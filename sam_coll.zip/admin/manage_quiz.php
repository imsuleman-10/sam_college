<?php
session_start();
// Security check: Admin only
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$page_title = 'Manage Quizzes';

$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$course_title = 'Quiz Management';
$quizzes = [];
$quiz_count = 0;

// Redirect if no valid course ID
if ($course_id === 0) {
    header('Location: manage_courses.php');
    exit;
}

// --- 1. Fetch Course Title and Validate ---
$sql_course = "SELECT title FROM courses WHERE course_id = ?";
if ($stmt_course = $conn->prepare($sql_course)) {
    $stmt_course->bind_param("i", $course_id);
    $stmt_course->execute();
    $result_course = $stmt_course->get_result();
    if ($result_course->num_rows === 1) {
        $course_title = $result_course->fetch_assoc()['title'];
    } else {
        // Invalid course ID, redirect
        $_SESSION['quiz_message'] = '<div class="alert alert-danger">Invalid Course ID provided.</div>';
        header('Location: manage_courses.php');
        exit;
    }
    $stmt_course->close();
}

// --- 2. Handle POST Request (Add/Edit Question) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $question_text = trim($_POST['question_text']);
    $option_a = trim($_POST['option_a']);
    $option_b = trim($_POST['option_b']);
    $option_c = trim($_POST['option_c']);
    $option_d = trim($_POST['option_d']);
    $correct_option = trim($_POST['correct_option']);
    $quiz_id = isset($_POST['quiz_id']) ? intval($_POST['quiz_id']) : 0;

    // Validation
    if (empty($question_text) || empty($option_a) || empty($option_b) || empty($option_c) || empty($option_d) || !in_array($correct_option, ['A', 'B', 'C', 'D'])) {
        $_SESSION['quiz_message'] = '<div class="alert alert-danger">All fields are required and the correct option must be A, B, C, or D.</div>';
    } else {
        if ($quiz_id > 0) {
            // EDIT Operation (Update)
            $sql = "UPDATE quizzes SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? WHERE quiz_id=? AND course_id=?";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("ssssssii", $question_text, $option_a, $option_b, $option_c, $option_d, $correct_option, $quiz_id, $course_id);
                if ($stmt->execute()) {
                    $_SESSION['quiz_message'] = '<div class="alert alert-success">Question updated successfully!</div>';
                } else {
                    $_SESSION['quiz_message'] = '<div class="alert alert-danger">Error updating question: ' . $stmt->error . '</div>';
                }
                $stmt->close();
            }
        } else {
            // ADD Operation (Create)
            // Check max limit (10) before adding
            $sql_count = "SELECT COUNT(*) AS count FROM quizzes WHERE course_id = ?";
            $stmt_count = $conn->prepare($sql_count);
            $stmt_count->bind_param("i", $course_id);
            $stmt_count->execute();
            $quiz_count = $stmt_count->get_result()->fetch_assoc()['count'];
            $stmt_count->close();

            if ($quiz_count >= 10) {
                $_SESSION['quiz_message'] = '<div class="alert alert-warning">The maximum limit of 10 MCQs has been reached for this course. Please edit an existing question instead.</div>';
            } else {
                $sql = "INSERT INTO quizzes (course_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)";
                if ($stmt = $conn->prepare($sql)) {
                    $stmt->bind_param("issssss", $course_id, $question_text, $option_a, $option_b, $option_c, $option_d, $correct_option);
                    if ($stmt->execute()) {
                        $_SESSION['quiz_message'] = '<div class="alert alert-success">Question added successfully!</div>';
                    } else {
                        $_SESSION['quiz_message'] = '<div class="alert alert-danger">Error adding question: ' . $stmt->error . '</div>';
                    }
                    $stmt->close();
                }
            }
        }
    }
    // PRG Pattern: Redirect back after POST
    header("Location: manage_quiz.php?course_id={$course_id}");
    exit;
}

// --- 3. Handle GET Request (Delete Question) ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['quiz_id'])) {
    $quiz_id_to_delete = intval($_GET['quiz_id']);
    
    $sql_delete = "DELETE FROM quizzes WHERE quiz_id = ? AND course_id = ?";
    if ($stmt_delete = $conn->prepare($sql_delete)) {
        $stmt_delete->bind_param("ii", $quiz_id_to_delete, $course_id);
        if ($stmt_delete->execute()) {
            $_SESSION['quiz_message'] = '<div class="alert alert-success">Question deleted successfully.</div>';
        } else {
            $_SESSION['quiz_message'] = '<div class="alert alert-danger">Error deleting question.</div>';
        }
        $stmt_delete->close();
    }
    // PRG Pattern: Redirect back after DELETE
    header("Location: manage_quiz.php?course_id={$course_id}");
    exit;
}

// --- 4. Fetch All Quizzes for Display ---
$sql_quizzes = "SELECT * FROM quizzes WHERE course_id = ?";
if ($stmt_quizzes = $conn->prepare($sql_quizzes)) {
    $stmt_quizzes->bind_param("i", $course_id);
    $stmt_quizzes->execute();
    $result_quizzes = $stmt_quizzes->get_result();
    $quiz_count = $result_quizzes->num_rows;
    while ($row = $result_quizzes->fetch_assoc()) {
        $quizzes[] = $row;
    }
    $stmt_quizzes->close();
}

$conn->close();
require_once '../includes/header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-question-circle text-success"></i> Manage Quiz for: <span class="text-primary"><?php echo htmlspecialchars($course_title); ?></span></h2>
        <a href="manage_courses.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Courses</a>
    </div>

    <?php if (isset($_SESSION['quiz_message'])): ?>
        <?php echo $_SESSION['quiz_message']; ?>
        <?php unset($_SESSION['quiz_message']); // Clear session message after display ?>
    <?php endif; ?>

    <div class="alert <?php echo ($quiz_count >= 5) ? 'alert-info' : 'alert-warning'; ?> shadow-sm">
        Current Questions: <span class="fw-bold"><?php echo $quiz_count; ?></span> / 10 (Min required: 5)
        <?php if ($quiz_count < 5): ?>
            <p class="mb-0 text-danger">⚠️ **ACTION REQUIRED:** You need to add at least **<?php echo 5 - $quiz_count; ?>** more questions before students can take the quiz.</p>
        <?php endif; ?>
    </div>
    
    <?php if ($quiz_count < 10): ?>
    <div class="card shadow-lg mb-5">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="fas fa-plus-square"></i> Add New MCQ (Question #<?php echo $quiz_count + 1; ?>)</h5>
        </div>
        <div class="card-body">
            <form action="manage_quiz.php?course_id=<?php echo $course_id; ?>" method="post">
                <input type="hidden" name="quiz_id" value="0">
                <div class="mb-3">
                    <label for="question_text" class="form-label fw-bold">Question Statement</label>
                    <textarea name="question_text" id="question_text" class="form-control" rows="2" required></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="option_a" class="form-label">Option A</label>
                        <input type="text" name="option_a" id="option_a" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="option_b" class="form-label">Option B</label>
                        <input type="text" name="option_b" id="option_b" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="option_c" class="form-label">Option C</label>
                        <input type="text" name="option_c" id="option_c" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="option_d" class="form-label">Option D</label>
                        <input type="text" name="option_d" id="option_d" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="correct_option" class="form-label fw-bold">Correct Option (A, B, C, or D)</label>
                    <select name="correct_option" id="correct_option" class="form-select" required>
                        <option value="">-- Select Correct Answer --</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success btn-lg"><i class="fas fa-plus-circle me-1"></i> Add Question</button>
            </form>
        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-danger text-center shadow-sm">
            <i class="fas fa-ban me-2"></i> You have reached the maximum limit of 10 questions. Please edit an existing one if needed.
        </div>
    <?php endif; ?>
    
    <hr>
    
    <h3 class="mb-3"><i class="fas fa-list-ul"></i> Existing Quizzes (Total: <?php echo $quiz_count; ?>)</h3>
    
    <?php if ($quiz_count > 0): ?>
        <?php $q_num = 1; foreach ($quizzes as $quiz): ?>
            <div class="card mb-3 shadow-sm quiz-item">
                <div class="card-body">
                    <h5 class="card-title text-primary">Q<?php echo $q_num++; ?>: <?php echo htmlspecialchars($quiz['question_text']); ?></h5>
                    <ul class="list-group list-group-flush mb-3 border rounded">
                        <li class="list-group-item <?php echo $quiz['correct_option'] == 'A' ? 'list-group-item-success fw-bold' : ''; ?>">
                            <?php echo $quiz['correct_option'] == 'A' ? '<i class="fas fa-check-circle me-2"></i>' : ' '; ?>
                            A. <?php echo htmlspecialchars($quiz['option_a']); ?>
                        </li>
                        <li class="list-group-item <?php echo $quiz['correct_option'] == 'B' ? 'list-group-item-success fw-bold' : ''; ?>">
                            <?php echo $quiz['correct_option'] == 'B' ? '<i class="fas fa-check-circle me-2"></i>' : ' '; ?>
                            B. <?php echo htmlspecialchars($quiz['option_b']); ?>
                        </li>
                        <li class="list-group-item <?php echo $quiz['correct_option'] == 'C' ? 'list-group-item-success fw-bold' : ''; ?>">
                            <?php echo $quiz['correct_option'] == 'C' ? '<i class="fas fa-check-circle me-2"></i>' : ' '; ?>
                            C. <?php echo htmlspecialchars($quiz['option_c']); ?>
                        </li>
                        <li class="list-group-item <?php echo $quiz['correct_option'] == 'D' ? 'list-group-item-success fw-bold' : ''; ?>">
                            <?php echo $quiz['correct_option'] == 'D' ? '<i class="fas fa-check-circle me-2"></i>' : ' '; ?>
                            D. <?php echo htmlspecialchars($quiz['option_d']); ?>
                        </li>
                    </ul>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-sm btn-warning me-2 edit-btn" 
                                data-bs-toggle="modal" data-bs-target="#editQuizModal" 
                                data-id="<?php echo $quiz['quiz_id']; ?>" 
                                data-q="<?php echo htmlspecialchars($quiz['question_text']); ?>"
                                data-a="<?php echo htmlspecialchars($quiz['option_a']); ?>"
                                data-b="<?php echo htmlspecialchars($quiz['option_b']); ?>"
                                data-c="<?php echo htmlspecialchars($quiz['option_c']); ?>"
                                data-d="<?php echo htmlspecialchars($quiz['option_d']); ?>"
                                data-correct="<?php echo $quiz['correct_option']; ?>">
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>
                        <a href="manage_quiz.php?course_id=<?php echo $course_id; ?>&action=delete&quiz_id=<?php echo $quiz['quiz_id']; ?>" 
                           onclick="return confirm('WARNING: Are you sure you want to delete this question? This action is permanent.');" 
                           class="btn btn-sm btn-danger">
                            <i class="fas fa-trash-alt me-1"></i> Delete
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="alert alert-info text-center">
            No quiz questions found for this course. Please add some above.
        </div>
    <?php endif; ?>
</div>

<div class="modal fade" id="editQuizModal" tabindex="-1" aria-labelledby="editQuizModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title" id="editQuizModalLabel"><i class="fas fa-edit"></i> Edit Quiz Question</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="manage_quiz.php?course_id=<?php echo $course_id; ?>" method="post">
                <div class="modal-body">
                    <input type="hidden" name="quiz_id" id="modal_quiz_id">
                    <div class="mb-3">
                        <label for="modal_question_text" class="form-label fw-bold">Question Statement</label>
                        <textarea name="question_text" id="modal_question_text" class="form-control" rows="2" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label for="modal_option_a" class="form-label">Option A</label><input type="text" name="option_a" id="modal_option_a" class="form-control" required></div>
                        <div class="col-md-6 mb-3"><label for="modal_option_b" class="form-label">Option B</label><input type="text" name="option_b" id="modal_option_b" class="form-control" required></div>
                        <div class="col-md-6 mb-3"><label for="modal_option_c" class="form-label">Option C</label><input type="text" name="option_c" id="modal_option_c" class="form-control" required></div>
                        <div class="col-md-6 mb-3"><label for="modal_option_d" class="form-label">Option D</label><input type="text" name="option_d" id="modal_option_d" class="form-control" required></div>
                    </div>
                    <div class="mb-3">
                        <label for="modal_correct_option" class="form-label fw-bold">Correct Option (A, B, C, or D)</label>
                        <select name="correct_option" id="modal_correct_option" class="form-select" required>
                            <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning"><i class="fas fa-save me-1"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var editQuizModal = document.getElementById('editQuizModal');
    
    // Check if the modal element exists before adding the listener
    if (editQuizModal) {
        editQuizModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            
            // Extract data attributes from the clicked button
            var quizId = button.getAttribute('data-id');
            var question = button.getAttribute('data-q');
            var optA = button.getAttribute('data-a');
            var optB = button.getAttribute('data-b');
            var optC = button.getAttribute('data-c');
            var optD = button.getAttribute('data-d');
            var correct = button.getAttribute('data-correct');
            
            // Populate the modal's form fields
            editQuizModal.querySelector('#modal_quiz_id').value = quizId;
            editQuizModal.querySelector('#modal_question_text').value = question;
            editQuizModal.querySelector('#modal_option_a').value = optA;
            editQuizModal.querySelector('#modal_option_b').value = optB;
            editQuizModal.querySelector('#modal_option_c').value = optC;
            editQuizModal.querySelector('#modal_option_d').value = optD;
            editQuizModal.querySelector('#modal_correct_option').value = correct;
        });
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>