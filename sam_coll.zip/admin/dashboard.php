<?php
// Start session and check for authentication
session_start();

// 1. Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// 2. Check if user is Admin
if ($_SESSION['user_type'] != 'admin') {
    // Redirect non-admin users away
    header('Location: ../student/dashboard.php');
    exit;
}

// Include database connection for stats
require_once '../includes/db_connection.php';

// Fetch comprehensive statistics for dashboard
try {
    // Get total students count
    $studentQuery = "SELECT COUNT(*) as total FROM users WHERE user_type = 'student'";
    $studentStmt = $pdo->query($studentQuery);
    $studentCount = $studentStmt->fetch()['total'];
    
    // Get total active courses count
    $courseQuery = "SELECT COUNT(*) as total FROM courses";
    $courseStmt = $pdo->query($courseQuery);
    $courseCount = $courseStmt->fetch()['total'];
    
    // Get certificate statistics
    $certStatsQuery = "
        SELECT 
            COUNT(*) as total_certificates,
            SUM(CASE WHEN certificate_status = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN certificate_status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN certificate_status = 'rejected' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN certificate_status = 'not_eligible' THEN 1 ELSE 0 END) as not_eligible
        FROM progress
    ";
    $certStmt = $pdo->query($certStatsQuery);
    $certStats = $certStmt->fetch(PDO::FETCH_ASSOC);
    
    // Get total quizzes count
    $quizQuery = "SELECT COUNT(*) as total FROM quizzes";
    $quizStmt = $pdo->query($quizQuery);
    $quizCount = $quizStmt->fetch()['total'];
    
    // Get enrolled students count
    $enrolledQuery = "SELECT COUNT(DISTINCT student_id) as total FROM enrollments";
    $enrolledStmt = $pdo->query($enrolledQuery);
    $enrolledStudents = $enrolledStmt->fetch()['total'];
    
    // Get recent enrollments (last 7 days)
    $recentEnrollQuery = "
        SELECT 
            u.name as student_name,
            c.title as course_title,
            e.enrollment_date,
            DATE_FORMAT(e.enrollment_date, '%b %d, %Y') as formatted_date,
            TIME_FORMAT(e.enrollment_date, '%h:%i %p') as formatted_time
        FROM enrollments e
        JOIN users u ON e.student_id = u.user_id
        JOIN courses c ON e.course_id = c.course_id
        WHERE e.enrollment_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY e.enrollment_date DESC
        LIMIT 6
    ";
    $recentEnrollStmt = $pdo->query($recentEnrollQuery);
    $recentEnrollments = $recentEnrollStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get top performing students (by quiz score)
    $topStudentsQuery = "
        SELECT 
            u.name,
            u.email,
            ROUND(AVG(p.quiz_score), 1) as avg_score,
            COUNT(DISTINCT p.course_id) as courses_completed
        FROM progress p
        JOIN users u ON p.student_id = u.user_id
        WHERE p.quiz_score > 0
        GROUP BY p.student_id
        ORDER BY avg_score DESC
        LIMIT 5
    ";
    $topStudentsStmt = $pdo->query($topStudentsQuery);
    $topStudents = $topStudentsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get course enrollment statistics
    $courseStatsQuery = "
        SELECT 
            c.title,
            COUNT(e.student_id) as enrolled_students,
            ROUND(AVG(p.quiz_score), 1) as avg_quiz_score,
            ROUND(AVG(p.video_progress_percentage), 1) as avg_progress
        FROM courses c
        LEFT JOIN enrollments e ON c.course_id = e.course_id
        LEFT JOIN progress p ON c.course_id = p.course_id AND e.student_id = p.student_id
        GROUP BY c.course_id
        ORDER BY enrolled_students DESC
    ";
    $courseStatsStmt = $pdo->query($courseStatsQuery);
    $courseStats = $courseStatsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get system health statistics
    $studentsWithoutEnrollment = $studentCount - $enrolledStudents;
    $enrollmentRate = $studentCount > 0 ? round(($enrolledStudents / $studentCount) * 100, 1) : 0;
    
} catch (PDOException $e) {
    // If there's an error, set defaults
    $studentCount = 0;
    $courseCount = 0;
    $quizCount = 0;
    $enrolledStudents = 0;
    $certStats = [
        'total_certificates' => 0,
        'approved' => 0,
        'pending' => 0,
        'rejected' => 0,
        'not_eligible' => 0
    ];
    $recentEnrollments = [];
    $topStudents = [];
    $courseStats = [];
    $studentsWithoutEnrollment = 0;
    $enrollmentRate = 0;
    $errorMessage = "Unable to load dashboard statistics: " . $e->getMessage();
}

$page_title = 'Admin Dashboard';
require_once '../includes/header.php';
?>

<!-- Dashboard CSS -->
<style>
:root {
    --primary-color: #4361ee;
    --secondary-color: #3a0ca3;
    --success-color: #4cc9f0;
    --warning-color: #f8961e;
    --danger-color: #e63946;
    --info-color: #4895ef;
    --dark-color: #2b2d42;
    --light-color: #f8f9fa;
    --gray-color: #6c757d;
}

.dashboard-card {
    border: none;
    border-radius: 12px;
    transition: all 0.3s ease;
    overflow: hidden;
}

.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
}

.stat-card {
    border-left: 4px solid;
    padding: 1.5rem;
}

.stat-card-primary { border-left-color: var(--primary-color); }
.stat-card-success { border-left-color: var(--success-color); }
.stat-card-warning { border-left-color: var(--warning-color); }
.stat-card-danger { border-left-color: var(--danger-color); }
.stat-card-info { border-left-color: var(--info-color); }

.stat-number {
    font-size: 2.2rem;
    font-weight: 700;
    line-height: 1;
    color: var(--dark-color);
}

.stat-label {
    font-size: 0.9rem;
    color: var(--gray-color);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 600;
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
}

.bg-primary-light { background-color: rgba(67, 97, 238, 0.1); color: var(--primary-color); }
.bg-success-light { background-color: rgba(76, 201, 240, 0.1); color: var(--success-color); }
.bg-warning-light { background-color: rgba(248, 150, 30, 0.1); color: var(--warning-color); }
.bg-danger-light { background-color: rgba(230, 57, 70, 0.1); color: var(--danger-color); }
.bg-info-light { background-color: rgba(72, 149, 239, 0.1); color: var(--info-color); }

.progress-thin {
    height: 6px;
    border-radius: 3px;
}

.badge-pill {
    border-radius: 50px;
    padding: 5px 12px;
    font-weight: 600;
}

.activity-item {
    border-left: 3px solid;
    padding-left: 15px;
    margin-bottom: 1.5rem;
}

.activity-item-primary { border-left-color: var(--primary-color); }
.activity-item-success { border-left-color: var(--success-color); }
.activity-item-warning { border-left-color: var(--warning-color); }

.course-progress {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 12px;
    padding: 1.5rem;
}

.chart-container {
    position: relative;
    height: 250px;
    width: 100%;
}

.quick-action-card {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    border: none;
    border-radius: 12px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.quick-action-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(0,0,0,0.1);
}

.welcome-header {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    border-radius: 12px;
    padding: 2rem;
    margin-bottom: 2rem;
}

.system-health {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
    color: white;
    border-radius: 12px;
    padding: 1.5rem;
}
</style>

<div class="container-fluid py-4">
    <!-- Welcome Header -->
    <div class="welcome-header shadow">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="display-5 fw-bold mb-2">Welcome back, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h1>
                <p class="lead mb-0">Here's what's happening with your e-learning platform today.</p>
                <div class="mt-3">
                    <span class="badge bg-light text-primary fs-6 px-3 py-2">
                        <i class="fas fa-user-shield me-2"></i>Administrator
                    </span>
                    <span class="badge bg-light text-dark fs-6 px-3 py-2 ms-2">
                        <i class="fas fa-calendar-alt me-2"></i><?php echo date('F j, Y'); ?>
                    </span>
                </div>
            </div>
            <div class="col-md-4 text-md-end">
                <div class="system-health">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-heartbeat fa-3x"></i>
                        </div>
                        <div>
                            <h3 class="mb-0"><?php echo $enrollmentRate; ?>%</h3>
                            <p class="mb-0">Enrollment Rate</p>
                            <small><?php echo $enrolledStudents; ?> of <?php echo $studentCount; ?> students enrolled</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <!-- Total Students -->
        <div class="col-xl-2 col-md-4 col-sm-6">
            <div class="card dashboard-card stat-card stat-card-primary">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="stat-number"><?php echo number_format($studentCount); ?></div>
                            <div class="stat-label">Total Students</div>
                        </div>
                        <div class="stat-icon bg-primary-light">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="px-3 pb-3">
                        <small class="text-muted">
                            <i class="fas fa-user-check me-1"></i>
                            <?php echo $enrolledStudents; ?> enrolled
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Active Courses -->
        <div class="col-xl-2 col-md-4 col-sm-6">
            <div class="card dashboard-card stat-card stat-card-success">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="stat-number"><?php echo number_format($courseCount); ?></div>
                            <div class="stat-label">Active Courses</div>
                        </div>
                        <div class="stat-icon bg-success-light">
                            <i class="fas fa-book-open"></i>
                        </div>
                    </div>
                    <div class="px-3 pb-3">
                        <small class="text-muted">
                            <i class="fas fa-chart-line me-1"></i>
                            <?php echo isset($courseStats[0]['enrolled_students']) ? $courseStats[0]['enrolled_students'] : 0; ?> in top course
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Quizzes -->
        <div class="col-xl-2 col-md-4 col-sm-6">
            <div class="card dashboard-card stat-card stat-card-warning">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="stat-number"><?php echo number_format($quizCount); ?></div>
                            <div class="stat-label">Total Quizzes</div>
                        </div>
                        <div class="stat-icon bg-warning-light">
                            <i class="fas fa-question-circle"></i>
                        </div>
                    </div>
                    <div class="px-3 pb-3">
                        <small class="text-muted">
                            <i class="fas fa-graduation-cap me-1"></i>
                            <?php echo isset($topStudents[0]['avg_score']) ? $topStudents[0]['avg_score'] : 0; ?>% top score
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Approved Certificates -->
        <div class="col-xl-2 col-md-4 col-sm-6">
            <div class="card dashboard-card stat-card stat-card-info">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="stat-number"><?php echo number_format($certStats['approved']); ?></div>
                            <div class="stat-label">Approved Certificates</div>
                        </div>
                        <div class="stat-icon bg-info-light">
                            <i class="fas fa-certificate"></i>
                        </div>
                    </div>
                    <div class="px-3 pb-3">
                        <small class="text-muted">
                            <i class="fas fa-clock me-1"></i>
                            <?php echo $certStats['pending']; ?> pending
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Enrollment Rate -->
        <div class="col-xl-2 col-md-4 col-sm-6">
            <div class="card dashboard-card stat-card stat-card-danger">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="stat-number"><?php echo $enrollmentRate; ?>%</div>
                            <div class="stat-label">Enrollment Rate</div>
                        </div>
                        <div class="stat-icon bg-danger-light">
                            <i class="fas fa-chart-pie"></i>
                        </div>
                    </div>
                    <div class="px-3 pb-3">
                        <div class="progress progress-thin">
                            <div class="progress-bar bg-danger" role="progressbar" 
                                 style="width: <?php echo $enrollmentRate; ?>%" 
                                 aria-valuenow="<?php echo $enrollmentRate; ?>" 
                                 aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Unenrolled Students -->
        <div class="col-xl-2 col-md-4 col-sm-6">
            <div class="card dashboard-card stat-card" style="border-left-color: #6c757d;">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="stat-number"><?php echo number_format($studentsWithoutEnrollment); ?></div>
                            <div class="stat-label">Not Enrolled</div>
                        </div>
                        <div class="stat-icon" style="background-color: rgba(108, 117, 125, 0.1); color: #6c757d;">
                            <i class="fas fa-user-slash"></i>
                        </div>
                    </div>
                    <div class="px-3 pb-3">
                        <small class="text-muted">
                            <i class="fas fa-exclamation-circle me-1"></i>
                            Need enrollment
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Row -->
    <div class="row g-4">
        <!-- Left Column: Recent Activity & Top Students -->
        <div class="col-lg-8">
            <!-- Recent Enrollments -->
            <div class="card dashboard-card shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-history text-primary me-2"></i>Recent Enrollments
                        </h5>
                        <a href="manage_users.php" class="btn btn-sm btn-outline-primary">
                            View All <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($recentEnrollments)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Course</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentEnrollments as $enrollment): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                                        <?php echo strtoupper(substr($enrollment['student_name'], 0, 1)); ?>
                                                    </div>
                                                    <div>
                                                        <div class="fw-semibold"><?php echo htmlspecialchars($enrollment['student_name']); ?></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-primary bg-opacity-10 text-primary"><?php echo htmlspecialchars($enrollment['course_title']); ?></span>
                                            </td>
                                            <td><?php echo $enrollment['formatted_date']; ?></td>
                                            <td><?php echo $enrollment['formatted_time']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-user-clock fa-3x text-muted mb-3"></i>
                            <h5>No Recent Enrollments</h5>
                            <p class="text-muted">No students have enrolled in the past 7 days.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Top Performing Students -->
            <div class="card dashboard-card shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-trophy text-warning me-2"></i>Top Performing Students
                        </h5>
                        <span class="badge bg-warning">Quiz Performance</span>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!empty($topStudents)): ?>
                        <div class="row g-3">
                            <?php $rank = 1; ?>
                            <?php foreach ($topStudents as $student): ?>
                                <div class="col-md-6">
                                    <div class="card border-0 bg-light">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-lg bg-warning text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                                                         style="width: 50px; height: 50px;">
                                                        <span class="fw-bold fs-5"><?php echo $rank++; ?></span>
                                                    </div>
                                                    <div>
                                                        <h6 class="mb-1"><?php echo htmlspecialchars($student['name']); ?></h6>
                                                        <p class="text-muted mb-0 small"><?php echo htmlspecialchars($student['email']); ?></p>
                                                    </div>
                                                </div>
                                                <div class="text-end">
                                                    <div class="fw-bold fs-4 text-success"><?php echo $student['avg_score']; ?>%</div>
                                                    <small class="text-muted">Avg Score</small>
                                                </div>
                                            </div>
                                            <div class="mt-3">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-primary bg-opacity-10 text-primary">
                                                        <i class="fas fa-book me-1"></i>
                                                        <?php echo $student['courses_completed']; ?> courses
                                                    </span>
                                                    <a href="view_student.php?id=<?php echo $student['user_id'] ?? '#'; ?>" 
                                                       class="btn btn-sm btn-outline-primary">
                                                        View Profile
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                            <h5>No Performance Data Yet</h5>
                            <p class="text-muted">Students need to complete quizzes to appear here.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Right Column: Quick Actions & Course Stats -->
        <div class="col-lg-4">
            <!-- Quick Actions -->
            <div class="card dashboard-card shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-bolt text-danger me-2"></i>Quick Actions
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <!-- Manage Students -->
                        <div class="col-12">
                            <div class="quick-action-card p-3" onclick="window.location.href='manage_users.php'">
                                <div class="d-flex align-items-center">
                                    <div class="bg-danger bg-opacity-10 p-2 rounded me-3">
                                        <i class="fas fa-user-graduate fa-2x text-danger"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Manage Students</h6>
                                        <p class="text-muted mb-0 small">View, edit, or delete student accounts</p>
                                    </div>
                                    <div class="ms-auto">
                                        <i class="fas fa-chevron-right text-muted"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Manage Courses -->
                        <div class="col-12">
                            <div class="quick-action-card p-3" onclick="window.location.href='manage_courses.php'">
                                <div class="d-flex align-items-center">
                                    <div class="bg-info bg-opacity-10 p-2 rounded me-3">
                                        <i class="fas fa-book fa-2x text-info"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Manage Courses</h6>
                                        <p class="text-muted mb-0 small">Add, update, or remove courses</p>
                                    </div>
                                    <div class="ms-auto">
                                        <i class="fas fa-chevron-right text-muted"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Manage Quizzes -->
                        <div class="col-12">
                            <div class="quick-action-card p-3" onclick="window.location.href='manage_quiz.php'">
                                <div class="d-flex align-items-center">
                                    <div class="bg-warning bg-opacity-10 p-2 rounded me-3">
                                        <i class="fas fa-question-circle fa-2x text-warning"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Manage Quizzes</h6>
                                        <p class="text-muted mb-0 small">Create and edit course quizzes</p>
                                    </div>
                                    <div class="ms-auto">
                                        <i class="fas fa-chevron-right text-muted"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Certificate Approval -->
                        <div class="col-12">
                            <div class="quick-action-card p-3" onclick="window.location.href='certificate_requests.php'">
                                <div class="d-flex align-items-center">
                                    <div class="bg-success bg-opacity-10 p-2 rounded me-3">
                                        <i class="fas fa-certificate fa-2x text-success"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Certificate Approval</h6>
                                        <p class="text-muted mb-0 small">Review and approve certificates</p>
                                    </div>
                                    <div class="ms-auto">
                                        <i class="fas fa-chevron-right text-muted"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Course Statistics -->
            <div class="card dashboard-card shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-bar text-success me-2"></i>Course Statistics
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($courseStats)): ?>
                        <?php foreach ($courseStats as $course): ?>
                            <div class="mb-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="mb-0"><?php echo htmlspecialchars($course['title']); ?></h6>
                                    <span class="badge bg-primary"><?php echo $course['enrolled_students']; ?> students</span>
                                </div>
                                
                                <!-- Quiz Score Progress -->
                                <div class="mb-2">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small class="text-muted">Quiz Score</small>
                                        <small class="fw-semibold"><?php echo $course['avg_quiz_score'] ?? 0; ?>%</small>
                                    </div>
                                    <div class="progress progress-thin">
                                        <div class="progress-bar bg-success" role="progressbar" 
                                             style="width: <?php echo $course['avg_quiz_score'] ?? 0; ?>%"></div>
                                    </div>
                                </div>
                                
                                <!-- Video Progress -->
                                <div class="mb-2">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small class="text-muted">Video Progress</small>
                                        <small class="fw-semibold"><?php echo $course['avg_progress'] ?? 0; ?>%</small>
                                    </div>
                                    <div class="progress progress-thin">
                                        <div class="progress-bar bg-info" role="progressbar" 
                                             style="width: <?php echo $course['avg_progress'] ?? 0; ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-book-open fa-3x text-muted mb-3"></i>
                            <h6>No Course Data Available</h6>
                            <p class="text-muted small">Add courses to see statistics here.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Certificate Status Overview -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card dashboard-card shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-certificate text-info me-2"></i>Certificate Status Overview
                        </h5>
                        <a href="certificate_requests.php" class="btn btn-sm btn-outline-info">
                            Manage Certificates
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 text-center mb-3">
                            <div class="bg-info bg-opacity-10 p-4 rounded">
                                <h2 class="text-info mb-2"><?php echo $certStats['approved']; ?></h2>
                                <span class="badge bg-info">Approved</span>
                            </div>
                        </div>
                        <div class="col-md-3 text-center mb-3">
                            <div class="bg-warning bg-opacity-10 p-4 rounded">
                                <h2 class="text-warning mb-2"><?php echo $certStats['pending']; ?></h2>
                                <span class="badge bg-warning">Pending</span>
                            </div>
                        </div>
                        <div class="col-md-3 text-center mb-3">
                            <div class="bg-secondary bg-opacity-10 p-4 rounded">
                                <h2 class="text-secondary mb-2"><?php echo $certStats['not_eligible']; ?></h2>
                                <span class="badge bg-secondary">Not Eligible</span>
                            </div>
                        </div>
                        <div class="col-md-3 text-center mb-3">
                            <div class="bg-danger bg-opacity-10 p-4 rounded">
                                <h2 class="text-danger mb-2"><?php echo $certStats['rejected']; ?></h2>
                                <span class="badge bg-danger">Rejected</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Links Footer -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card border-0 bg-light">
                <div class="card-body py-3">
                    <div class="d-flex flex-wrap justify-content-center gap-2">
                        <a href="add_student.php" class="btn btn-primary">
                            <i class="fas fa-user-plus me-2"></i> Add Student
                        </a>
                        <a href="add_course.php" class="btn btn-success">
                            <i class="fas fa-plus-circle me-2"></i> Add Course
                        </a>
                        <a href="add_quiz.php" class="btn btn-warning">
                            <i class="fas fa-question-circle me-2"></i> Add Quiz
                        </a>
                        <!-- <a href="system_logs.php" class="btn btn-secondary">
                            <i class="fas fa-clipboard-list me-2"></i> System Logs
                        </a> -->
                        <a href="reports.php" class="btn btn-info">
                            <i class="fas fa-chart-pie me-2"></i> Generate Reports
                        </a>
                        <a href="../logout.php" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Dashboard JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto refresh dashboard every 2 minutes
    let refreshInterval = setInterval(function() {
        console.log('Dashboard auto-refresh check...');
        // You can add AJAX refresh here if needed
    }, 120000);

    // Quick action card click effects
    document.querySelectorAll('.quick-action-card').forEach(card => {
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });

    // Number animation for stats
    function animateNumbers() {
        const statNumbers = document.querySelectorAll('.stat-number');
        statNumbers.forEach(stat => {
            const finalValue = parseFloat(stat.textContent.replace(/,/g, ''));
            let startValue = 0;
            const duration = 2000;
            const increment = finalValue / (duration / 16);
            
            const timer = setInterval(() => {
                startValue += increment;
                if (startValue >= finalValue) {
                    stat.textContent = finalValue.toLocaleString();
                    clearInterval(timer);
                } else {
                    stat.textContent = Math.floor(startValue).toLocaleString();
                }
            }, 16);
        });
    }

    // Start animation on page load
    setTimeout(animateNumbers, 500);

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Alt + S for student management
        if (e.altKey && e.key === 's') {
            e.preventDefault();
            window.location.href = 'manage_users.php';
        }
        // Alt + C for course management
        if (e.altKey && e.key === 'c') {
            e.preventDefault();
            window.location.href = 'manage_courses.php';
        }
        // Alt + Q for quiz management
        if (e.altKey && e.key === 'q') {
            e.preventDefault();
            window.location.href = 'manage_quiz.php';
        }
    });

    // Performance optimization
    window.addEventListener('blur', function() {
        clearInterval(refreshInterval);
    });

    window.addEventListener('focus', function() {
        clearInterval(refreshInterval);
        refreshInterval = setInterval(function() {
            console.log('Dashboard auto-refresh check...');
        }, 120000);
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>