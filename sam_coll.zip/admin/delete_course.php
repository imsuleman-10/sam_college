<?php
session_start();
// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';

// Check for course ID
if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
    $course_id = trim($_GET["id"]);

    // IMPORTANT: Because of the database's use of ON DELETE CASCADE for foreign keys,
    // deleting the course will automatically delete associated records in:
    // - enrollments
    // - quizzes
    // - progress
    // - certificates (if you had a dedicated table linked to progress/enrollment)
    
    // Check the course exists first to get the title for the message
    $title_check_sql = "SELECT title FROM courses WHERE course_id = ?";
    if ($stmt_check = $conn->prepare($title_check_sql)) {
        $stmt_check->bind_param("i", $param_id);
        $param_id = $course_id;
        
        if ($stmt_check->execute()) {
            $result = $stmt_check->get_result();
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                $course_title = $row['title'];

                $stmt_check->close();

                // Prepare a DELETE statement
                $sql_delete = "DELETE FROM courses WHERE course_id = ?";
                if ($stmt_delete = $conn->prepare($sql_delete)) {
                    $stmt_delete->bind_param("i", $param_id);
                    $param_id = $course_id;

                    if ($stmt_delete->execute()) {
                        // Success
                        $_SESSION['message'] = 'Course **' . htmlspecialchars($course_title) . '** and all related data were deleted successfully.';
                    } else {
                        // Failure
                        $_SESSION['message'] = '<div class="alert alert-danger">Error deleting course: ' . $stmt_delete->error . '</div>';
                    }
                    $stmt_delete->close();
                }
            } else {
                 $_SESSION['message'] = '<div class="alert alert-danger">Error: Course ID not found.</div>';
            }
        }
    }
} else {
    // If no ID is provided
    $_SESSION['message'] = '<div class="alert alert-danger">Error: Invalid request. No course ID specified.</div>';
}

$conn->close();
// Redirect back to the course management page
header("Location: manage_courses.php");
exit();
?>