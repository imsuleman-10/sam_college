<?php
session_start();
// Security checks
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';

$page_title = 'Manage Courses';
$edit_course = null;
$action = 'Add New Course';
$message_key = 'course_message';

// --- Configuration for File Uploads ---
const UPLOAD_LOGO_DIR = '../uploads/course_logos/';
const UPLOAD_SLIDES_DIR = '../uploads/course_slides/';

const ALLOWED_LOGO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const ALLOWED_SLIDES_TYPES = ['application/pdf', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];

const MAX_LOGO_SIZE = 2 * 1024 * 1024; // 2MB
const MAX_SLIDES_SIZE = 10 * 1024 * 1024; // 10MB

// Ensure upload directories exist
if (!is_dir(UPLOAD_LOGO_DIR)) {
    mkdir(UPLOAD_LOGO_DIR, 0777, true);
}
if (!is_dir(UPLOAD_SLIDES_DIR)) {
    mkdir(UPLOAD_SLIDES_DIR, 0777, true);
}

// Function to handle logo upload
function handle_logo_upload($course_id = 0, $old_image_path = null) {
    $new_image_path = $old_image_path;

    if (isset($_FILES['course_image']) && $_FILES['course_image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['course_image'];
        
        // 1. Validation
        if ($file['size'] > MAX_LOGO_SIZE) {
            $_SESSION['course_message'] = '<div class="alert alert-danger">Error: Logo file is too large (max 2MB).</div>';
            return false;
        }
        if (!in_array($file['type'], ALLOWED_LOGO_TYPES)) {
            $_SESSION['course_message'] = '<div class="alert alert-danger">Error: Only JPG, PNG, and WEBP files are allowed for logo.</div>';
            return false;
        }

        // 2. Create unique filename
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $new_file_name = uniqid('course_', true) . '.' . strtolower($ext);
        $destination = UPLOAD_LOGO_DIR . $new_file_name;

        // 3. Move file
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            // Delete old file if updating
            if ($old_image_path && file_exists('../' . $old_image_path)) {
                unlink('../' . $old_image_path);
            }
            // Return the path relative to the root/uploads folder for DB storage
            return 'uploads/course_logos/' . $new_file_name; 
        } else {
            $_SESSION['course_message'] = '<div class="alert alert-danger">Error uploading logo file to server.</div>';
            return false;
        }
    } 
    
    // If no new file is uploaded, keep the old path if editing.
    if ($course_id > 0) {
        return $old_image_path;
    }
    
    // If adding new and no file uploaded
    return null;
}

// Function to handle slides upload
function handle_slides_upload($course_id = 0, $old_slides_path = null) {
    $new_slides_path = $old_slides_path;

    if (isset($_FILES['slides_file']) && $_FILES['slides_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['slides_file'];
        
        // 1. Validation
        if ($file['size'] > MAX_SLIDES_SIZE) {
            $_SESSION['course_message'] = '<div class="alert alert-danger">Error: Slides file is too large (max 10MB).</div>';
            return false;
        }
        if (!in_array($file['type'], ALLOWED_SLIDES_TYPES)) {
            $_SESSION['course_message'] = '<div class="alert alert-danger">Error: Only PDF and PowerPoint files are allowed for slides.</div>';
            return false;
        }

        // 2. Create unique filename
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $new_file_name = uniqid('slides_', true) . '.' . strtolower($ext);
        $destination = UPLOAD_SLIDES_DIR . $new_file_name;

        // 3. Move file
        if (move_uploaded_file($file['tmp_name'], $destination)) {
            // Delete old file if updating
            if ($old_slides_path && file_exists('../' . $old_slides_path)) {
                unlink('../' . $old_slides_path);
            }
            // Return the path relative to the root/uploads folder for DB storage
            return 'uploads/course_slides/' . $new_file_name; 
        } else {
            $_SESSION['course_message'] = '<div class="alert alert-danger">Error uploading slides file to server.</div>';
            return false;
        }
    }
    
    // If no new file is uploaded, keep the old path if editing.
    if ($course_id > 0) {
        return $old_slides_path;
    }
    
    // If adding new and no file uploaded
    return null;
}

// --- 1. Form Submission Handling (Add or Edit) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $youtube_iframe_link = trim($_POST['youtube_iframe_link']);
    $course_id = isset($_POST['course_id']) ? intval($_POST['course_id']) : 0;
    $old_image_path = isset($_POST['old_image_path']) ? $_POST['old_image_path'] : null;
    $old_slides_path = isset($_POST['old_slides_path']) ? $_POST['old_slides_path'] : null;

    if (empty($title) || empty($youtube_iframe_link)) {
        $_SESSION[$message_key] = '<div class="alert alert-danger">Course Title and YouTube Embed Link are required.</div>';
    } else {
        // Handle logo upload
        $uploaded_logo_path = handle_logo_upload($course_id, $old_image_path);
        if ($uploaded_logo_path === false) {
            header('Location: manage_courses.php');
            exit;
        }

        // Handle slides upload
        $uploaded_slides_path = handle_slides_upload($course_id, $old_slides_path);
        if ($uploaded_slides_path === false) {
            header('Location: manage_courses.php');
            exit;
        }

        // Sanitize iframe: Although stored as TEXT, restrict size and trust context
        $youtube_iframe_link = substr($youtube_iframe_link, 0, 500); 

        if ($course_id > 0) {
            // EDIT Course
            $sql = "UPDATE courses SET title = ?, description = ?, youtube_iframe_link = ?, course_image = ?, slides_path = ? WHERE course_id = ?";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("sssssi", $title, $description, $youtube_iframe_link, $uploaded_logo_path, $uploaded_slides_path, $course_id);
                if ($stmt->execute()) {
                    $_SESSION[$message_key] = '<div class="alert alert-success">Course **' . htmlspecialchars($title) . '** updated successfully!</div>';
                } else {
                    $_SESSION[$message_key] = '<div class="alert alert-danger">Error updating course: ' . $conn->error . '</div>';
                }
                $stmt->close();
            }
        } else {
            // ADD New Course
            $sql = "INSERT INTO courses (title, description, youtube_iframe_link, course_image, slides_path) VALUES (?, ?, ?, ?, ?)";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("sssss", $title, $description, $youtube_iframe_link, $uploaded_logo_path, $uploaded_slides_path);
                if ($stmt->execute()) {
                    $_SESSION[$message_key] = '<div class="alert alert-success">New course **' . htmlspecialchars($title) . '** added successfully!</div>';
                } else {
                    $_SESSION[$message_key] = '<div class="alert alert-danger">Error adding course: ' . $conn->error . '</div>';
                }
                $stmt->close();
            }
        }
    }
    // PRG Pattern: Redirect after POST to prevent form resubmission
    header('Location: manage_courses.php');
    exit;
}

// --- 2. Edit Mode Initialization (GET Request) ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $course_id = intval($_GET['id']);
    $sql = "SELECT course_id, title, description, youtube_iframe_link, course_image, slides_path FROM courses WHERE course_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $course_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $edit_course = $result->fetch_assoc();
        $stmt->close();
        if ($edit_course) {
            $action = 'Edit Course ID: ' . $course_id . ' - ' . htmlspecialchars($edit_course['title']);
        }
    }
}

// --- 3. Course Deletion Handling (GET Request) ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $course_id = intval($_GET['id']);
    
    // First, fetch the image and slides paths to delete the files
    $image_path_to_delete = null;
    $slides_path_to_delete = null;
    $sql_fetch_path = "SELECT course_image, slides_path FROM courses WHERE course_id = ?";
    if ($stmt_fetch = $conn->prepare($sql_fetch_path)) {
        $stmt_fetch->bind_param("i", $course_id);
        $stmt_fetch->execute();
        $result_fetch = $stmt_fetch->get_result();
        $row_fetch = $result_fetch->fetch_assoc();
        if ($row_fetch) {
            // Delete logo if exists
            if ($row_fetch['course_image']) {
                $image_path_to_delete = '../' . $row_fetch['course_image']; 
            }
            // Delete slides if exists
            if ($row_fetch['slides_path']) {
                $slides_path_to_delete = '../' . $row_fetch['slides_path']; 
            }
        }
        $stmt_fetch->close();
    }

    // Now, delete the course record (which cascades to quizzes, enrollments, etc.)
    $sql_delete = "DELETE FROM courses WHERE course_id = ?";
    if ($stmt_delete = $conn->prepare($sql_delete)) {
        $stmt_delete->bind_param("i", $course_id);
        if ($stmt_delete->execute()) {
            // Delete the physical logo file if it exists
            if ($image_path_to_delete && file_exists($image_path_to_delete)) {
                unlink($image_path_to_delete);
            }
            // Delete the physical slides file if it exists
            if ($slides_path_to_delete && file_exists($slides_path_to_delete)) {
                unlink($slides_path_to_delete);
            }
            $_SESSION[$message_key] = '<div class="alert alert-success">Course ID ' . $course_id . ' and all related data (including logo and slides) deleted successfully!</div>';
        } else {
            $_SESSION[$message_key] = '<div class="alert alert-danger">Error deleting course: ' . $conn->error . '</div>';
        }
        $stmt_delete->close();
    }
    
    // PRG Pattern: Redirect after action
    header('Location: manage_courses.php');
    exit;
}

// --- 4. Fetch All Courses for List View (with Quiz Count) ---
$courses = [];
$sql = "
    SELECT 
        c.course_id, 
        c.title, 
        c.description,
        c.course_image,
        c.slides_path,
        (SELECT COUNT(*) FROM quizzes q WHERE q.course_id = c.course_id) AS quiz_count
    FROM courses c
    ORDER BY c.course_id DESC
";
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row;
    }
    $result->free();
}

$conn->close();

// Helper function to fetch and clear session message
function get_session_message($key) {
    if (isset($_SESSION[$key])) {
        $message = $_SESSION[$key];
        unset($_SESSION[$key]);
        return $message;
    }
    return '';
}

require_once '../includes/header.php';
$message = get_session_message($message_key); // Get the message here
?>

<div class="container mt-5">
    <h2 class="mb-4 text-primary display-4 fw-bold"><i class="fas fa-chalkboard-teacher me-2"></i> Course Management</h2>

    <?php echo $message; ?>

    <div class="card shadow-lg mb-5 border-0">
        <div class="card-header bg-primary text-white py-3">
            <h4 class="mb-0"><i class="fas fa-edit me-2"></i> <?php echo $action; ?></h4>
        </div>
        <div class="card-body">
            <form action="manage_courses.php" method="POST" enctype="multipart/form-data"> 
                
                <?php if ($edit_course): ?>
                    <input type="hidden" name="course_id" value="<?php echo htmlspecialchars($edit_course['course_id']); ?>">
                    <input type="hidden" name="old_image_path" value="<?php echo $edit_course['course_image'] ? htmlspecialchars($edit_course['course_image']) : ''; ?>">
                    <input type="hidden" name="old_slides_path" value="<?php echo $edit_course['slides_path'] ? htmlspecialchars($edit_course['slides_path']) : ''; ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label for="title" class="form-label fw-bold">Course Title <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="title" name="title" 
                            value="<?php echo $edit_course ? htmlspecialchars($edit_course['title']) : ''; ?>" 
                            placeholder="e.g., Introduction to Web Development" required>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label fw-bold">Course Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" 
                            placeholder="A brief overview of the course content."><?php echo $edit_course ? htmlspecialchars($edit_course['description']) : ''; ?></textarea>
                </div>
                
                <div class="mb-4">
                    <label for="youtube_iframe_link" class="form-label fw-bold">YouTube Iframe Embed Link <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="youtube_iframe_link" name="youtube_iframe_link" rows="5" required
                            placeholder="Paste the full embed code starting with <iframe..."><?php echo $edit_course ? htmlspecialchars($edit_course['youtube_iframe_link']) : ''; ?></textarea>
                    <div class="form-text text-muted"><i class="fas fa-info-circle me-1"></i> Paste the full iframe embed code from YouTube's "Share > Embed" option.</div>
                </div>

                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="p-3 border rounded bg-light">
                            <label for="course_image" class="form-label fw-bold">
                                <i class="fas fa-image me-2"></i> Course Logo/Image (Max 2MB, JPG/PNG/WEBP)
                            </label>
                            <input type="file" class="form-control" id="course_image" name="course_image" accept=".jpg, .jpeg, .png, .webp">
                            
                            <?php if ($edit_course && $edit_course['course_image']): ?>
                                <div class="mt-3">
                                    <span class="text-success fw-bold me-2">Current Logo:</span>
                                    <img src="<?php echo '../' . htmlspecialchars($edit_course['course_image']); ?>" alt="Course Image" style="width: 100px; height: 60px; object-fit: cover; border-radius: 5px;">
                                    <span class="form-text text-muted d-block">Uploading a new file will replace the current one.</span>
                                </div>
                            <?php elseif ($edit_course): ?>
                                <div class="form-text text-warning">No logo currently set for this course.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="p-3 border rounded bg-light">
                            <label for="slides_file" class="form-label fw-bold">
                                <i class="fas fa-file-powerpoint me-2"></i> Course Slides (Max 10MB, PDF/PPT)
                            </label>
                            <input type="file" class="form-control" id="slides_file" name="slides_file" accept=".pdf,.ppt,.pptx">
                            
                            <?php if ($edit_course && $edit_course['slides_path']): ?>
                                <div class="mt-3">
                                    <span class="text-success fw-bold me-2">Current Slides:</span>
                                    <div class="d-flex align-items-center mt-2">
                                        <i class="fas fa-file-pdf fa-2x text-danger me-2"></i>
                                        <div>
                                            <a href="<?php echo '../' . htmlspecialchars($edit_course['slides_path']); ?>" 
                                               target="_blank" class="text-decoration-none">
                                                View Slides
                                            </a>
                                            <span class="form-text text-muted d-block">Uploading a new file will replace the current one.</span>
                                        </div>
                                    </div>
                                </div>
                            <?php elseif ($edit_course): ?>
                                <div class="form-text text-warning">No slides currently set for this course.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-<?php echo $edit_course ? 'warning' : 'success'; ?> btn-lg">
                    <i class="fas fa-save me-2"></i> <?php echo $edit_course ? 'Update Course' : 'Add New Course'; ?>
                </button>
                
                <?php if ($edit_course): ?>
                    <a href="manage_courses.php" class="btn btn-secondary btn-lg ms-2">
                        <i class="fas fa-times me-2"></i> Cancel Edit
                    </a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    
    <h3 class="mb-3 mt-5 text-secondary"><i class="fas fa-list-alt me-2"></i> Current Courses (<?php echo count($courses); ?>)</h3>
    <?php if (empty($courses)): ?>
        <div class="alert alert-info text-center shadow-sm">No courses found. Use the form above to add your first course.</div>
    <?php else: ?>
        <div class="table-responsive shadow-lg bg-white p-3 rounded">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th style="width: 5%;">ID</th>
                        <th style="width: 8%;">Logo</th>
                        <th style="width: 20%;">Title</th>
                        <th style="width: 25%;">Description Snippet</th>
                        <th style="width: 10%;" class="text-center">Quizzes</th>
                        <th style="width: 12%;" class="text-center">Slides</th>
                        <th style="width: 20%;" class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($course['course_id']); ?></td>
                            <td class="text-center">
                                <?php if ($course['course_image']): ?>
                                    <img src="<?php echo '../' . htmlspecialchars($course['course_image']); ?>" 
                                         alt="Logo" 
                                         style="width: 60px; height: 40px; object-fit: cover; border: 1px solid #ddd; border-radius: 3px;">
                                <?php else: ?>
                                    <i class="fas fa-image text-muted" title="No Image"></i>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold text-primary"><?php echo htmlspecialchars($course['title']); ?></td>
                            <td><?php 
                                $desc_snippet = htmlspecialchars($course['description']);
                                echo (strlen($desc_snippet) > 100) ? substr($desc_snippet, 0, 100) . '...' : $desc_snippet; 
                            ?></td>
                            <td class="text-center">
                                <span class="badge rounded-pill bg-<?php echo ($course['quiz_count'] >= 5) ? 'success' : 'danger'; ?> py-2 px-3 fs-6">
                                    <?php echo $course['quiz_count']; ?> / 10
                                </span>
                            </td>
                            <td class="text-center">
                                <?php if ($course['slides_path']): ?>
                                    <a href="<?php echo '../' . htmlspecialchars($course['slides_path']); ?>" 
                                       target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-file-download me-1"></i> Download
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">No Slides</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="manage_courses.php?action=edit&id=<?php echo $course['course_id']; ?>" class="btn btn-sm btn-primary mb-1 w-100">
                                    <i class="fas fa-edit me-1"></i> Edit Course
                                </a>
                                <a href="manage_quiz.php?course_id=<?php echo $course['course_id']; ?>" class="btn btn-sm btn-info mb-1 w-100 text-dark">
                                    <i class="fas fa-question-circle me-1"></i> Manage Quiz
                                </a>
                                <a href="manage_courses.php?action=delete&id=<?php echo $course['course_id']; ?>" 
                                   class="btn btn-sm btn-danger w-100"
                                   onclick="return confirm('CRITICAL WARNING: Are you sure you want to delete the course «<?php echo htmlspecialchars($course['title']); ?>»? All associated data (quizzes, student enrollments, progress, and the course image) will be permanently lost.')">
                                    <i class="fas fa-trash-alt me-1"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
[file content end]