<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_users.php");
    exit();
}

$student_id = (int)$_GET['id'];

// Handle POST for updating student
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);

    if (empty($name) || empty($email)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Check if email is unique (excluding current user)
        $checkQuery = "SELECT user_id FROM users WHERE email = :email AND user_id != :id";
        $checkStmt = $pdo->prepare($checkQuery);
        $checkStmt->execute([':email' => $email, ':id' => $student_id]);
        if ($checkStmt->fetch()) {
            $error = "Email is already in use by another user.";
        } else {
            $updateQuery = "UPDATE users SET name = :name, email = :email WHERE user_id = :id";
            $updateStmt = $pdo->prepare($updateQuery);
            $updateStmt->execute([':name' => $name, ':email' => $email, ':id' => $student_id]);
            $success = "Student updated successfully.";
            // Refresh student data
            $studentStmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :id AND user_type = 'student'");
            $studentStmt->execute([':id' => $student_id]);
            $student = $studentStmt->fetch();
        }
    }
}

// Get student basic information
$studentQuery = "SELECT * FROM users WHERE user_id = :id AND user_type = 'student'";
$studentStmt = $pdo->prepare($studentQuery);
$studentStmt->execute([':id' => $student_id]);
$student = $studentStmt->fetch();

if (!$student) {
    header("Location: manage_users.php");
    exit();
}

// Get student's enrolled courses with progress
$coursesQuery = "SELECT c.course_id, c.title, c.description,
                e.enrollment_date,
                p.video_progress_percentage, 
                p.quiz_score, 
                p.certificate_status
                FROM enrollments e
                JOIN courses c ON e.course_id = c.course_id
                LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
                WHERE e.student_id = :id
                ORDER BY e.enrollment_date DESC";

$coursesStmt = $pdo->prepare($coursesQuery);
$coursesStmt->execute([':id' => $student_id]);
$courses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate averages
$totalCourses = count($courses);
$avgVideoProgress = 0;
$avgQuizScore = 0;

if ($totalCourses > 0) {
    $totalVideoProgress = 0;
    $totalQuizScore = 0;
    $count = 0;
    
    foreach ($courses as $course) {
        if ($course['video_progress_percentage'] !== null) {
            $totalVideoProgress += $course['video_progress_percentage'];
            $count++;
        }
        if ($course['quiz_score'] !== null) {
            $totalQuizScore += $course['quiz_score'];
        }
    }
    
    $avgVideoProgress = $count > 0 ? $totalVideoProgress / $count : 0;
    $avgQuizScore = $totalCourses > 0 ? $totalQuizScore / $totalCourses : 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .progress-bar-custom {
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .certificate-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .certificate-approved {
            background-color: #28a745;
            color: white;
        }
        
        .certificate-pending {
            background-color: #ffc107;
            color: black;
        }
        
        .certificate-not-eligible {
            background-color: #6c757d;
            color: white;
        }
        
        .certificate-rejected {
            background-color: #dc3545;
            color: white;
        }
        
        .course-card {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <a href="manage_users.php" class="btn btn-secondary mb-3">
            <i class="fas fa-arrow-left me-1"></i> Back to Students
        </a>
        
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-user-graduate me-2"></i>
                    Edit Student Details: <?php echo htmlspecialchars($student['name']); ?>
                </h4>
            </div>
            
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Student Stats -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="stats-card">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo $totalCourses; ?></h3>
                                    <p class="mb-0">Enrolled Courses</p>
                                </div>
                                <div>
                                    <i class="fas fa-book fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="stats-card" style="background: linear-gradient(135deg, #4cc9f0 0%, #4361ee 100%);">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo number_format($avgVideoProgress, 1); ?>%</h3>
                                    <p class="mb-0">Avg Video Progress</p>
                                </div>
                                <div>
                                    <i class="fas fa-play-circle fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="stats-card" style="background: linear-gradient(135deg, #f8961e 0%, #e63946 100%);">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0"><?php echo number_format($avgQuizScore, 1); ?>%</h3>
                                    <p class="mb-0">Avg Quiz Score</p>
                                </div>
                                <div>
                                    <i class="fas fa-question-circle fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Personal Information Edit Form -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5><i class="fas fa-user-circle me-2"></i>Personal Information</h5>
                        <form method="POST">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="40%">Student ID</th>
                                    <td>#<?php echo $student['user_id']; ?></td>
                                </tr>
                                <tr>
                                    <th>Full Name</th>
                                    <td>
                                        <input type="text" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" class="form-control" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Email Address</th>
                                    <td>
                                        <input type="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>" class="form-control" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Account Type</th>
                                    <td>
                                        <span class="badge bg-primary">Student</span>
                                    </td>
                                </tr>
                            </table>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i> Save Changes
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Course Progress -->
                <h5><i class="fas fa-chart-line me-2"></i>Course Progress</h5>
                
                <?php if ($totalCourses > 0): ?>
                    <?php foreach ($courses as $course): ?>
                        <div class="course-card">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h6 class="mb-1"><?php echo htmlspecialchars($course['title']); ?></h6>
                                    <small class="text-muted">
                                        Enrolled on: <?php echo date('M d, Y', strtotime($course['enrollment_date'])); ?>
                                    </small>
                                </div>
                                <span class="certificate-badge certificate-<?php echo str_replace('_', '-', $course['certificate_status'] ?? 'not_eligible'); ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $course['certificate_status'] ?? 'not_eligible')); ?>
                                </span>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <small class="text-muted d-block mb-1">Video Progress:</small>
                                        <div class="d-flex align-items-center">
                                            <div class="progress progress-bar-custom" style="flex-grow: 1;">
                                                <div class="progress-bar bg-info" role="progressbar" 
                                                     style="width: <?php echo $course['video_progress_percentage'] ?? 0; ?>%;">
                                                </div>
                                            </div>
                                            <span class="ms-2" style="font-weight: 600;">
                                                <?php echo $course['video_progress_percentage'] ?? 0; ?>%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <small class="text-muted d-block mb-1">Quiz Score:</small>
                                        <div class="d-flex align-items-center">
                                            <div class="progress progress-bar-custom" style="flex-grow: 1;">
                                                <div class="progress-bar bg-success" role="progressbar" 
                                                     style="width: <?php echo $course['quiz_score'] ?? 0; ?>%;">
                                                </div>
                                            </div>
                                            <span class="ms-2" style="font-weight: 600;">
                                                <?php echo $course['quiz_score'] ?? 0; ?>%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if (!empty($course['description'])): ?>
                                <div class="mt-2">
                                    <small class="text-muted">Course Description:</small>
                                    <p class="mb-0" style="font-size: 0.9rem;">
                                        <?php echo nl2br(htmlspecialchars($course['description'])); ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        This student is not enrolled in any courses yet.
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="card-footer">
                <a href="manage_users.php" class="btn btn-secondary">
                    <i class="fas fa-users me-1"></i> Back to All Students
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>