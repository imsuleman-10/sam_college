<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';

if (!isAdminLoggedIn()) {
    http_response_code(403);
    echo "Access denied";
    exit();
}

if (!isset($_GET['student_id'])) {
    http_response_code(400);
    echo "Student ID required";
    exit();
}

$student_id = (int)$_GET['student_id'];

// Get student's enrolled courses with progress
$query = "SELECT c.course_id, c.title, e.enrollment_id, e.enrollment_date,
          p.video_progress_percentage, p.quiz_score, p.certificate_status
          FROM enrollments e
          JOIN courses c ON e.course_id = c.course_id
          LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
          WHERE e.student_id = :student_id
          ORDER BY e.enrollment_date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute([':student_id' => $student_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($courses)) {
    echo '<div class="alert alert-info text-center py-4">
            <i class="fas fa-info-circle fa-2x mb-3"></i>
            <h5>No Courses Enrolled</h5>
            <p class="mb-0 text-muted">This student is not enrolled in any courses yet.</p>
          </div>';
    exit();
}
?>

<?php foreach ($courses as $course): ?>
    <div class="course-item">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <h6 class="course-title mb-1"><?php echo htmlspecialchars($course['title']); ?></h6>
                <small class="text-muted">
                    <i class="far fa-calendar me-1"></i>
                    Enrolled on: <?php echo date('M d, Y', strtotime($course['enrollment_date'])); ?>
                </small>
            </div>
            
            <form method="POST" action="manage_users.php" style="display: inline;" 
                  onsubmit="return confirm('Are you sure you want to unenroll from this course?')">
                <input type="hidden" name="enrollment_id" value="<?php echo $course['enrollment_id']; ?>">
                <input type="hidden" name="student_name" value="<?php echo htmlspecialchars($_GET['student_name'] ?? ''); ?>">
                <input type="hidden" name="course_title" value="<?php echo htmlspecialchars($course['title']); ?>">
                <button type="submit" name="unenroll_course" class="unenroll-btn">
                    <i class="fas fa-user-minus"></i> Unenroll
                </button>
            </form>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <small class="text-muted d-block mb-1">Video Progress:</small>
                    <div class="d-flex align-items-center">
                        <div class="progress progress-bar-custom" style="flex-grow: 1;">
                            <div class="progress-bar bg-info" role="progressbar" 
                                 style="width: <?php echo $course['video_progress_percentage'] ?? 0; ?>%;">
                            </div>
                        </div>
                        <span class="ms-2 progress-text">
                            <?php echo $course['video_progress_percentage'] ?? 0; ?>%
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="mb-3">
                    <small class="text-muted d-block mb-1">Quiz Score:</small>
                    <div class="d-flex align-items-center">
                        <div class="progress progress-bar-custom" style="flex-grow: 1;">
                            <div class="progress-bar bg-success" role="progressbar" 
                                 style="width: <?php echo $course['quiz_score'] ?? 0; ?>%;">
                            </div>
                        </div>
                        <span class="ms-2 progress-text">
                            <?php echo $course['quiz_score'] ?? 0; ?>%
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <small class="text-muted">Certificate Status:</small>
                <span class="badge-certificate badge-<?php echo str_replace('_', '-', $course['certificate_status'] ?? 'not_eligible'); ?> ms-2">
                    <?php echo ucfirst(str_replace('_', ' ', $course['certificate_status'] ?? 'not_eligible')); ?>
                </span>
            </div>
            
            <form method="POST" action="manage_users.php" class="certificate-update-form d-flex align-items-center">
                <input type="hidden" name="student_id" value="<?php echo $student_id; ?>">
                <input type="hidden" name="course_id" value="<?php echo $course['course_id']; ?>">
                <select name="certificate_status" class="certificate-select me-2" style="width: auto;">
                    <option value="not_eligible" <?php echo ($course['certificate_status'] ?? 'not_eligible') == 'not_eligible' ? 'selected' : ''; ?>>Not Eligible</option>
                    <option value="pending" <?php echo ($course['certificate_status'] ?? 'not_eligible') == 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="approved" <?php echo ($course['certificate_status'] ?? 'not_eligible') == 'approved' ? 'selected' : ''; ?>>Approved</option>
                    <option value="rejected" <?php echo ($course['certificate_status'] ?? 'not_eligible') == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                </select>
                <button type="submit" name="update_certificate" class="btn btn-sm btn-primary">
                    <i class="fas fa-sync-alt"></i> Update
                </button>
            </form>
        </div>
    </div>
<?php endforeach; ?>