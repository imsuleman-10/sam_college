<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';

// Admin login check karo
if (!isAdminLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// Check if delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    
    // Check if user_id is provided
    if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
        $_SESSION['error_message'] = "Student ID not provided!";
        header("Location: manage_users.php");
        exit();
    }
    
    $student_id = (int)$_POST['user_id'];
    
    try {
        $pdo->beginTransaction();
        
        // First, get student name for success message
        $studentQuery = "SELECT name, email FROM users WHERE user_id = :id AND user_type = 'student'";
        $studentStmt = $pdo->prepare($studentQuery);
        $studentStmt->execute([':id' => $student_id]);
        $student = $studentStmt->fetch();
        
        if (!$student) {
            $pdo->rollBack();
            $_SESSION['error_message'] = "Student not found or already deleted!";
            header("Location: manage_users.php");
            exit();
        }
        
        $student_name = $student['name'];
        
        // Delete all related data in correct order (child tables first)
        $deleteQueries = [
            "DELETE FROM progress WHERE student_id = :id",
            "DELETE FROM enrollments WHERE student_id = :id",
            "DELETE FROM users WHERE user_id = :id AND user_type = 'student'"
        ];
        
        foreach ($deleteQueries as $deleteQuery) {
            $stmt = $pdo->prepare($deleteQuery);
            $stmt->execute([':id' => $student_id]);
            
            // Check if user deletion failed (last query)
            if ($deleteQuery === "DELETE FROM users WHERE user_id = :id AND user_type = 'student'") {
                if ($stmt->rowCount() === 0) {
                    $pdo->rollBack();
                    $_SESSION['error_message'] = "Failed to delete student account. It may not exist or is not a student.";
                    header("Location: manage_users.php");
                    exit();
                }
            }
        }
        
        $pdo->commit();
        $_SESSION['success_message'] = "Student '$student_name' deleted successfully!";
        
    } catch (PDOException $e) {
        // Rollback transaction on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error_message'] = "Error deleting student: " . $e->getMessage();
    }
    
    // Redirect back to manage_users.php
    header("Location: manage_users.php");
    exit();
    
} else {
    // If accessed directly without POST
    $_SESSION['error_message'] = "Invalid request method!";
    header("Location: manage_users.php");
    exit();
}
?>