<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';

// Admin login check
if (!isAdminLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// Pagination variables
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search functionality
$search = '';
$whereClause = "WHERE u.user_type = 'student'";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = trim($_GET['search']);
    $whereClause .= " AND (u.name LIKE :search OR u.email LIKE :search)";
}

// Total students count for pagination
$countQuery = "SELECT COUNT(*) as total FROM users u WHERE u.user_type = 'student'";
if (!empty($search)) {
    $countQuery .= " AND (u.name LIKE :search OR u.email LIKE :search)";
}

$stmt = $pdo->prepare($countQuery);
if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%");
}
$stmt->execute();
$totalStudents = $stmt->fetch()['total'];
$totalPages = ceil($totalStudents / $limit);

// Students data with progress
$query = "SELECT u.*, 
          COUNT(DISTINCT e.course_id) as enrolled_courses,
          AVG(p.video_progress_percentage) as avg_video_progress,
          AVG(p.quiz_score) as avg_quiz_score,
          GROUP_CONCAT(DISTINCT c.title SEPARATOR '||') as course_titles,
          GROUP_CONCAT(DISTINCT CONCAT(c.course_id, '::', c.title) SEPARATOR '||') as course_details
          FROM users u
          LEFT JOIN enrollments e ON u.user_id = e.student_id
          LEFT JOIN courses c ON e.course_id = c.course_id
          LEFT JOIN progress p ON u.user_id = p.student_id AND e.course_id = p.course_id
          $whereClause
          GROUP BY u.user_id
          ORDER BY u.user_id DESC
          LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%");
}
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Delete student ka action
if (isset($_POST['delete_user'])) {
    $user_id = (int)$_POST['user_id'];
    
    try {
        $pdo->beginTransaction();
        
        $deleteQueries = [
            "DELETE FROM progress WHERE student_id = :id",
            "DELETE FROM enrollments WHERE student_id = :id",
            "DELETE FROM users WHERE user_id = :id AND user_type = 'student'"
        ];
        
        foreach ($deleteQueries as $deleteQuery) {
            $stmt = $pdo->prepare($deleteQuery);
            $stmt->execute([':id' => $user_id]);
        }
        
        $pdo->commit();
        $_SESSION['success_message'] = "Student deleted successfully!";
        header("Location: manage_users.php");
        exit();
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error deleting student: " . $e->getMessage();
    }
}

// Unenroll action handle karo
if (isset($_POST['unenroll_course'])) {
    $enrollment_id = (int)$_POST['enrollment_id'];
    $student_name = $_POST['student_name'];
    $course_title = $_POST['course_title'];
    
    try {
        // Enrollment se student_id aur course_id get karo
        $getStmt = $pdo->prepare("SELECT student_id, course_id FROM enrollments WHERE enrollment_id = :eid");
        $getStmt->execute([':eid' => $enrollment_id]);
        $enrollment = $getStmt->fetch();
        
        if ($enrollment) {
            // Progress table se delete karo
            $progressStmt = $pdo->prepare("DELETE FROM progress WHERE student_id = :sid AND course_id = :cid");
            $progressStmt->execute([
                ':sid' => $enrollment['student_id'],
                ':cid' => $enrollment['course_id']
            ]);
            
            // Enrollments se delete karo
            $enrollmentStmt = $pdo->prepare("DELETE FROM enrollments WHERE enrollment_id = :eid");
            $enrollmentStmt->execute([':eid' => $enrollment_id]);
            
            $_SESSION['success_message'] = "Student '$student_name' has been unenrolled from '$course_title'";
        }
        
        header("Location: manage_users.php");
        exit();
        
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error unenrolling student: " . $e->getMessage();
        header("Location: manage_users.php");
        exit();
    }
}

// Certificate status update ka action
if (isset($_POST['update_certificate'])) {
    $student_id = (int)$_POST['student_id'];
    $course_id = (int)$_POST['course_id'];
    $certificate_status = $_POST['certificate_status'];
    
    try {
        // Check karo agar progress record hai ya nahi
        $checkStmt = $pdo->prepare("SELECT * FROM progress WHERE student_id = :sid AND course_id = :cid");
        $checkStmt->execute([':sid' => $student_id, ':cid' => $course_id]);
        
        if ($checkStmt->rowCount() > 0) {
            // Existing record update karo
            $updateStmt = $pdo->prepare("UPDATE progress SET certificate_status = :status WHERE student_id = :sid AND course_id = :cid");
            $updateStmt->execute([
                ':status' => $certificate_status,
                ':sid' => $student_id,
                ':cid' => $course_id
            ]);
        } else {
            // New record insert karo
            $insertStmt = $pdo->prepare("INSERT INTO progress (student_id, course_id, certificate_status) VALUES (:sid, :cid, :status)");
            $insertStmt->execute([
                ':sid' => $student_id,
                ':cid' => $course_id,
                ':status' => $certificate_status
            ]);
        }
        
        $_SESSION['success_message'] = "Certificate status updated successfully!";
        header("Location: manage_users.php");
        exit();
        
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error updating certificate status: " . $e->getMessage();
        header("Location: manage_users.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --warning-color: #f8961e;
            --danger-color: #e63946;
            --light-bg: #f8f9fa;
            --border-color: #dee2e6;
        }
        
        body {
            background-color: #f5f7fb;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .admin-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 1.5rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: white;
            border-bottom: 2px solid var(--primary-color);
            font-weight: 600;
            padding: 1rem 1.5rem;
        }
        
        .search-box {
            max-width: 400px;
        }
        
        .btn-custom {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            transition: background-color 0.3s ease;
        }
        
        .btn-custom:hover {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-danger-custom {
            background-color: var(--danger-color);
            color: white;
        }
        
        .table-responsive {
            border-radius: 8px;
            overflow: hidden;
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table thead {
            background-color: var(--primary-color);
            color: white;
        }
        
        .table th {
            border: none;
            padding: 1rem;
            font-weight: 600;
        }
        
        .table td {
            vertical-align: middle;
            padding: 1rem;
            border-color: var(--border-color);
        }
        
        .progress-bar-custom {
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-text {
            font-size: 0.8rem;
            font-weight: 600;
            min-width: 40px;
        }
        
        .badge-certificate {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            display: inline-block;
            margin-bottom: 2px;
        }
        
        .badge-approved {
            background-color: #28a745;
            color: white;
        }
        
        .badge-pending {
            background-color: #ffc107;
            color: black;
        }
        
        .badge-not-eligible {
            background-color: #6c757d;
            color: white;
        }
        
        .badge-rejected {
            background-color: #dc3545;
            color: white;
        }
        
        .alert {
            border-radius: 8px;
            border: none;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
        }
        
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            padding: 1.5rem;
        }
        
        .course-details-modal .modal-body {
            max-height: 500px;
            overflow-y: auto;
            padding: 20px;
        }
        
        .course-item {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            background-color: white;
            transition: box-shadow 0.2s ease;
        }
        
        .course-item:hover {
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        
        .course-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 10px;
            font-size: 1.1rem;
        }
        
        .unenroll-btn {
            background-color: var(--danger-color);
            color: white;
            border: none;
            padding: 6px 15px;
            border-radius: 4px;
            font-size: 0.8rem;
            transition: background-color 0.2s ease;
        }
        
        .unenroll-btn:hover {
            background-color: #c1121f;
        }
        
        .certificate-select {
            width: 100%;
            padding: 6px 10px;
            border-radius: 4px;
            border: 1px solid var(--border-color);
            font-size: 0.9rem;
        }
        
        .action-buttons .btn {
            margin-right: 5px;
            margin-bottom: 5px;
        }
        
        .no-data {
            color: #6c757d;
            font-style: italic;
        }
        
        .modal-backdrop {
            opacity: 0.5 !important;
        }
        
        .modal.fade .modal-dialog {
            transform: translate(0, 0) !important;
            transition: transform 0.3s ease-out;
        }
        
        /* Blinking issue fix */
        .modal {
            overflow-y: auto;
            padding-right: 0 !important;
        }
        
        .modal-open {
            overflow: auto;
            padding-right: 0 !important;
        }
        
        .modal-dialog {
            margin: 30px auto;
        }
        
        .modal-content {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        
        body.modal-open {
            padding-right: 0 !important;
        }
        
        .modal {
            padding-left: 0 !important;
        }
    </style>
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="fas fa-users-cog me-2"></i>Student Management</h2>
                    <p class="mb-0">Manage all registered students in the system</p>
                </div>
                <div>
                    <a href="dashboard.php" class="btn btn-light me-2">
                        <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                    </a>
                    <a href="../logout.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Stats Card -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0"><?php echo $totalStudents; ?></h3>
                            <p class="mb-0">Total Students</p>
                        </div>
                        <div class="stats-icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Card -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-list me-2"></i>Students List
                </h5>
                
                <!-- Search Form -->
                <form method="GET" class="d-flex search-box">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" 
                               placeholder="Search by name or email..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-custom" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                        <?php if (!empty($search)): ?>
                            <a href="manage_users.php" class="btn btn-outline-secondary">
                                <i class="fas fa-times"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="card-body">
                <?php if (empty($students)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                        <h4>No students found</h4>
                        <p class="text-muted">
                            <?php echo empty($search) ? 'No students registered yet.' : 'No students match your search.'; ?>
                        </p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Student Name</th>
                                    <th>Email</th>
                                    <th>Enrolled Courses</th>
                                    <th>Quiz Score (%)</th>
                                    <th>Video Progress (%)</th>
                                    <th>Certificate Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($students as $student): 
                                    // Course data parse karo
                                    $course_titles = !empty($student['course_titles']) ? explode('||', $student['course_titles']) : [];
                                    $course_details = !empty($student['course_details']) ? explode('||', $student['course_details']) : [];
                                    
                                    // Student ke detailed course information get karo
                                    $courseDetailsQuery = "SELECT c.course_id, c.title, e.enrollment_id, e.enrollment_date,
                                                          p.video_progress_percentage, p.quiz_score, p.certificate_status
                                                          FROM enrollments e
                                                          JOIN courses c ON e.course_id = c.course_id
                                                          LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
                                                          WHERE e.student_id = :student_id
                                                          ORDER BY e.enrollment_date DESC";
                                    $courseStmt = $pdo->prepare($courseDetailsQuery);
                                    $courseStmt->execute([':student_id' => $student['user_id']]);
                                    $studentCourses = $courseStmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    // Certificate status summary calculate karo
                                    $certificate_counts = [
                                        'approved' => 0,
                                        'pending' => 0,
                                        'not_eligible' => 0,
                                        'rejected' => 0
                                    ];
                                    
                                    foreach ($studentCourses as $course) {
                                        $status = $course['certificate_status'] ?? 'not_eligible';
                                        if (isset($certificate_counts[$status])) {
                                            $certificate_counts[$status]++;
                                        }
                                    }
                                ?>
                                    <tr>
                                        <td>#<?php echo $student['user_id']; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                                        </td>
                                        <td>
                                            <a href="mailto:<?php echo $student['email']; ?>" class="text-decoration-none">
                                                <?php echo htmlspecialchars($student['email']); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <?php if ($student['enrolled_courses'] > 0): ?>
                                                <span class="badge bg-primary rounded-pill">
                                                    <?php echo $student['enrolled_courses']; ?> course(s)
                                                </span>
                                                <button type="button" class="btn btn-sm btn-outline-primary ms-2 view-courses-btn" 
                                                        data-student-id="<?php echo $student['user_id']; ?>"
                                                        data-student-name="<?php echo htmlspecialchars($student['name']); ?>">
                                                    <i class="fas fa-eye"></i> View
                                                </button>
                                            <?php else: ?>
                                                <span class="badge bg-secondary rounded-pill">Not enrolled</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($student['avg_quiz_score'] !== null): ?>
                                                <div class="d-flex align-items-center">
                                                    <div class="progress progress-bar-custom" style="width: 80px;">
                                                        <div class="progress-bar bg-success" role="progressbar" 
                                                             style="width: <?php echo min(100, $student['avg_quiz_score']); ?>%;"
                                                             aria-valuenow="<?php echo $student['avg_quiz_score']; ?>" 
                                                             aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <span class="ms-2 progress-text">
                                                        <?php echo number_format($student['avg_quiz_score'], 1); ?>%
                                                    </span>
                                                </div>
                                            <?php else: ?>
                                                <span class="no-data">No data</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($student['avg_video_progress'] !== null): ?>
                                                <div class="d-flex align-items-center">
                                                    <div class="progress progress-bar-custom" style="width: 80px;">
                                                        <div class="progress-bar bg-info" role="progressbar" 
                                                             style="width: <?php echo min(100, $student['avg_video_progress']); ?>%;"
                                                             aria-valuenow="<?php echo $student['avg_video_progress']; ?>" 
                                                             aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <span class="ms-2 progress-text">
                                                        <?php echo number_format($student['avg_video_progress'], 1); ?>%
                                                    </span>
                                                </div>
                                            <?php else: ?>
                                                <span class="no-data">No data</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php 
                                            $hasCertificates = false;
                                            foreach ($certificate_counts as $status => $count):
                                                if ($count > 0):
                                                    $hasCertificates = true;
                                                    $badge_class = 'badge-' . str_replace('_', '-', $status);
                                            ?>
                                                <span class="badge-certificate <?php echo $badge_class; ?> me-1 mb-1 d-inline-block">
                                                    <?php echo ucfirst(str_replace('_', ' ', $status)) . ' (' . $count . ')'; ?>
                                                </span>
                                            <?php 
                                                endif;
                                            endforeach; 
                                            if (!$hasCertificates): ?>
                                                <span class="no-data">No certificates</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="action-buttons">
                                            <a href="view_student.php?id=<?php echo $student['user_id']; ?>" 
                                               class="btn btn-sm btn-outline-primary" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit_student.php?id=<?php echo $student['user_id']; ?>" 
                                               class="btn btn-sm btn-outline-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-outline-danger delete-student-btn" 
                                                    data-student-id="<?php echo $student['user_id']; ?>"
                                                    data-student-name="<?php echo htmlspecialchars($student['name']); ?>"
                                                    data-enrolled-courses="<?php echo $student['enrolled_courses']; ?>"
                                                    title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                </li>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <div class="card-footer text-muted">
                <div class="row">
                    <div class="col-md-6">
                        Showing <?php echo ($offset + 1); ?> to <?php echo min($offset + $limit, $totalStudents); ?> of <?php echo $totalStudents; ?> students
                    </div>
                    <div class="col-md-6 text-end">
                        <a href="add_student.php" class="btn btn-custom">
                            <i class="fas fa-user-plus me-1"></i> Add New Student
                        </a>
                        <!-- Excel Export ka button REMOVE ho gaya hai -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Courses Modal (Single for all students) -->
    <div class="modal fade" id="coursesModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-book me-2"></i>
                        <span id="modalStudentName"></span> - Enrolled Courses
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="coursesModalBody">
                    <!-- Courses AJAX se load hongay -->
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-3">Loading courses...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal (Single for all students) -->
    <!-- Delete Confirmation Modal (Single for all students) -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="delete_student_action.php" id="deleteForm">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Confirm Delete
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete student <strong id="deleteStudentName"></strong>?</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Warning:</strong> This action will permanently delete:
                        <ul class="mt-2 mb-0">
                            <li>Student account</li>
                            <li id="deleteCourseCount">All course enrollments</li>
                            <li>Progress and quiz data</li>
                        </ul>
                        <p class="mt-2 mb-0"><small>This action cannot be undone!</small></p>
                    </div>
                    <input type="hidden" name="user_id" id="deleteStudentId">
                    <input type="hidden" name="delete_user" value="1">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger-custom">
                        <i class="fas fa-trash me-1"></i> Delete Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
<script>
    // Global variables for modal instances
    let coursesModal = null;
    let deleteModal = null;
    
    // Blinking issue ka fix - SIMPLIFIED VERSION
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize modals once
        const coursesModalElement = document.getElementById('coursesModal');
        const deleteModalElement = document.getElementById('deleteModal');
        
        if (coursesModalElement) {
            coursesModal = new bootstrap.Modal(coursesModalElement, {
                backdrop: 'static',
                keyboard: true
            });
        }
        
        if (deleteModalElement) {
            deleteModal = new bootstrap.Modal(deleteModalElement, {
                backdrop: 'static',
                keyboard: true
            });
        }
        
        // Simple modal scrolling fix
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('show.bs.modal', function () {
                document.body.style.overflow = 'hidden';
                document.body.style.paddingRight = '0px';
            });
            
            modal.addEventListener('hidden.bs.modal', function () {
                document.body.style.overflow = 'auto';
                document.body.style.paddingRight = '';
                
                // Reset courses modal content
                if (this.id === 'coursesModal') {
                    const modalBody = document.getElementById('coursesModalBody');
                    if (modalBody) {
                        modalBody.innerHTML = `
                            <div class="text-center py-5">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <p class="mt-3">Loading courses...</p>
                            </div>
                        `;
                    }
                }
            });
        });
    });

    // View Courses Button ka handler - EVENT DELEGATION USE KARO
    document.addEventListener('click', function(e) {
        // Check if clicked element is view-courses-btn or its child
        const viewCoursesBtn = e.target.closest('.view-courses-btn');
        if (viewCoursesBtn) {
            e.preventDefault();
            
            const studentId = viewCoursesBtn.getAttribute('data-student-id');
            const studentName = viewCoursesBtn.getAttribute('data-student-name');
            
            // Modal title set karo
            document.getElementById('modalStudentName').textContent = studentName;
            
            // Hide any other open modals first
            if (deleteModal) {
                deleteModal.hide();
            }
            
            // Show courses modal
            if (coursesModal) {
                coursesModal.show();
                
                // AJAX se courses load karo
                loadStudentCourses(studentId);
            }
        }
    });

    // AJAX se student courses load karo
    function loadStudentCourses(studentId) {
        const modalBody = document.getElementById('coursesModalBody');
        if (!modalBody) return;
        
        modalBody.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3">Loading courses...</p>
            </div>
        `;
        
        // AJAX request create karo
        const xhr = new XMLHttpRequest();
        xhr.open('GET', `get_student_courses.php?student_id=${studentId}`, true);
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                modalBody.innerHTML = xhr.responseText;
                
                // Unenroll buttons ke event listeners attach karo
                attachUnenrollListeners();
                attachCertificateUpdateListeners();
            } else {
                modalBody.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        Error loading courses. Please try again.
                    </div>
                `;
            }
        };
        
        xhr.onerror = function() {
            modalBody.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    Network error. Please check your connection.
                </div>
            `;
        };
        
        xhr.send();
    }

    // Delete Student Button ka handler - EVENT DELEGATION USE KARO
    document.addEventListener('click', function(e) {
        // Check if clicked element is delete-student-btn or its child
        const deleteBtn = e.target.closest('.delete-student-btn');
        if (deleteBtn) {
            e.preventDefault();
            
            const studentId = deleteBtn.getAttribute('data-student-id');
            const studentName = deleteBtn.getAttribute('data-student-name');
            const enrolledCourses = deleteBtn.getAttribute('data-enrolled-courses');
            
            // Modal content set karo
            const deleteStudentName = document.getElementById('deleteStudentName');
            const deleteStudentId = document.getElementById('deleteStudentId');
            const deleteCourseCount = document.getElementById('deleteCourseCount');
            
            if (deleteStudentName) deleteStudentName.textContent = studentName;
            if (deleteStudentId) deleteStudentId.value = studentId;
            
            if (deleteCourseCount) {
                // Plural/singular text handle karo
                const courseText = enrolledCourses == 1 ? '1 course' : `${enrolledCourses} courses`;
                deleteCourseCount.textContent = `All course enrollments (${courseText})`;
            }
            
            // Hide any other open modals first
            if (coursesModal) {
                coursesModal.hide();
            }
            
            // Show delete modal
            if (deleteModal) {
                deleteModal.show();
            }
        }
    });

    // Unenroll buttons ke event listeners - EVENT DELEGATION USE KARO
    function attachUnenrollListeners() {
        const coursesModalBody = document.getElementById('coursesModalBody');
        if (!coursesModalBody) return;
        
        coursesModalBody.addEventListener('click', function(e) {
            const unenrollBtn = e.target.closest('.unenroll-btn');
            if (unenrollBtn) {
                if (!confirm('Are you sure you want to unenroll this student from the course?')) {
                    e.preventDefault();
                }
            }
        });
    }

    // Certificate update forms ke event listeners - EVENT DELEGATION USE KARO
    function attachCertificateUpdateListeners() {
        const coursesModalBody = document.getElementById('coursesModalBody');
        if (!coursesModalBody) return;
        
        coursesModalBody.addEventListener('submit', function(e) {
            const form = e.target.closest('.certificate-update-form');
            if (form) {
                const select = form.querySelector('.certificate-select');
                if (select) {
                    const currentStatus = select.options[select.selectedIndex].text;
                    
                    if (!confirm(`Change certificate status to "${currentStatus}"?`)) {
                        e.preventDefault();
                    }
                }
            }
        });
    }

    // Search form clear button functionality
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.querySelector('input[name="search"]');
        const clearButton = document.querySelector('a[href="manage_users.php"]');
        
        if (searchInput && clearButton) {
            // Agar search input empty hai to clear button hide karo
            if (!searchInput.value.trim()) {
                clearButton.style.display = 'none';
            }
            
            // Jab bhi search input change ho, clear button show/hide karo
            searchInput.addEventListener('input', function() {
                if (this.value.trim()) {
                    clearButton.style.display = 'block';
                } else {
                    clearButton.style.display = 'none';
                }
            });
        }
    });

    // Alerts ko auto dismiss karo - SIMPLE VERSION
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                const closeBtn = alert.querySelector('.btn-close');
                if (closeBtn) {
                    closeBtn.click();
                }
            });
        }, 5000);
    });

    // Prevent multiple form submissions for delete form
    document.addEventListener('submit', function(e) {
        const deleteForm = e.target.closest('#deleteForm');
        if (deleteForm) {
            const submitBtn = deleteForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Deleting...';
            }
        }
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Escape key se modal close karo
        if (e.key === 'Escape') {
            if (coursesModal) {
                coursesModal.hide();
            }
            if (deleteModal) {
                deleteModal.hide();
            }
        }
    });

    // Simple mobile adjustments
    function adjustForMobile() {
        if (window.innerWidth < 768) {
            document.querySelectorAll('.action-buttons .btn').forEach(btn => {
                btn.innerHTML = btn.innerHTML.replace(/<i[^>]*><\/i>\s*/g, '');
            });
        }
    }
    
    window.addEventListener('resize', adjustForMobile);
    document.addEventListener('DOMContentLoaded', adjustForMobile);
</script>
</body>
</html>