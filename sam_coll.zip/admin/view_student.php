<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_users.php");
    exit();
}

$student_id = (int)$_GET['id'];

// Get student details with progress information
$query = "SELECT u.*, 
          p.video_progress_percentage, 
          p.quiz_score, 
          p.certificate_status,
          c.title as course_title,
          COUNT(e.course_id) as total_courses
          FROM users u
          LEFT JOIN enrollments e ON u.user_id = e.student_id
          LEFT JOIN progress p ON u.user_id = p.student_id AND e.course_id = p.course_id
          LEFT JOIN courses c ON e.course_id = c.course_id
          WHERE u.user_id = :id AND u.user_type = 'student'
          GROUP BY u.user_id, e.course_id";

$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $student_id]);
$studentData = $stmt->fetchAll();

if (empty($studentData)) {
    header("Location: manage_users.php");
    exit();
}

$student = $studentData[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container mt-4">
        <a href="manage_users.php" class="btn btn-secondary mb-3">
            <i class="fas fa-arrow-left me-1"></i> Back to Students
        </a>
        
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <i class="fas fa-user-graduate me-2"></i>
                    Student Details: <?php echo htmlspecialchars($student['name']); ?>
                </h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Personal Information</h5>
                        <table class="table table-bordered">
                            <tr>
                                <th width="40%">Student ID</th>
                                <td>#<?php echo $student['user_id']; ?></td>
                            </tr>
                            <tr>
                                <th>Full Name</th>
                                <td><?php echo htmlspecialchars($student['name']); ?></td>
                            </tr>
                            <tr>
                                <th>Email Address</th>
                                <td>
                                    <a href="mailto:<?php echo $student['email']; ?>">
                                        <?php echo htmlspecialchars($student['email']); ?>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>Account Type</th>
                                <td>
                                    <span class="badge bg-primary">Student</span>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="col-md-6">
                        <h5>Course Progress</h5>
                        <?php if ($student['total_courses'] > 0): ?>
                            <div class="list-group">
                                <?php foreach ($studentData as $data): ?>
                                    <?php if (!empty($data['course_title'])): ?>
                                        <div class="list-group-item">
                                            <h6><?php echo htmlspecialchars($data['course_title']); ?></h6>
                                            <div class="progress mb-2" style="height: 20px;">
                                                <div class="progress-bar" role="progressbar" 
                                                     style="width: <?php echo $data['video_progress_percentage']; ?>%;"
                                                     aria-valuenow="<?php echo $data['video_progress_percentage']; ?>" 
                                                     aria-valuemin="0" aria-valuemax="100">
                                                    <?php echo $data['video_progress_percentage']; ?>%
                                                </div>
                                            </div>
                                            <small class="text-muted">
                                                Quiz Score: <?php echo $data['quiz_score']; ?>% | 
                                                Certificate: 
                                                <span class="badge 
                                                    <?php echo $data['certificate_status'] == 'approved' ? 'bg-success' : 
                                                          ($data['certificate_status'] == 'pending' ? 'bg-warning' : 'bg-secondary'); ?>">
                                                    <?php echo ucfirst(str_replace('_', ' ', $data['certificate_status'])); ?>
                                                </span>
                                            </small>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No courses enrolled yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="edit_student.php?id=<?php echo $student['user_id']; ?>" class="btn btn-warning">
                    <i class="fas fa-edit me-1"></i> Edit Student
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>