<?php
session_start();
// Security check: Ensure user is logged in and is an Admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$page_title = 'Add New Course';
require_once '../includes/header.php'; // Include header with Bootstrap

$title = $description = $youtube_iframe_link = '';
$title_err = $link_err = '';
$message = '';

// --- Configuration for File Upload ---
const UPLOAD_SLIDES_DIR = '../uploads/course_slides/';
const ALLOWED_SLIDES_TYPES = ['application/pdf', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];
const MAX_SLIDES_SIZE = 10 * 1024 * 1024; // 10MB

// Ensure upload directory exists
if (!is_dir(UPLOAD_SLIDES_DIR)) {
    mkdir(UPLOAD_SLIDES_DIR, 0777, true);
}

// Processing form data when form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. Validate Title
    if (empty(trim($_POST['title']))) {
        $title_err = 'Please enter a course title.';
    } else {
        $title = trim($_POST['title']);
    }

    // 2. Validate YouTube Iframe Link (must contain "iframe")
    $youtube_iframe_link = trim($_POST['youtube_iframe_link']);
    if (empty($youtube_iframe_link)) {
        $link_err = 'Please paste the full YouTube embed/iframe code.';
    } elseif (strpos($youtube_iframe_link, '<iframe') === false || strpos($youtube_iframe_link, 'youtube.com') === false) {
        $link_err = 'The input must be the full YouTube IFRAME embed code.';
    }

    $description = trim($_POST['description']);
    $slides_path = null;

    // 3. Handle Slides File Upload
    if (isset($_FILES['slides_file']) && $_FILES['slides_file']['error'] === UPLOAD_ERR_OK) {
        $slides_file = $_FILES['slides_file'];
        
        // Validate file size
        if ($slides_file['size'] > MAX_SLIDES_SIZE) {
            $message = '<div class="alert alert-danger">Error: Slides file is too large (max 10MB).</div>';
        }
        // Validate file type
        elseif (!in_array($slides_file['type'], ALLOWED_SLIDES_TYPES)) {
            $message = '<div class="alert alert-danger">Error: Only PDF and PowerPoint files are allowed for slides.</div>';
        }
        else {
            // Create unique filename
            $ext = pathinfo($slides_file['name'], PATHINFO_EXTENSION);
            $slides_filename = uniqid('slides_', true) . '.' . strtolower($ext);
            $destination = UPLOAD_SLIDES_DIR . $slides_filename;
            
            // Move uploaded file
            if (move_uploaded_file($slides_file['tmp_name'], $destination)) {
                // Store path relative to root for database
                $slides_path = 'uploads/course_slides/' . $slides_filename;
            } else {
                $message = '<div class="alert alert-danger">Error uploading slides file.</div>';
            }
        }
    }

    // Check input errors before inserting into database
    if (empty($title_err) && empty($link_err) && empty($message)) {
        
        // Prepare an insert statement
        $sql = "INSERT INTO courses (title, description, youtube_iframe_link, slides_path) VALUES (?, ?, ?, ?)";
        
        if ($stmt = $conn->prepare($sql)) {
            // Bind parameters
            $stmt->bind_param("ssss", $param_title, $param_description, $param_link, $param_slides);
            
            // Set parameters
            $param_title = $title;
            $param_description = $description;
            // Clean up the iframe link to ensure it's valid HTML
            $param_link = htmlspecialchars($youtube_iframe_link);
            $param_slides = $slides_path;
            
            // Execute the statement
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Course **' . htmlspecialchars($title) . '** added successfully!</div>';
                // Reset form fields
                $title = $description = $youtube_iframe_link = '';
            } else {
                $message = '<div class="alert alert-danger">Error: Could not add course. Please try again.</div>';
            }

            $stmt->close();
        }
    }
    $conn->close();
}
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-plus-circle text-primary"></i> Add New Course</h2>
        <a href="manage_courses.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Courses
        </a>
    </div>

    <?php echo $message; ?>

    <div class="card shadow-lg mb-5">
        <div class="card-body p-4">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="title" class="form-label fw-bold">Course Title</label>
                    <input type="text" name="title" id="title" 
                        class="form-control <?php echo (!empty($title_err)) ? 'is-invalid' : ''; ?>" 
                        value="<?php echo htmlspecialchars($title); ?>" required>
                    <span class="invalid-feedback"><?php echo $title_err; ?></span>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label fw-bold">Course Description</label>
                    <textarea name="description" id="description" class="form-control" rows="4" 
                        placeholder="Provide a detailed summary of the course content..."><?php echo htmlspecialchars($description); ?></textarea>
                </div>
                
                <hr>

                <!-- <div class="mb-3">
                    <label for="youtube_iframe_link" class="form-label fw-bold text-danger">YouTube Iframe Embed Code</label>
                    <textarea name="youtube_iframe_link" id="youtube_iframe_link" 
                        class="form-control <?php echo (!empty($link_err)) ? 'is-invalid' : ''; ?>" rows="4" 
                        placeholder='Paste the full embed code starting with <iframe...> here...' required><?php echo htmlspecialchars($youtube_iframe_link); ?></textarea>
                    <span class="invalid-feedback"><?php echo $link_err; ?></span>
                    <small class="form-text text-muted">
                        Get this code by clicking 'Share' -> 'Embed' on any YouTube video. **Example:** `<iframe width="560" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="..." frameborder="0" allowfullscreen></iframe>`
                    </small>
                </div> -->

                <div class="mb-4">
                    <label for="slides_file" class="form-label fw-bold text-primary">
                        <i class="fas fa-file-powerpoint me-1"></i> Course Slides (PDF/PPT)
                    </label>
                    <input type="file" name="slides_file" id="slides_file" 
                        class="form-control" accept=".pdf,.ppt,.pptx">
                    <small class="form-text text-muted">
                        Upload course slides (PDF or PowerPoint). Maximum file size: 10MB
                    </small>
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save me-2"></i> Save Course
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
[file content end]