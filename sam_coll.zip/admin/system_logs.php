<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php'; // Log function ke liye zaroori

// Admin login check
if (!isAdminLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// -----------------------------------------------------------
// FILTERS AUR PAGINATION LOGIC
// -----------------------------------------------------------

$limit = 20; // Har page par 20 logs dikhayenge
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filter Variables
$search_term = $_GET['search'] ?? '';
$user_type_filter = $_GET['user_type'] ?? '';
$action_filter = $_GET['action'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build WHERE Clause and Parameters
$where_clauses = [];
$params = [];

if (!empty($search_term)) {
    // Search by user_id, action, ya details
    $where_clauses[] = "(l.user_id = :search_id OR l.action LIKE :search_term OR l.details LIKE :search_term OR u.name LIKE :search_term_name)";
    $params[':search_id'] = is_numeric($search_term) ? (int)$search_term : 0;
    $params[':search_term'] = "%" . $search_term . "%";
    $params[':search_term_name'] = "%" . $search_term . "%";
}

if (!empty($user_type_filter)) {
    $where_clauses[] = "l.user_type = :user_type";
    $params[':user_type'] = $user_type_filter;
}

if (!empty($action_filter)) {
    $where_clauses[] = "l.action = :action_filter";
    $params[':action_filter'] = $action_filter;
}

if (!empty($date_from)) {
    $where_clauses[] = "DATE(l.timestamp) >= :date_from";
    $params[':date_from'] = $date_from;
}

if (!empty($date_to)) {
    $where_clauses[] = "DATE(l.timestamp) <= :date_to";
    $params[':date_to'] = $date_to;
}

$where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

// 1. Total Count for Pagination
$countQuery = "SELECT COUNT(*) as total FROM system_logs l LEFT JOIN users u ON l.user_id = u.user_id " . $where_sql;
$stmt = $pdo->prepare($countQuery);
$stmt->execute($params);
$totalLogs = $stmt->fetch()['total'];



$totalPages = ceil($totalLogs / $limit);

// 2. Fetch Log Data
$logQuery = "
    SELECT 
        l.*, 
        u.name AS user_name,
        u.email AS user_email
    FROM 
        system_logs l
    LEFT JOIN 
        users u ON l.user_id = u.user_id
    " . $where_sql . "
    ORDER BY 
        l.timestamp DESC
    LIMIT :limit OFFSET :offset
";

$stmt = $pdo->prepare($logQuery);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

// Parameters ko bind karna
foreach ($params as $key => $value) {
    // Integer values (jaise user_id) aur string values ko alag-alag bind karna
    $pdo_type = (strpos($key, ':search_id') !== false) ? PDO::PARAM_INT : PDO::PARAM_STR;
    $stmt->bindValue($key, $value, $pdo_type);
}
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique user types and actions for filter dropdowns
$userTypesStmt = $pdo->query("SELECT DISTINCT user_type FROM system_logs ORDER BY user_type");
$availableUserTypes = $userTypesStmt->fetchAll(PDO::FETCH_COLUMN);

$actionsStmt = $pdo->query("SELECT DISTINCT action FROM system_logs ORDER BY action");
$availableActions = $actionsStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Logs - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
        }
        body { background-color: #f5f7fb; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .admin-header { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 1.5rem 0; margin-bottom: 2rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08); }
        .card-header { background-color: white; border-bottom: 2px solid var(--primary-color); font-weight: 600; padding: 1rem 1.5rem; }
        .log-table th { font-size: 0.9rem; text-transform: uppercase; }
        .log-table td { font-size: 0.85rem; }
        .log-details-col { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .btn-custom { background-color: var(--primary-color); color: white; border: none; transition: background-color 0.3s ease; }
        .btn-custom:hover { background-color: var(--secondary-color); color: white; }
        .log-filter-form .form-control, .log-filter-form .form-select { height: 38px; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="fas fa-file-invoice me-2"></i>System Activity Logs</h2>
                    <p class="mb-0">Audit records of user and system events.</p>
                </div>
                <div>
                    <a href="manage_users.php" class="btn btn-light me-2">
                        <i class="fas fa-users me-1"></i> Manage Students
                    </a>
                    <a href="../logout.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                System Log Entries (Total: <?php echo $totalLogs; ?>)
            </div>
            <div class="card-body">
                <form method="GET" class="row g-2 mb-4 log-filter-form align-items-end">
                    <div class="col-md-3">
                        <label for="search" class="form-label visually-hidden">Search</label>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Search ID, Name, Action, or Details" value="<?php echo htmlspecialchars($search_term); ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="user_type" class="form-label visually-hidden">User Type</label>
                        <select class="form-select" id="user_type" name="user_type">
                            <option value="">All Users</option>
                            <?php foreach ($availableUserTypes as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>" <?php echo $user_type_filter === $type ? 'selected' : ''; ?>>
                                    <?php echo ucfirst($type); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="action" class="form-label visually-hidden">Action</label>
                        <select class="form-select" id="action" name="action">
                            <option value="">All Actions</option>
                            <?php foreach ($availableActions as $action): ?>
                                <option value="<?php echo htmlspecialchars($action); ?>" <?php echo $action_filter === $action ? 'selected' : ''; ?>>
                                    <?php echo str_replace('_', ' ', ucfirst(strtolower($action))); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="date_from" class="form-label visually-hidden">Date From</label>
                        <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" title="Date From">
                    </div>
                    <div class="col-md-1">
                        <button type="submit" class="btn btn-custom w-100">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                    </div>
                    <div class="col-md-2">
                        <a href="system_logs.php" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-sync-alt"></i> Reset
                        </a>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover log-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Timestamp</th>
                                <th>Action Type</th>
                                <th>User (ID)</th>
                                <th>User Type</th>
                                <th>Details</th>
                                <th>IP Address</th>
                                <th><i class="fas fa-cogs"></i></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($totalLogs > 0): ?>
                                <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($log['log_id']); ?></td>
                                        <td><?php echo date('Y-m-d H:i:s', strtotime($log['timestamp'])); ?></td>
                                        <td><span class="badge bg-info text-white"><?php echo htmlspecialchars($log['action']); ?></span></td>
                                        <td>
                                            <?php if ($log['user_name']): ?>
                                                <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($log['user_name']); ?>
                                                (<?php echo htmlspecialchars($log['user_id']); ?>)
                                            <?php else: ?>
                                                System
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars(ucfirst($log['user_type'])); ?></td>
                                        <td class="log-details-col" title="<?php echo htmlspecialchars($log['details']); ?>">
                                            <?php echo htmlspecialchars($log['details']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#logDetailModal"
                                                    data-details="<?php echo htmlspecialchars($log['details']); ?>"
                                                    data-action="<?php echo htmlspecialchars($log['action']); ?>"
                                                    data-timestamp="<?php echo date('Y-m-d H:i:s', strtotime($log['timestamp'])); ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">No system logs found matching the current criteria.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mt-3">
                            <?php 
                                // URL parameters ko dubara set karne ke liye
                                $filter_params = http_build_query([
                                    'search' => $search_term,
                                    'user_type' => $user_type_filter,
                                    'action' => $action_filter,
                                    'date_from' => $date_from,
                                    'date_to' => $date_to,
                                ]);
                            ?>
                            
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?>&<?php echo $filter_params; ?>">Previous</a>
                            </li>

                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo $page === $i ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&<?php echo $filter_params; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>

                            <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?>&<?php echo $filter_params; ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <div class="modal fade" id="logDetailModal" tabindex="-1" aria-labelledby="logDetailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logDetailModalLabel"><i class="fas fa-info-circle me-1"></i> Log Detail</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <dl class="row">
                        <dt class="col-sm-3">Action:</dt>
                        <dd class="col-sm-9" id="modalAction"></dd>
                        
                        <dt class="col-sm-3">Timestamp:</dt>
                        <dd class="col-sm-9" id="modalTimestamp"></dd>
                        
                        <dt class="col-sm-3">Details (Raw):</dt>
                        <dd class="col-sm-9"><pre class="bg-light p-2 rounded" id="modalDetails"></pre></dd>
                    </dl>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const logDetailModal = document.getElementById('logDetailModal');
            if (logDetailModal) {
                logDetailModal.addEventListener('show.bs.modal', function (event) {
                    const button = event.relatedTarget;
                    const details = button.getAttribute('data-details');
                    const action = button.getAttribute('data-action');
                    const timestamp = button.getAttribute('data-timestamp');

                    const modalDetails = logDetailModal.querySelector('#modalDetails');
                    const modalAction = logDetailModal.querySelector('#modalAction');
                    const modalTimestamp = logDetailModal.querySelector('#modalTimestamp');
                    
                    // JSON details ko format karke dikhana
                    try {
                        const parsedJson = JSON.parse(details);
                        modalDetails.textContent = JSON.stringify(parsedJson, null, 4);
                    } catch (e) {
                        modalDetails.textContent = details;
                    }
                    
                    modalAction.textContent = action;
                    modalTimestamp.textContent = timestamp;
                });
            }
        });
    </script>
</body>
</html>