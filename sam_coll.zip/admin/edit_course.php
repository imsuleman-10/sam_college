<?php
session_start();
// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$page_title = 'Edit Course';

// --- Configuration for File Uploads ---
const UPLOAD_SLIDES_DIR = '../uploads/course_slides/';
const ALLOWED_SLIDES_TYPES = ['application/pdf', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];
const MAX_SLIDES_SIZE = 10 * 1024 * 1024; // 10MB

// Ensure upload directory exists
if (!is_dir(UPLOAD_SLIDES_DIR)) {
    mkdir(UPLOAD_SLIDES_DIR, 0777, true);
}

$course_id = $title = $description = $youtube_iframe_link = $slides_path = '';
$title_err = $link_err = '';
$message = '';

// Check if an ID is passed
if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
    $course_id = trim($_GET["id"]);

    // 1. Fetch existing course data
    $sql = "SELECT title, description, youtube_iframe_link, slides_path FROM courses WHERE course_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $param_id);
        $param_id = $course_id;

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                $title = $row['title'];
                $description = $row['description'];
                $youtube_iframe_link = htmlspecialchars_decode($row['youtube_iframe_link']); // Decode for textarea display
                $slides_path = $row['slides_path'];
            } else {
                // Course ID not valid, redirect
                header("Location: manage_courses.php");
                exit();
            }
        }
        $stmt->close();
    }

    // 2. Process form submission (if POST request)
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        // Validate and sanitize inputs
        if (empty(trim($_POST['title']))) {
            $title_err = 'Please enter a course title.';
        } else {
            $title = trim($_POST['title']);
        }

        $youtube_iframe_link = trim($_POST['youtube_iframe_link']);
        if (empty($youtube_iframe_link) || strpos($youtube_iframe_link, '<iframe') === false) {
            $link_err = 'The input must be the full YouTube IFRAME embed code.';
        }

        $description = trim($_POST['description']);
        $new_slides_path = $slides_path;

        // 3. Handle Slides File Upload
        if (isset($_FILES['slides_file']) && $_FILES['slides_file']['error'] === UPLOAD_ERR_OK) {
            $slides_file = $_FILES['slides_file'];
            
            // Validate file size
            if ($slides_file['size'] > MAX_SLIDES_SIZE) {
                $message = '<div class="alert alert-danger">Error: Slides file is too large (max 10MB).</div>';
            }
            // Validate file type
            elseif (!in_array($slides_file['type'], ALLOWED_SLIDES_TYPES)) {
                $message = '<div class="alert alert-danger">Error: Only PDF and PowerPoint files are allowed for slides.</div>';
            }
            else {
                // Create unique filename
                $ext = pathinfo($slides_file['name'], PATHINFO_EXTENSION);
                $slides_filename = uniqid('slides_', true) . '.' . strtolower($ext);
                $destination = UPLOAD_SLIDES_DIR . $slides_filename;
                
                // Move uploaded file
                if (move_uploaded_file($slides_file['tmp_name'], $destination)) {
                    // Delete old slides file if exists
                    if ($slides_path && file_exists('../' . $slides_path)) {
                        unlink('../' . $slides_path);
                    }
                    // Store path relative to root for database
                    $new_slides_path = 'uploads/course_slides/' . $slides_filename;
                } else {
                    $message = '<div class="alert alert-danger">Error uploading slides file.</div>';
                }
            }
        }

        // Check input errors before updating
        if (empty($title_err) && empty($link_err) && empty($message)) {
            $sql_update = "UPDATE courses SET title = ?, description = ?, youtube_iframe_link = ?, slides_path = ? WHERE course_id = ?";
            
            if ($stmt_update = $conn->prepare($sql_update)) {
                $stmt_update->bind_param("ssssi", $param_title, $param_description, $param_link, $param_slides, $param_id);
                
                $param_title = $title;
                $param_description = $description;
                $param_link = htmlspecialchars($youtube_iframe_link); // Re-encode for security
                $param_slides = $new_slides_path;
                $param_id = $course_id;
                
                if ($stmt_update->execute()) {
                    // Success, redirect back to manage courses with message
                    $_SESSION['message'] = 'Course **' . htmlspecialchars($title) . '** updated successfully!';
                    header("Location: manage_courses.php");
                    exit();
                } else {
                    $message = '<div class="alert alert-danger">Error: Could not update course.</div>';
                }
                $stmt_update->close();
            }
        }
    }
} else {
    // No ID parameter, redirect to list
    header("Location: manage_courses.php");
    exit();
}
$conn->close();
require_once '../includes/header.php'; // Include header after data processing
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-edit text-warning"></i> Edit Course: <?php echo htmlspecialchars($title); ?></h2>
        <a href="manage_courses.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Courses
        </a>
    </div>

    <?php echo $message; ?>

    <div class="card shadow-lg mb-5">
        <div class="card-body p-4">
            <form action="edit_course.php?id=<?php echo $course_id; ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $course_id; ?>">
                
                <div class="mb-3">
                    <label for="title" class="form-label fw-bold">Course Title</label>
                    <input type="text" name="title" id="title" 
                        class="form-control <?php echo (!empty($title_err)) ? 'is-invalid' : ''; ?>" 
                        value="<?php echo htmlspecialchars($title); ?>" required>
                    <span class="invalid-feedback"><?php echo $title_err; ?></span>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label fw-bold">Course Description</label>
                    <textarea name="description" id="description" class="form-control" rows="4" 
                        placeholder="Provide a detailed summary..."><?php echo htmlspecialchars($description); ?></textarea>
                </div>
                
                <hr>

                <div class="mb-3">
                    <label for="youtube_iframe_link" class="form-label fw-bold text-danger">YouTube Iframe Embed Code</label>
                    <textarea name="youtube_iframe_link" id="youtube_iframe_link" 
                        class="form-control <?php echo (!empty($link_err)) ? 'is-invalid' : ''; ?>" rows="4" 
                        required><?php echo htmlspecialchars($youtube_iframe_link); ?></textarea>
                    <span class="invalid-feedback"><?php echo $link_err; ?></span>
                    <small class="form-text text-muted">Ensure this is the full `<iframe ...>` embed code.</small>
                </div>

                <div class="mb-4">
                    <label for="slides_file" class="form-label fw-bold text-primary">
                        <i class="fas fa-file-powerpoint me-1"></i> Course Slides (PDF/PPT)
                    </label>
                    <input type="file" name="slides_file" id="slides_file" 
                        class="form-control" accept=".pdf,.ppt,.pptx">
                    <small class="form-text text-muted">
                        Upload new slides to replace existing ones. Maximum file size: 10MB
                    </small>
                    
                    <?php if ($slides_path): ?>
                        <div class="mt-3 p-3 border rounded bg-light">
                            <span class="text-success fw-bold me-2">Current Slides:</span>
                            <div class="d-flex align-items-center mt-2">
                                <i class="fas fa-file-pdf fa-2x text-danger me-2"></i>
                                <div>
                                    <a href="<?php echo '../' . htmlspecialchars($slides_path); ?>" 
                                       target="_blank" class="text-decoration-none">
                                        Download Current Slides
                                    </a>
                                    <span class="form-text text-muted d-block">Uploading a new file will replace the current one.</span>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mt-2">
                            <span class="text-warning">No slides currently uploaded for this course.</span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-warning btn-lg">
                        <i class="fas fa-sync-alt me-2"></i> Update Course
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
[file content end]