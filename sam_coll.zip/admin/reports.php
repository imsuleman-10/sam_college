<?php
session_start();
require_once '../includes/db_connection.php';
require_once '../includes/auth.php';

// Check Authentication
if (!isAdminLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// -----------------------------------------------------------
// 1. DATA LOGIC ENGINE
// -----------------------------------------------------------
try {
    // --- KEY METRICS ---
    
    // 1. Total Learners
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE user_type = 'student'");
    $stats['total_students'] = $stmt->fetchColumn();

    // 2. Growth (New Enrollments This Month)
    $stmt = $pdo->query("
        SELECT COUNT(*) 
        FROM enrollments 
        WHERE MONTH(enrollment_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(enrollment_date) = YEAR(CURRENT_DATE())
    ");
    $stats['monthly_growth'] = $stmt->fetchColumn();
    
    // 3. Certification Rate
    $stmt = $pdo->query("SELECT COUNT(*) FROM progress WHERE certificate_status = 'approved'");
    $certificates = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM enrollments");
    $total_enrollments = $stmt->fetchColumn();
    
    // Calculate percentage (avoid division by zero)
    $stats['completion_rate'] = ($total_enrollments > 0) 
        ? round(($certificates / $total_enrollments) * 100, 1) 
        : 0;

    // --- CHART 1: Enrollment Trends (Last 6 Months) ---
    // Simulating monthly trend data using the available enrollment dates
    $trendQuery = "
        SELECT 
            DATE_FORMAT(enrollment_date, '%Y-%m') as month_key,
            DATE_FORMAT(enrollment_date, '%M') as month_name,
            COUNT(*) as count
        FROM enrollments
        GROUP BY month_key, month_name
        ORDER BY month_key DESC
        LIMIT 6
    ";
    $stmt = $pdo->query($trendQuery);
    $trendData = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC)); // Flip to chronological order

    $trendLabels = [];
    $trendCounts = [];
    foreach ($trendData as $data) {
        $trendLabels[] = $data['month_name'];
        $trendCounts[] = $data['count'];
    }

    // --- CHART 2: Course Distribution (Top 5) ---
    $distQuery = "
        SELECT c.title, COUNT(e.student_id) as count 
        FROM courses c 
        LEFT JOIN enrollments e ON c.course_id = e.course_id 
        GROUP BY c.course_id, c.title
        ORDER BY count DESC
        LIMIT 4
    ";
    $stmt = $pdo->query($distQuery);
    $distData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $distLabels = [];
    $distCounts = [];
    foreach ($distData as $data) {
        $distLabels[] = $data['title'];
        $distCounts[] = $data['count'];
    }

    // --- TABLE: Recent Live Activity ---
    $feedQuery = "
        SELECT 
            u.name, u.email,
            c.title as course,
            e.enrollment_date
        FROM enrollments e
        JOIN users u ON e.student_id = u.user_id
        JOIN courses c ON e.course_id = c.course_id
        ORDER BY e.enrollment_date DESC
        LIMIT 6
    ";
    $stmt = $pdo->query($feedQuery);
    $activityFeed = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics | Admin Dashboard</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --font-main: 'Inter', sans-serif;
            --primary: #2563eb;
            --surface: #ffffff;
            --bg-app: #f3f4f6;
            --text-dark: #111827;
            --text-light: #6b7280;
            --border: #e5e7eb;
        }

        body {
            font-family: var(--font-main);
            background-color: var(--bg-app);
            color: var(--text-dark);
            padding-bottom: 40px;
        }

        /* --- Navigation --- */
        .app-header {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }
        .nav-logo {
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--text-dark);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .nav-link-custom {
            color: var(--text-light);
            font-weight: 500;
            font-size: 0.9rem;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s;
            text-decoration: none;
        }
        .nav-link-custom:hover, .nav-link-custom.active {
            color: var(--primary);
            background: #eff6ff;
        }

        /* --- Cards --- */
        .metric-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
            height: 100%;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .metric-card:hover {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
            transform: translateY(-2px);
        }
        .metric-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-light);
            margin-bottom: 0.5rem;
        }
        .metric-value {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--text-dark);
            letter-spacing: -0.025em;
        }
        .metric-delta {
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            border-radius: 9999px;
            margin-top: 10px;
        }
        .delta-positive { background: #dcfce7; color: #166534; }
        .delta-neutral { background: #f3f4f6; color: #374151; }

        /* --- Charts & Tables Section --- */
        .panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
            height: 100%;
        }
        .panel-header {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .panel-title {
            font-weight: 600;
            font-size: 1rem;
            margin: 0;
            color: var(--text-dark);
        }
        
        .table-pro th {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-light);
            font-weight: 600;
            background: #f9fafb;
            border-bottom: 1px solid var(--border);
            padding: 0.75rem 1.5rem;
        }
        .table-pro td {
            padding: 1rem 1.5rem;
            vertical-align: middle;
            border-bottom: 1px solid var(--border);
            font-size: 0.9rem;
            color: #374151;
        }
        .table-pro tr:last-child td { border-bottom: none; }
        
        .user-initials {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #e0e7ff;
            color: #4338ca;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: 600;
            margin-right: 12px;
        }
    </style>
</head>
<body>

    <header class="app-header">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-4">
                <a href="#" class="nav-logo">
                    <div style="width:32px; height:32px; background:var(--primary); border-radius:8px; display:flex; align-items:center; justify-content:center; color:white;">
                        <i class="fas fa-shapes"></i>
                    </div>
                    <span>LMS Admin</span>
                </a>
                <nav class="d-none d-md-flex gap-2">
                    <a href="dashboard.php" class="nav-link-custom active">Dashboard</a>
                    <a href="manage_users.php" class="nav-link-custom">Students</a>
                    <a href="manage_courses.php" class="nav-link-custom">Courses</a>
                    <a href="#" class="nav-link-custom">Settings</a>
                </nav>
            </div>
            
            <div class="d-flex align-items-center gap-3">
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary border-0" type="button">
                        <i class="far fa-bell"></i>
                    </button>
                </div>
                <div class="vr h-50 my-auto text-secondary"></div>
                <a href="../logout.php" class="btn btn-sm btn-dark px-3 rounded-pill">Logout</a>
            </div>
        </div>
    </header>

    <div class="container py-5">
        
        <div class="d-flex justify-content-between align-items-end mb-5">
            <div>
                <h6 class="text-uppercase text-secondary fw-bold" style="font-size: 0.75rem; letter-spacing: 0.05em;">Analytics Overview</h6>
                <h2 class="fw-bold mb-0">Executive Report</h2>
            </div>
            <div class="d-none d-sm-block">
                <button class="btn btn-white border shadow-sm btn-sm"><i class="fas fa-download me-2"></i>Export PDF</button>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger shadow-sm border-0 mb-4"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="row g-4 mb-5">
            <div class="col-lg-3 col-md-6">
                <div class="metric-card">
                    <div class="d-flex justify-content-between">
                        <div>
                            <div class="metric-label">Total Learners</div>
                            <div class="metric-value"><?php echo number_format($stats['total_students'] ?? 0); ?></div>
                        </div>
                        <div class="text-primary opacity-75"><i class="fas fa-users fa-lg"></i></div>
                    </div>
                    <div class="metric-delta delta-neutral">
                        <i class="fas fa-minus me-1"></i> Stable
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="metric-card">
                    <div class="d-flex justify-content-between">
                        <div>
                            <div class="metric-label">Monthly Growth</div>
                            <div class="metric-value"><?php echo number_format($stats['monthly_growth'] ?? 0); ?></div>
                        </div>
                        <div class="text-success opacity-75"><i class="fas fa-chart-line fa-lg"></i></div>
                    </div>
                    <div class="metric-delta delta-positive">
                        <i class="fas fa-arrow-up me-1"></i> This Month
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="metric-card">
                    <div class="d-flex justify-content-between">
                        <div>
                            <div class="metric-label">Completion Rate</div>
                            <div class="metric-value"><?php echo $stats['completion_rate']; ?>%</div>
                        </div>
                        <div class="text-info opacity-75"><i class="fas fa-percent fa-lg"></i></div>
                    </div>
                    <div class="metric-delta delta-positive">
                        <i class="fas fa-check-circle me-1"></i> Certified
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="metric-card">
                    <div class="d-flex justify-content-between">
                        <div>
                            <div class="metric-label">Total Enrollments</div>
                            <div class="metric-value"><?php echo number_format($total_enrollments ?? 0); ?></div>
                        </div>
                        <div class="text-warning opacity-75"><i class="fas fa-graduation-cap fa-lg"></i></div>
                    </div>
                    <div class="metric-delta delta-neutral">
                        Across all courses
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-5">
            <div class="col-lg-8">
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title">Enrollment Trends</h3>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border" type="button">Last 6 Months</button>
                        </div>
                    </div>
                    <div class="p-4" style="height: 320px;">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title">Popular Courses</h3>
                    </div>
                    <div class="p-4 d-flex align-items-center justify-content-center" style="height: 320px;">
                        <canvas id="doughnutChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title">Recent Activity Feed</h3>
                        <a href="manage_users.php" class="text-decoration-none small fw-bold">View All Users &rarr;</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-pro mb-0">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Action</th>
                                    <th>Course</th>
                                    <th>Time</th>
                                    <th class="text-end">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($activityFeed)): ?>
                                    <?php foreach ($activityFeed as $act): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-initials">
                                                    <?php echo strtoupper(substr($act['name'], 0, 1)); ?>
                                                </div>
                                                <div>
                                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($act['name']); ?></div>
                                                    <div class="text-muted small"><?php echo htmlspecialchars($act['email']); ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><span class="badge bg-light text-dark border">Enrolled</span></td>
                                        <td class="fw-medium text-dark"><?php echo htmlspecialchars($act['course']); ?></td>
                                        <td class="text-muted"><?php echo date('M d, H:i', strtotime($act['enrollment_date'])); ?></td>
                                        <td class="text-end">
                                            <div class="d-inline-block rounded-circle bg-success" style="width:8px; height:8px;"></div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center py-4 text-muted">No recent activity.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script>
        // Data injected from PHP
        const trendLabels = <?php echo json_encode($trendLabels); ?>;
        const trendData = <?php echo json_encode($trendCounts); ?>;
        
        const distLabels = <?php echo json_encode($distLabels); ?>;
        const distData = <?php echo json_encode($distCounts); ?>;

        // 1. Line Chart (Trends)
        new Chart(document.getElementById('trendChart'), {
            type: 'line',
            data: {
                labels: trendLabels.length ? trendLabels : ['No Data'],
                datasets: [{
                    label: 'Enrollments',
                    data: trendData.length ? trendData : [0],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#ffffff',
                    pointBorderColor: '#2563eb',
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { borderDash: [2, 4], color: '#f3f4f6' } },
                    x: { grid: { display: false } }
                }
            }
        });

        // 2. Doughnut Chart (Distribution)
        new Chart(document.getElementById('doughnutChart'), {
            type: 'doughnut',
            data: {
                labels: distLabels.length ? distLabels : ['Empty'],
                datasets: [{
                    data: distData.length ? distData : [1],
                    backgroundColor: ['#2563eb', '#3b82f6', '#60a5fa', '#93c5fd'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: {
                    legend: { position: 'bottom', labels: { usePointStyle: true, padding: 20 } }
                }
            }
        });
    </script>
</body>
</html>