<?php
session_start();
// Security checks: Only Admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($student_id === 0 || $course_id === 0) {
    $_SESSION['message'] = '<div class="alert alert-danger">Error: Invalid student or course ID.</div>';
    header('Location: student_data.php');
    exit;
}

// Data consistency ke liye transaction shuru karein
$conn->begin_transaction();
$success = true;

try {
    // 1. Delete Progress Record (Quiz Score, Video Progress, Certificate Status)
    $sql_progress = "DELETE FROM progress WHERE student_id = ? AND course_id = ?";
    if ($stmt_progress = $conn->prepare($sql_progress)) {
        $stmt_progress->bind_param("ii", $student_id, $course_id);
        if (!$stmt_progress->execute()) {
            $success = false;
        }
        $stmt_progress->close();
    } else {
        $success = false;
    }

    // 2. Delete Enrollment Record
    if ($success) {
        $sql_enrollment = "DELETE FROM enrollments WHERE student_id = ? AND course_id = ?";
        if ($stmt_enrollment = $conn->prepare($sql_enrollment)) {
            $stmt_enrollment->bind_param("ii", $student_id, $course_id);
            if (!$stmt_enrollment->execute()) {
                $success = false;
            }
            $stmt_enrollment->close();
        } else {
            $success = false;
        }
    }

    if ($success) {
        $conn->commit();
        $_SESSION['message'] = '<div class="alert alert-success">Enrollment successfully cancelled. Progress and quiz data removed.</div>';
    } else {
        $conn->rollback();
        $_SESSION['message'] = '<div class="alert alert-danger">Failed to cancel enrollment due to a database error.</div>';
    }

} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['message'] = '<div class="alert alert-danger">An internal error occurred: ' . $e->getMessage() . '</div>';
}

$conn->close();
header('Location: student_data.php');
exit;
?>