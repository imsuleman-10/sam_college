<?php
session_start();
// Security check: Admin only
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$page_title = 'Certificate Requests';

// Handle Action (Approve/Reject)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && isset($_POST['progress_id'])) {
    $progress_id = intval($_POST['progress_id']);
    $action = $_POST['action'];
    $new_status = '';

    if ($action == 'approve') {
        $new_status = 'approved';
    } elseif ($action == 'reject') {
        $new_status = 'rejected';
    }

    if (!empty($new_status)) {
        // Update the progress status
        $sql_update = "UPDATE progress SET certificate_status = ? WHERE progress_id = ?";
        if ($stmt_update = $conn->prepare($sql_update)) {
            $stmt_update->bind_param("si", $new_status, $progress_id);
            $stmt_update->execute();
            $stmt_update->close();

            // If approved, insert/update record in the certificates table
            if ($new_status == 'approved') {
                $sql_cert = "
                    INSERT INTO certificates (student_id, course_id, issue_date) 
                    SELECT student_id, course_id, NOW() 
                    FROM progress WHERE progress_id = ?
                    ON DUPLICATE KEY UPDATE issue_date = NOW()
                ";
                $stmt_cert = $conn->prepare($sql_cert);
                $stmt_cert->bind_param("i", $progress_id);
                $stmt_cert->execute();
                $stmt_cert->close();
            }
            $_SESSION['message'] = '<div class="alert alert-success">Request successfully marked as **' . $new_status . '**.</div>';
            header("Location: certificate_requests.php");
            exit;
        }
    }
}

// Fetch all requests where students are eligible and status is pending/approved/rejected
$sql = "
    SELECT 
        p.progress_id, 
        u.name AS student_name, 
        c.title AS course_title, 
        p.video_progress_percentage, 
        p.quiz_score,
        p.certificate_status
    FROM progress p
    JOIN users u ON p.student_id = u.user_id
    JOIN courses c ON p.course_id = c.course_id
    WHERE p.video_progress_percentage >= 60.00 AND p.quiz_score >= 70.00
    ORDER BY FIELD(p.certificate_status, 'pending', 'rejected', 'approved'), p.progress_id DESC
";

$requests = [];
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    $result->free();
}

$conn->close();
require_once '../includes/header.php';
?>

<div class="container mt-4">
    <h2><i class="fas fa-certificate text-success"></i> Certificate Requests</h2>
    <p class="text-muted">Review and approve requests from students who have met the minimum requirements (Video $\ge 60\%$, Quiz $\ge 70\%$).</p>
    
    <?php 
    if (isset($_SESSION['message'])): 
        echo $_SESSION['message']; 
        unset($_SESSION['message']);
    endif;
    ?>

    <?php if (count($requests) > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped shadow-sm">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Student Name</th>
                        <th>Course</th>
                        <th>Video Progress</th>
                        <th>Quiz Score</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['course_title']); ?></td>
                            <td><span class="badge bg-info"><?php echo $request['video_progress_percentage']; ?>%</span></td>
                            <td><span class="badge bg-primary"><?php echo $request['quiz_score']; ?>%</span></td>
                            <td>
                                <?php 
                                $status = $request['certificate_status'];
                                $badge_class = 'bg-secondary';
                                if ($status == 'pending') $badge_class = 'bg-warning text-dark';
                                elseif ($status == 'approved') $badge_class = 'bg-success';
                                elseif ($status == 'rejected') $badge_class = 'bg-danger';
                                ?>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo ucfirst($status); ?></span>
                            </td>
                            <td>
                                <form method="post" class="d-inline-block">
                                    <input type="hidden" name="progress_id" value="<?php echo $request['progress_id']; ?>">
                                    <?php if ($status != 'approved'): ?>
                                        <button type="submit" name="action" value="approve" class="btn btn-sm btn-success" 
                                                onclick="return confirm('Approve certificate for <?php echo htmlspecialchars($request['student_name']); ?>?');">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($status != 'rejected'): ?>
                                        <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger" 
                                                onclick="return confirm('Reject certificate request?');">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">
            No certificate requests currently meet the eligibility criteria.
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>