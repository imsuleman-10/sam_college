<?php
session_start();

// --- 1. Security & Setup ---
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$student_id = $_SESSION['user_id'];
$message = '';

// --- 2. Logic: Handle Enrollment AND Unenrollment ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $course_id = intval($_GET['id']);
    
    // CASE A: ENROLL
    if ($_GET['action'] == 'enroll') {
        // Check if course exists
        $course_check = "SELECT course_id FROM courses WHERE course_id = ?";
        if ($course_stmt = $conn->prepare($course_check)) {
            $course_stmt->bind_param("i", $course_id);
            $course_stmt->execute();
            $course_stmt->store_result();
            
            if ($course_stmt->num_rows === 0) {
                $_SESSION['catalog_message'] = '<div class="alert alert-danger shadow-sm"><i class="fas fa-exclamation-circle me-2"></i>Course not found.</div>';
            } else {
                $course_stmt->close();
                // Check if already enrolled
                $check_sql = "SELECT enrollment_id FROM enrollments WHERE student_id = ? AND course_id = ?";
                if ($check_stmt = $conn->prepare($check_sql)) {
                    $check_stmt->bind_param("ii", $student_id, $course_id);
                    $check_stmt->execute();
                    $check_stmt->store_result();
                    
                    if ($check_stmt->num_rows === 0) {
                        // FIX APPLIED HERE: Changed 'enrolled_at' to 'enrollment_date'
                        $enroll_sql = "INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, NOW())";
                        if ($enroll_stmt = $conn->prepare($enroll_sql)) {
                            $enroll_stmt->bind_param("ii", $student_id, $course_id);
                            if ($enroll_stmt->execute()) {
                                $_SESSION['catalog_message'] = '<div class="alert alert-success shadow-sm"><i class="fas fa-check-circle me-2"></i>Successfully enrolled!</div>';
                            } else {
                                $_SESSION['catalog_message'] = '<div class="alert alert-danger shadow-sm">Enrollment failed.</div>';
                            }
                            $enroll_stmt->close();
                        }
                    } else {
                        $_SESSION['catalog_message'] = '<div class="alert alert-info shadow-sm"><i class="fas fa-info-circle me-2"></i>You are already enrolled.</div>';
                    }
                    $check_stmt->close();
                }
            }
        }
    } 
    // CASE B: UNROLL
    elseif ($_GET['action'] == 'unroll') {
        // Prepare DELETE statement
        $unroll_sql = "DELETE FROM enrollments WHERE student_id = ? AND course_id = ?";
        
        if ($unroll_stmt = $conn->prepare($unroll_sql)) {
            $unroll_stmt->bind_param("ii", $student_id, $course_id);
            
            if ($unroll_stmt->execute()) {
                if ($unroll_stmt->affected_rows > 0) {
                    $_SESSION['catalog_message'] = '<div class="alert alert-warning shadow-sm"><i class="fas fa-trash-alt me-2"></i>You have unrolled from the course.</div>';
                } else {
                    $_SESSION['catalog_message'] = '<div class="alert alert-info shadow-sm">You were not enrolled in this course.</div>';
                }
            } else {
                $_SESSION['catalog_message'] = '<div class="alert alert-danger shadow-sm">Error processing request.</div>';
            }
            $unroll_stmt->close();
        }
    }
    
    // Redirect to clear URL parameters
    header('Location: course_catalog.php');
    exit;
}

// --- 3. Logic: Fetch Courses ---
if (isset($_SESSION['catalog_message'])) {
    $message = $_SESSION['catalog_message'];
    unset($_SESSION['catalog_message']);
}

$page_title = 'Course Catalog';
require_once '../includes/header.php';

$all_courses = [];
$sql = "SELECT c.*, CASE WHEN e.enrollment_id IS NOT NULL THEN 1 ELSE 0 END AS is_enrolled 
        FROM courses c 
        LEFT JOIN enrollments e ON c.course_id = e.course_id AND e.student_id = ? 
        ORDER BY c.title ASC";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $all_courses[] = $row;
    }
    $stmt->close();
}
?>

<style>
    :root {
        --primary-color: #4e73df;
        --secondary-text: #858796;
        --card-border-radius: 12px;
    }
    
    body {
        background-color: #f8f9fc;
    }

    /* Hero Section */
    .catalog-header {
        background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
        color: white;
        padding: 3rem 0;
        margin-bottom: 2rem;
        border-radius: 0 0 20px 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    /* Card Styling */
    .course-card {
        border: none;
        border-radius: var(--card-border-radius);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        background: white;
    }

    .course-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }

    .course-img-wrapper {
        position: relative;
        height: 200px;
        background-color: #eaecf4;
        overflow: hidden;
    }

    .course-img-top {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .course-card:hover .course-img-top {
        transform: scale(1.05);
    }

    /* Status Badges */
    .status-badge {
        position: absolute;
        top: 15px;
        right: 15px;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        z-index: 10;
    }

    .badge-enrolled {
        background-color: #1cc88a;
        color: white;
    }

    .badge-available {
        background-color: rgba(255,255,255,0.9);
        color: #4e73df;
    }

    /* Text & Buttons */
    .course-title {
        font-weight: 700;
        color: #333;
        line-height: 1.4;
    }

    .course-desc {
        color: var(--secondary-text);
        font-size: 0.9rem;
        line-height: 1.6;
    }

    .btn-action {
        border-radius: 8px;
        padding: 10px 20px;
        font-weight: 600;
        width: 100%;
        transition: all 0.2s;
    }
</style>

<div class="catalog-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="fw-bold mb-2"><i class="fas fa-graduation-cap me-3"></i>Course Catalog</h1>
                <p class="mb-0 opacity-75">Expand your knowledge with our premium courses.</p>
            </div>
            <div class="col-md-4 text-end d-none d-md-block">
                <i class="fas fa-shapes fa-5x opacity-25"></i>
            </div>
        </div>
    </div>
</div>

<div class="container pb-5">
    
    <?php if (!empty($message)): ?>
        <div class="row mb-4">
            <div class="col-md-8 mx-auto">
                <?php echo $message; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php if (empty($all_courses)): ?>
            <div class="col-12 text-center py-5">
                <div class="text-muted">
                    <i class="fas fa-folder-open fa-4x mb-3"></i>
                    <h4>No courses found</h4>
                    <p>Check back later for new content.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($all_courses as $course): ?>
                <?php 
                    // --- IMAGE FIX LOGIC ---
                    $img_path = htmlspecialchars($course['course_image']);
                    $has_image = !empty($img_path);
                    if ($has_image && !preg_match('/^(http|\.\.\/|\/)/', $img_path)) {
                        $img_path = "../" . $img_path; 
                    }
                ?>

                <div class="col-lg-4 col-md-6">
                    <div class="card course-card h-100 shadow-sm">
                        <div class="course-img-wrapper">
                            
                            <?php if ($course['is_enrolled']): ?>
                                <span class="status-badge badge-enrolled">
                                    <i class="fas fa-check me-1"></i> Enrolled
                                </span>
                            <?php else: ?>
                                <span class="status-badge badge-available">
                                    <i class="fas fa-lock-open me-1"></i> Open
                                </span>
                            <?php endif; ?>

                            <?php if ($has_image): ?>
                                <img src="<?php echo $img_path; ?>" 
                                     class="course-img-top" 
                                     alt="Course thumbnail"
                                     onerror="this.onerror=null; this.src='https://via.placeholder.com/600x400?text=No+Image'; this.parentElement.classList.add('bg-light');">
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center h-100 text-secondary">
                                    <i class="fas fa-image fa-3x opacity-25"></i>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="card-body d-flex flex-column p-4">
                            <h5 class="course-title mb-3"><?php echo htmlspecialchars($course['title']); ?></h5>
                            
                            <p class="course-desc flex-grow-1">
                                <?php 
                                    $desc = $course['description'];
                                    echo htmlspecialchars(strlen($desc) > 90 ? substr($desc, 0, 90) . '...' : $desc);
                                ?>
                            </p>
                            
                            <div class="mt-4 pt-3 border-top">
                                <?php if ($course['is_enrolled']): ?>
                                    <a href="view_course.php?id=<?php echo $course['course_id']; ?>" 
                                       class="btn btn-outline-success btn-action mb-2">
                                       Continue Learning
                                    </a>
                                    <a href="course_catalog.php?action=unroll&id=<?php echo $course['course_id']; ?>" 
                                       class="btn btn-sm btn-outline-danger w-100"
                                       onclick="return confirm('Are you sure you want to unroll from <?php echo htmlspecialchars(addslashes($course['title'])); ?>? Your progress may be lost.')">
                                       <i class="fas fa-times me-1"></i> Unroll
                                    </a>
                                <?php else: ?>
                                    <a href="course_catalog.php?action=enroll&id=<?php echo $course['course_id']; ?>" 
                                       class="btn btn-primary btn-action"
                                       onclick="return confirm('Confirm enrollment for: <?php echo htmlspecialchars(addslashes($course['title'])); ?>?')">
                                       Enroll Now
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>