<?php
session_start();
// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';

$student_id = $_SESSION['user_id'];
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($course_id === 0) {
    header('Location: my_progress.php');
    exit;
}

// Data fetch
$sql = "
    SELECT 
        u.name AS student_name,
        c.title AS course_title,
        p.certificate_status
    FROM progress p 
    JOIN users u ON p.student_id = u.user_id
    JOIN courses c ON p.course_id = c.course_id
    WHERE p.student_id = ? AND p.course_id = ? AND p.certificate_status = 'approved'
";

$certificate_data = null;
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("ii", $student_id, $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $certificate_data = $result->fetch_assoc();
    }
    $stmt->close();
}
$conn->close();

if (!$certificate_data) {
    $_SESSION['message'] = '<div class="alert alert-danger">Certificate not found.</div>';
    header('Location: my_progress.php');
    exit;
}

$issue_date_str = date('Y-m-d'); 
$issue_date = new DateTime($issue_date_str);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate - <?php echo htmlspecialchars($certificate_data['course_title']); ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700;900&family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Pinyon+Script&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --gold: #D4AF37;
            --dark-blue: #0f1c3f;
            --cream: #fffdf5;
        }

        body { 
            background: #dcdcdc; 
            margin: 0; 
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            font-family: 'Playfair Display', serif;
        }

        /* --- Certificate Container --- */
        .cert-paper {
            width: 1123px; /* A4 width landscape */
            height: 794px; /* A4 height landscape */
            background-color: var(--cream);
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            padding: 15px;
            box-sizing: border-box;
            color: var(--dark-blue);
        }

        /* --- Borders --- */
        .border-outer {
            width: 100%;
            height: 100%;
            border: 8px solid var(--dark-blue);
            padding: 5px;
            position: relative;
            box-sizing: border-box;
        }

        .border-inner {
            width: 100%;
            height: 100%;
            border: 3px solid var(--gold);
            display: flex;
            flex-direction: column;
            align-items: center;
            /* Main fix: Use space-around/center for vertical distribution */
            justify-content: center; 
            padding: 30px; /* Overall internal padding */
            position: relative;
            background-image: radial-gradient(circle, transparent 30%, rgba(212, 175, 55, 0.05) 100%);
            box-sizing: border-box;
        }

        /* --- Header Layout (Logo + Text Side by Side) --- */
        .header-group {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px; /* Reduced gap */
            margin-bottom: 25px; /* Reduced margin */
        }

        .logo-img {
            height: 70px; /* Slightly reduced logo size */
            width: auto;
        }

        .college-name {
            font-family: 'Cinzel', serif;
            font-size: 3rem; /* Adjusted size */
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 4px; /* Slight increase for visual impact */
            color: var(--dark-blue);
            text-shadow: 1px 1px 0px rgba(212, 175, 55, 0.4);
            line-height: 1;
            margin: 0;
        }

        /* --- Content Spacing Adjusted --- */
        .cert-title {
            font-family: 'Cinzel', serif;
            font-size: 1.6rem; /* Slightly reduced size */
            font-weight: 700;
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 4px;
            margin-bottom: 15px; /* Reduced margin */
        }

        .cert-text-small {
            font-style: italic;
            font-size: 1rem;
            color: #555;
            margin-bottom: 3px; /* Reduced margin */
        }

        /* Student Name */
        .student-name {
            font-family: 'Pinyon Script', cursive;
            font-size: 4rem; /* Adjusted size */
            color: var(--dark-blue);
            margin: 10px 0 15px 0; /* Reduced margins */
            padding: 0 30px;
            border-bottom: 1px solid #ccc;
            line-height: 1.1;
        }

        /* Course Name */
        .course-name {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem; /* Adjusted size */
            font-weight: bold;
            color: var(--dark-blue);
            margin: 10px 0 30px 0; /* Reduced margins */
            max-width: 80%;
            text-align: center;
        }

        /* --- Footer --- */
        .footer-area {
            width: 80%;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            /* No margin-top: auto needed now as we use justify-content: center */
            margin-top: 30px; 
            margin-bottom: 0;
        }

        .sig-box {
            text-align: center;
            width: 200px; /* Slightly narrower signature box */
        }
        .sig-img { height: 50px; display: block; margin: 0 auto; }
        .sig-line {
            border-top: 1px solid var(--dark-blue);
            margin-top: 5px;
            padding-top: 5px;
            font-weight: bold;
            font-family: 'Cinzel', serif;
            font-size: 0.95rem;
        }
        .sig-role { font-size: 0.8rem; color: var(--gold); text-transform: uppercase; letter-spacing: 1px; }

        /* Corners & Seal (Slightly reduced size for balance) */
        .ornament { position: absolute; font-size: 22px; color: var(--gold); }
        .tl { top: 8px; left: 8px; transform: rotate(-45deg); }
        .tr { top: 8px; right: 8px; transform: rotate(45deg); }
        .bl { bottom: 8px; left: 8px; transform: rotate(-135deg); }
        .br { bottom: 8px; right: 8px; transform: rotate(135deg); }

        .gold-seal {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 80px;
            background: radial-gradient(ellipse at center, #f7df8b 0%, #D4AF37 100%);
            border-radius: 50%;
            box-shadow: 0 0 0 3px #b08d26;
            display: flex; justify-content: center; align-items: center;
            font-family: 'Cinzel', serif; font-weight: bold; font-size: 8px; color: #584611; border: 1px dashed #584611;
        }
        .gold-seal::after { content: "OFFICIAL SEAL"; }

        .print-btn-area { position: fixed; top: 20px; right: 20px; z-index: 100; }

        @media print {
            @page { size: landscape; margin: 0; }
            body { background: none; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; margin: 0; padding: 0; }
            .cert-paper { box-shadow: none; width: 100%; height: 100vh; page-break-after: always; padding: 0; margin: 0; }
            .border-outer { border: none; padding: 10px; } 
            .print-btn-area { display: none; }
        }
    </style>
</head>
<body>

<div class="print-btn-area">
    <button onclick="window.print()" class="btn btn-dark btn-lg shadow">
        <i class="fas fa-print me-2"></i> Print Certificate
    </button>
</div>

<div class="cert-paper">
    <div class="border-outer">
        <div class="border-inner">

            <div class="ornament tl"><i class="fas fa-certificate"></i></div>
            <div class="ornament tr"><i class="fas fa-certificate"></i></div>
            <div class="ornament bl"><i class="fas fa-certificate"></i></div>
            <div class="ornament br"><i class="fas fa-certificate"></i></div>

            <div class="header-group">
                <img src="../assets/img/logo.png" alt="Logo" class="logo-img" onerror="this.style.display='none'">
                
                <div class="college-name">SAM COLLEGE</div>
            </div>

            <div class="cert-title">Certificate of Completion</div>

            <div class="cert-text-small">This certifies that</div>

            <div class="student-name"><?php echo htmlspecialchars($certificate_data['student_name']); ?></div>

            <div class="cert-text-small">has successfully completed the requirements for</div>

            <div class="course-name"><?php echo htmlspecialchars($certificate_data['course_title']); ?></div>

            <div class="gold-seal"></div>

            <div class="footer-area">
                <div class="sig-box">
                    <div style="height: 50px; display: flex; align-items: end; justify-content: center; font-size: 1rem;">
                        <?php echo $issue_date->format('F d, Y'); ?>
                    </div>
                    <div class="sig-line">Date Issued</div>
                </div>

                <div class="sig-box">
                    <img src="../assets/img/signature.png" alt="Sign" class="sig-img" onerror="this.style.display='none'">
                    <div class="sig-line">Suleman Mirza</div>
                    <div class="sig-role">Chief E-Learning Officer</div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>