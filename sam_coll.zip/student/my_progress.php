<?php
session_start();
// FIX 1: Ensure strict type checking on session variables before proceeding
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

// FIX 2: Use constants for file paths where possible, and ensure the paths are correct.
// Assuming the file structure is correct: my_progress.php is in /student/, config/db.php and includes/header.php are in /
require_once '../config/db.php';
$page_title = 'My Learning Progress';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$progress_data = [];

// Fetch enrolled courses and detailed progress
$sql = "
    SELECT 
        c.course_id, 
        c.title,
        c.course_image,
        c.description,
        -- Use COALESCE to ensure progress data defaults to 0 if no progress record exists
        COALESCE(p.video_progress_percentage, 0) AS video_progress_percentage, 
        COALESCE(p.quiz_score, 0) AS quiz_score, 
        COALESCE(p.certificate_status, 'not_eligible') AS certificate_status,
        (SELECT COUNT(*) FROM quizzes WHERE course_id = c.course_id) AS total_quizzes
    FROM enrollments e
    JOIN courses c ON e.course_id = c.course_id
    LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
    WHERE e.student_id = ?
    ORDER BY c.title ASC
";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        // Recalculate based on fetched (or defaulted) values
        $row['video_eligible'] = ((float)$row['video_progress_percentage']) >= 60.00;
        $row['quiz_eligible'] = ((float)$row['quiz_score']) >= 70.00;
        $row['cert_eligible'] = $row['video_eligible'] && $row['quiz_eligible'];
        $progress_data[] = $row;
    }
    $stmt->close();
}
$conn->close();

// Calculate overall stats
$total_courses = count($progress_data);
$completed_courses = 0;
foreach ($progress_data as $data) {
    if ($data['certificate_status'] == 'approved') $completed_courses++;
}
$completion_rate = $total_courses > 0 ? round(($completed_courses / $total_courses) * 100) : 0;
?>

<style>
    :root {
        --primary-color: #667eea;
        --success-color: #42e695;
        --danger-color: #f5576c;
        --purple-color: #764ba2; /* Defined for consistent use in icons */

        --primary-gradient: linear-gradient(135deg, var(--primary-color) 0%, var(--purple-color) 100%);
        --success-gradient: linear-gradient(135deg, var(--success-color) 0%, #3bb2b8 100%);
        --warning-gradient: linear-gradient(135deg, #f093fb 0%, var(--danger-color) 100%);
        --card-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        --card-hover-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
    }
    
    .stats-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        box-shadow: var(--card-shadow);
        border: none;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .stats-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--card-hover-shadow);
    }
    
    .course-card {
        border-radius: 15px;
        overflow: hidden;
        border: none;
        box-shadow: var(--card-shadow);
        transition: all 0.3s ease;
        background: white;
    }
    
    .course-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--card-hover-shadow);
    }
    
    .progress-circle {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 1.1rem;
        margin-right: 15px;
        flex-shrink: 0;
    }
    
    .certificate-badge {
        position: absolute;
        top: 20px;
        right: 20px;
        z-index: 2;
        font-size: 0.85rem;
        padding: 6px 15px;
        border-radius: 50px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    }
    
    .progress-track {
        position: relative;
        height: 8px;
        background: #e9ecef;
        border-radius: 10px;
        overflow: hidden;
    }
    
    .progress-fill {
        position: absolute;
        height: 100%;
        border-radius: 10px;
        transition: width 1s ease-in-out;
    }
    
    .goal-marker {
        position: absolute;
        top: -5px;
        width: 3px;
        height: 18px;
        background: rgba(0, 0, 0, 0.3);
    }
    
    .course-image-container {
        height: 180px;
        overflow: hidden;
        position: relative;
    }
    
    .course-image-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }
    
    .course-card:hover .course-image-container img {
        transform: scale(1.05);
    }
    
    .course-image-overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.7), transparent);
        padding: 20px;
        color: white;
    }
    
    .achievement-icon {
        font-size: 1.5rem;
        margin-right: 10px;
        vertical-align: middle;
        /* Using defined CSS variables for better maintenance */
    }

    .text-purple {
        color: var(--purple-color) !important;
    }
    
    .pill-badge {
        border-radius: 50px;
        padding: 5px 15px;
        font-size: 0.8rem;
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    
    .goal-indicator {
        font-size: 0.75rem;
        color: #6c757d;
        display: block;
        margin-top: 2px;
    }

    /* === NEW STYLES FOR PROGRESS REPORT BUTTON === */
    .btn-report-card {
        width: 48px; /* Fixed width for square shape */
        height: 48px; /* Fixed height */
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%; /* Circle shape */
        background: #f8f9fa;
        color: #6c757d;
        border: 1px solid #e9ecef;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-decoration: none;
    }

    .btn-report-card:hover {
        background: white;
        color: var(--primary-color); 
        border-color: var(--primary-color);
        transform: translateY(-3px) rotate(15deg); 
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.25);
    }

    .tooltip-custom {
        font-size: 0.8rem;
    }

</style>

<div class="container-fluid py-4">
    <div class="row mb-5">
        <div class="col-12">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h1 class="display-6 fw-bold text-dark d-inline">
                        <i class="fas fa-chart-line me-3" style="color: var(--primary-color);"></i>My Learning Journey
                    </h1>
                    <p class="text-muted mt-2">Track your progress, unlock achievements, and earn certificates</p>
                </div>
                <div class="text-end">
                    <span class="badge bg-light text-dark fs-6 p-3 rounded-pill shadow-sm">
                        <i class="fas fa-book-open me-2"></i>
                        <?php echo $total_courses; ?> Course<?php echo $total_courses != 1 ? 's' : ''; ?> Enrolled
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-md-3 mb-4">
            <div class="stats-card text-center" style="border-top: 4px solid var(--primary-color);">
                <div class="mb-3">
                    <i class="fas fa-chart-pie fa-3x" style="color: var(--primary-color);"></i>
                </div>
                <h3 class="fw-bold"><?php echo $completion_rate; ?>%</h3>
                <p class="text-muted mb-0">Overall Completion</p>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="stats-card text-center" style="border-top: 4px solid var(--success-color);">
                <div class="mb-3">
                    <i class="fas fa-medal fa-3x" style="color: var(--success-color);"></i>
                </div>
                <h3 class="fw-bold"><?php echo $completed_courses; ?></h3>
                <p class="text-muted mb-0">Certificates Earned</p>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="stats-card text-center" style="border-top: 4px solid #f093fb;">
                <div class="mb-3">
                    <i class="fas fa-video fa-3x text-purple"></i>
                </div>
                <h3 class="fw-bold"><?php echo $total_courses; ?></h3>
                <p class="text-muted mb-0">Active Courses</p>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="stats-card text-center" style="border-top: 4px solid var(--danger-color);">
                <div class="mb-3">
                    <i class="fas fa-trophy fa-3x" style="color: var(--danger-color);"></i>
                </div>
                <h3 class="fw-bold"><?php echo $total_courses - $completed_courses; ?></h3>
                <p class="text-muted mb-0">In Progress</p>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-12">
            <h3 class="fw-bold mb-4 text-dark">
                <i class="fas fa-graduation-cap me-2" style="color: var(--primary-color);"></i>Course Progress
            </h3>
        </div>
    </div>

    <div class="row">
        <?php if (count($progress_data) > 0): ?>
            <?php foreach ($progress_data as $data): ?>
                <?php
                $video_progress = $data['video_progress_percentage'];
                $quiz_score = $data['quiz_score'];
                $status = $data['certificate_status'];
                
                // Status badge configuration
                $status_config = [
                    'not_eligible' => ['class' => 'bg-light text-dark', 'icon' => 'fas fa-clock', 'label' => 'In Progress'],
                    'pending' => ['class' => 'bg-warning text-dark', 'icon' => 'fas fa-hourglass-half', 'label' => 'Pending Review'],
                    'approved' => ['class' => 'bg-success', 'icon' => 'fas fa-award', 'label' => 'Certificate Ready']
                ];
                
                $status_info = $status_config[$status] ?? $status_config['not_eligible'];
                
                // Progress colors
                $video_color = $data['video_eligible'] ? 'var(--success-color)' : 'var(--purple-color)';
                $quiz_color = $data['quiz_eligible'] ? 'var(--success-color)' : 'var(--danger-color)';
                $cert_color = $status == 'approved' ? 'var(--success-color)' : ($data['cert_eligible'] ? 'var(--primary-color)' : '#adb5bd');
                ?>
                
                <div class="col-xl-4 col-lg-6 mb-4">
                    <div class="course-card h-100">
                        <div class="course-image-container">
                            <?php if ($data['course_image']): ?>
                                <img src="<?php echo '../' . htmlspecialchars($data['course_image']); ?>" 
                                    alt="<?php echo htmlspecialchars($data['title']); ?>">
                            <?php else: ?>
                                <div class="bg-gradient-primary h-100 d-flex align-items-center justify-content-center" style="background: var(--primary-gradient);">
                                    <i class="fas fa-book-open fa-4x text-white opacity-50"></i>
                                </div>
                            <?php endif; ?>
                            <div class="course-image-overlay">
                                <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($data['title']); ?></h5>
                                <small class="opacity-75"><?php echo substr($data['description'] ?? 'No description available', 0, 80); ?>...</small>
                            </div>
                            <span class="certificate-badge <?php echo $status_info['class']; ?>">
                                <i class="<?php echo $status_info['icon']; ?> me-1"></i>
                                <?php echo $status_info['label']; ?>
                            </span>
                        </div>
                        
                        <div class="card-body p-4">
                            <div class="mb-4">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-video achievement-icon text-purple"></i>
                                        <div>
                                            <strong>Video Progress</strong>
                                            <span class="goal-indicator">Goal: 60%</span>
                                        </div>
                                    </div>
                                    <span class="fw-bold fs-5 <?php echo $data['video_eligible'] ? 'text-success' : 'text-purple'; ?>">
                                        <?php echo number_format($video_progress, 0); ?>%
                                    </span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" style="width: <?php echo min($video_progress, 100); ?>%; background: <?php echo $video_color; ?>;"></div>
                                    <div class="goal-marker" style="left: 60%;"></div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-question-circle achievement-icon text-danger"></i>
                                        <div>
                                            <strong>Quiz Score</strong>
                                            <span class="goal-indicator">Goal: 70%</span>
                                        </div>
                                    </div>
                                    <span class="fw-bold fs-5 <?php echo $data['quiz_eligible'] ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo number_format($quiz_score, 0); ?>%
                                    </span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" style="width: <?php echo min($quiz_score, 100); ?>%; background: <?php echo $quiz_color; ?>;"></div>
                                    <div class="goal-marker" style="left: 70%;"></div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-certificate achievement-icon text-warning"></i>
                                        <div>
                                            <strong>Certificate Status</strong>
                                            <span class="goal-indicator">Complete both requirements</span>
                                        </div>
                                    </div>
                                    <div class="progress-circle" style="background: <?php echo $cert_color; ?>; color: white;">
                                        <?php if ($status == 'approved'): ?>
                                            <i class="fas fa-check"></i>
                                        <?php elseif ($data['cert_eligible']): ?>
                                            <i class="fas fa-bolt"></i>
                                        <?php else: ?>
                                            <i class="fas fa-lock"></i>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex gap-2 mt-4 pt-3 border-top">
                                
                                <div class="flex-grow-1">
                                    <?php if ($data['cert_eligible'] && $status == 'not_eligible'): ?>
                                        <div class="alert alert-success d-flex align-items-center mb-3 p-2" role="alert">
                                            <i class="fas fa-check-circle fs-5 me-2"></i>
                                            <small class="fw-bold">Eligible for Certification</small>
                                        </div>
                                        <a href="view_course.php?id=<?php echo $data['course_id']; ?>" 
                                            class="btn btn-lg btn-success w-100 rounded-pill fw-bold shadow-sm">
                                            <i class="fas fa-file-certificate me-2"></i>Apply for Certificate
                                        </a>
                                        
                                    <?php elseif ($status == 'approved'): ?>
                                        <a href="certificate_view.php?course_id=<?php echo $data['course_id']; ?>" 
                                            class="btn btn-lg btn-warning w-100 rounded-pill fw-bold shadow-sm text-dark">
                                            <i class="fas fa-medal me-2"></i>View Certificate
                                        </a>
                                        
                                    <?php elseif (!$data['video_eligible']): ?>
                                        <a href="view_course.php?id=<?php echo $data['course_id']; ?>" 
                                            class="btn btn-lg btn-primary w-100 rounded-pill fw-bold shadow-sm"
                                            style="background: var(--primary-gradient); border: none;">
                                            <i class="fas fa-play-circle me-2"></i>Continue Course
                                        </a>
                                        
                                    <?php elseif ($data['video_eligible'] && !$data['quiz_eligible']): ?>
                                        <a href="view_course.php?id=<?php echo $data['course_id']; ?>" 
                                            class="btn btn-lg btn-outline-danger w-100 rounded-pill fw-bold">
                                            <i class="fas fa-redo me-2"></i>Retake Quiz
                                        </a>
                                        
                                    <?php else: ?>
                                        <a href="view_course.php?id=<?php echo $data['course_id']; ?>" 
                                            class="btn btn-lg btn-outline-dark w-100 rounded-pill fw-bold">
                                            <i class="fas fa-external-link-alt me-2"></i>View Course Details
                                        </a>
                                    <?php endif; ?>
                                </div>

                                <div>
                                    <a href="progress_report.php?course_id=<?php echo $data['course_id']; ?>" 
                                        class="btn-report-card" 
                                        data-bs-toggle="tooltip" 
                                        data-bs-placement="top" 
                                        title="View Detailed Report">
                                        <i class="fas fa-chart-pie fa-lg"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <div class="mb-4">
                        <i class="fas fa-book-open fa-4x text-muted opacity-25"></i>
                    </div>
                    <h3 class="text-muted mb-3">No Courses Enrolled</h3>
                    <p class="text-muted mb-4">You haven't enrolled in any courses yet. Start your learning journey today!</p>
                    <a href="course_catalog.php" class="btn btn-primary btn-lg rounded-pill px-4" style="background: var(--primary-gradient); border: none;">
                        <i class="fas fa-search me-2"></i>Browse Courses
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Animate progress bars on scroll
        const progressBars = document.querySelectorAll('.progress-fill');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const bar = entry.target;
                    const width = bar.style.width;
                    bar.style.width = '0';
                    setTimeout(() => {
                        bar.style.width = width;
                    }, 300);
                    // Stop observing once animation is done
                    observer.unobserve(bar);
                }
            });
        }, { threshold: 0.3 });
        
        progressBars.forEach(bar => observer.observe(bar));

        // FIX 5: Initialize Bootstrap Tooltips for the new report button
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
          // Assuming you are using Bootstrap 5, use the 'bootstrap' object
          return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    });
</script>

<?php require_once '../includes/footer.php'; ?>