<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$page_title = 'Student Dashboard';
require_once '../includes/header.php';

$student_id = $_SESSION['user_id'];
$enrolled_courses = [];

// Fetch all courses the student is enrolled in, along with progress data and image
$sql = "
    SELECT 
        c.course_id, 
        c.title,
        c.course_image, /* <--- Course Image Added */
        c.description,
        p.video_progress_percentage,
        p.quiz_score
    FROM enrollments e
    JOIN courses c ON e.course_id = c.course_id
    LEFT JOIN progress p ON e.student_id = p.student_id AND e.course_id = p.course_id
    WHERE e.student_id = ?
    ORDER BY e.enrollment_date DESC
";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $enrolled_courses[] = $row;
    }
    $stmt->close();
}
$conn->close();

// Calculate statistics
$course_count = count($enrolled_courses);
$avg_progress = 0;
$avg_quiz = 0;
$completed_courses = 0;

if ($course_count > 0) {
    $total_progress = 0;
    $total_quiz = 0;
    
    foreach ($enrolled_courses as $course) {
        $total_progress += $course['video_progress_percentage'] ?? 0;
        $total_quiz += $course['quiz_score'] ?? 0;
        
        if (($course['video_progress_percentage'] ?? 0) >= 90) {
            $completed_courses++;
        }
    }
    
    $avg_progress = $total_progress / $course_count;
    $avg_quiz = $total_quiz / $course_count;
}
?>

<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --success-gradient: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
        --card-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        --card-hover-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        --transition-smooth: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }

    .dashboard-header {
        background: var(--primary-gradient);
        border-radius: 20px;
        padding: 2.5rem;
        margin-bottom: 2.5rem;
        color: white;
        position: relative;
        overflow: hidden;
    }

    .dashboard-header::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 200%;
        background: rgba(255, 255, 255, 0.1);
        transform: rotate(30deg);
    }

    .welcome-text {
        font-size: 1.1rem;
        opacity: 0.9;
        margin-bottom: 0;
    }

    .course-card {
        background: white;
        border-radius: 16px;
        border: none;
        transition: var(--transition-smooth);
        overflow: hidden;
        height: 100%;
        position: relative;
        border-top: 4px solid;
    }

    .course-card:hover {
        transform: translateY(-8px);
        box-shadow: var(--card-hover-shadow);
    }

    .course-image-container {
        height: 140px;
        overflow: hidden;
        border-radius: 12px 12px 0 0;
        position: relative;
    }

    .course-image-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .course-card:hover .course-image-container img {
        transform: scale(1.05);
    }

    .course-icon {
        width: 70px;
        height: 70px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 1rem;
        font-size: 1.8rem;
    }

    .progress-circle {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 0.9rem;
        background: white;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .stat-card {
        background: white;
        border-radius: 16px;
        padding: 1.5rem;
        text-align: center;
        transition: var(--transition-smooth);
        border: 1px solid #eef2f7;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--card-shadow);
    }

    .empty-state {
        background: linear-gradient(135deg, #f8f9ff 0%, #eef2ff 100%);
        border-radius: 16px;
        padding: 4rem 2rem;
        border: 2px dashed #c5d0ff;
    }

    .action-btn {
        padding: 1rem 2rem;
        border-radius: 12px;
        font-weight: 600;
        transition: var(--transition-smooth);
        border: none;
    }

    .progress-bar-animated {
        height: 8px;
        border-radius: 4px;
        background: #e9ecef;
        overflow: hidden;
    }

    .progress-bar-animated .progress-fill {
        height: 100%;
        border-radius: 4px;
        transition: width 1s ease-in-out;
    }

    .badge-pill {
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-weight: 500;
    }
    
    .courses-count-badge {
        background: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        padding: 0.5rem 1.5rem;
        border-radius: 50px;
        font-weight: 600;
        font-size: 1.1rem;
    }
</style>

<div class="container py-5">
    <!-- Header Section -->
    <div class="dashboard-header shadow-lg">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="display-5 fw-bold mb-2">
                    <i class="fas fa-graduation-cap me-3"></i>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Student'); ?>!
                </h1>
                <p class="welcome-text">
                    You have <?php echo $course_count; ?> active course<?php echo $course_count !== 1 ? 's' : ''; ?>
                    · Keep up the great work!
                </p>
            </div>
            <div class="col-md-4 text-end">
                <!-- Enrolled Courses Count Badge -->
                <span class="courses-count-badge">
                    <i class="fas fa-book me-2"></i><?php echo $course_count; ?> Course<?php echo $course_count !== 1 ? 's' : ''; ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold text-dark">
                    <i class="fas fa-book-open text-primary me-2"></i>My Learning Journey
                </h3>
                <span class="badge bg-primary bg-gradient px-3 py-2">
                    <?php echo $course_count; ?> Course<?php echo $course_count !== 1 ? 's' : ''; ?>
                </span>
            </div>
        </div>
    </div>

    <?php if (empty($enrolled_courses)): ?>
        <!-- Empty State -->
        <div class="empty-state text-center my-5">
            <div class="display-1 text-muted mb-4">
                <i class="fas fa-book-reader"></i>
            </div>
            <h3 class="fw-bold text-dark mb-3">No Courses Enrolled Yet</h3>
            <p class="text-muted mb-4">Start your learning journey by exploring our course catalog</p>
            <a href="course_catalog.php" class="btn btn-primary btn-lg px-5 py-3 shadow-sm">
                <i class="fas fa-search me-2"></i>Browse Courses
            </a>
        </div>
    <?php else: ?>
        <!-- Courses Grid -->
        <div class="row g-4">
            <?php foreach ($enrolled_courses as $course): 
                $progress_percent = $course['video_progress_percentage'] ?? 0;
                $quiz_score = $course['quiz_score'] ?? 0;
                
                // Determine progress color and status
                if ($progress_percent >= 80) {
                    $progress_color = 'success';
                    $progress_text = 'Excellent';
                } elseif ($progress_percent >= 50) {
                    $progress_color = 'info';
                    $progress_text = 'Good Progress';
                } else {
                    $progress_color = 'warning';
                    $progress_text = 'Getting Started';
                }
            ?>
                <div class="col-lg-4 col-md-6">
                    <div class="course-card shadow-sm h-100" style="border-top-color: var(--bs-<?php echo $progress_color; ?>)">
                        <!-- Course Image -->
                        <div class="course-image-container">
                            <?php if ($course['course_image']): ?>
                                <img src="<?php echo '../' . htmlspecialchars($course['course_image']); ?>" 
                                     alt="<?php echo htmlspecialchars($course['title']); ?>">
                            <?php else: ?>
                                <div class="h-100 d-flex align-items-center justify-content-center bg-<?php echo $progress_color; ?> bg-opacity-10">
                                    <i class="fas fa-book-reader fa-4x text-<?php echo $progress_color; ?>"></i>
                                </div>
                            <?php endif; ?>
                            <div class="position-absolute top-0 end-0 m-3">
                                <div class="progress-circle bg-<?php echo $progress_color; ?> text-white">
                                    <?php echo (int)$progress_percent; ?>%
                                </div>
                            </div>
                        </div>

                        <!-- Course Content -->
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title fw-bold text-dark mb-0 flex-grow-1">
                                    <?php echo htmlspecialchars($course['title']); ?>
                                </h5>
                            </div>
                            
                            <p class="card-text text-muted mb-4 small">
                                <?php echo substr(htmlspecialchars($course['description']), 0, 100) . '...'; ?>
                            </p>

                            <!-- Progress Section -->
                            <div class="mb-4">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="small fw-semibold text-dark">Progress</span>
                                    <span class="small text-<?php echo $progress_color; ?> fw-bold">
                                        <?php echo $progress_text; ?>
                                    </span>
                                </div>
                                <div class="progress-bar-animated mb-2">
                                    <div class="progress-fill bg-<?php echo $progress_color; ?>" 
                                         style="width: <?php echo $progress_percent; ?>%"></div>
                                </div>
                                <div class="d-flex justify-content-between small text-muted">
                                    <span><?php echo number_format($progress_percent, 1); ?>% Complete</span>
                                    <span><?php echo number_format(100 - $progress_percent, 1); ?>% Remaining</span>
                                </div>
                            </div>

                            <!-- Quiz Score -->
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <span class="small text-dark">
                                    <i class="fas fa-chart-bar text-info me-1"></i> Quiz Score
                                </span>
                                <span class="badge bg-info bg-opacity-10 text-info px-3 py-2 fw-semibold">
                                    <?php echo number_format($quiz_score, 1); ?>%
                                </span>
                            </div>

                            <!-- Action Button -->
                            <div class="d-grid">
                                <a href="view_course.php?id=<?php echo $course['course_id']; ?>" 
                                   class="btn btn-<?php echo $progress_color; ?> btn-lg py-3 fw-semibold">
                                    <i class="fas fa-play-circle me-2"></i>
                                    <?php echo $progress_percent > 0 ? 'Continue Learning' : 'Start Learning'; ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Action Buttons -->
    <div class="row mt-5 g-3">
        <div class="col-md-6">
            <a href="my_progress.php" class="btn btn-outline-success w-100 py-3 action-btn">
                <i class="fas fa-chart-line fa-2x mb-2"></i>
                <div class="fw-bold">Detailed Analytics</div>
                <small class="text-muted">View your learning journey</small>
            </a>
        </div>
        <div class="col-md-6">
            <a href="course_catalog.php" class="btn btn-outline-primary w-100 py-3 action-btn">
                <i class="fas fa-search fa-2x mb-2"></i>
                <div class="fw-bold">Browse Courses</div>
                <small class="text-muted">Explore new subjects</small>
            </a>
        </div>
    </div>

    <!-- Stats Summary -->
    <?php if (!empty($enrolled_courses)): ?>
        <div class="row mt-5">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="fw-bold text-dark mb-4">
                            <i class="fas fa-chart-pie text-primary me-2"></i>Learning Overview
                        </h5>
                        <div class="row text-center">
                            <div class="col-md-3">
                                <div class="h2 fw-bold text-primary">
                                    <?php echo $course_count; ?>
                                </div>
                                <small class="text-muted">Total Courses</small>
                            </div>
                            <div class="col-md-3">
                                <div class="h2 fw-bold text-success">
                                    <?php echo number_format($avg_progress, 1); ?>%
                                </div>
                                <small class="text-muted">Average Progress</small>
                            </div>
                            <div class="col-md-3">
                                <div class="h2 fw-bold text-info">
                                    <?php echo number_format($avg_quiz, 1); ?>%
                                </div>
                                <small class="text-muted">Avg. Quiz Score</small>
                            </div>
                            <div class="col-md-3">
                                <div class="h2 fw-bold text-warning">
                                    <?php echo $completed_courses; ?>
                                </div>
                                <small class="text-muted">Nearly Complete</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
    // Add smooth animation to progress bars
    document.addEventListener('DOMContentLoaded', function() {
        const progressBars = document.querySelectorAll('.progress-fill');
        progressBars.forEach(bar => {
            const targetWidth = bar.style.width;
            bar.style.width = '0%';
            setTimeout(() => {
                bar.style.width = targetWidth;
            }, 300);
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>