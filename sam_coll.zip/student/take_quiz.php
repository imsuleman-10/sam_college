<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$student_id = $_SESSION['user_id'];
$course_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($course_id === 0) {
    header('Location: course_catalog.php');
    exit;
}

$course_title = '';
$quiz_questions = [];
$message = '';
$quiz_status = 'pending'; 

// 1. Fetch Course Title and Quiz Questions
$sql_info = "
    SELECT 
        c.title AS course_title,
        q.quiz_id, q.title AS quiz_title, q.question_text, 
        q.option_a, q.option_b, q.option_c, q.option_d, q.correct_option
    FROM courses c
    JOIN quizzes q ON c.course_id = q.course_id
    WHERE c.course_id = ?
";

if ($stmt_info = $conn->prepare($sql_info)) {
    $stmt_info->bind_param("i", $course_id);
    $stmt_info->execute();
    $result_info = $stmt_info->get_result();
    
    if ($result_info->num_rows > 0) {
        while ($row = $result_info->fetch_assoc()) {
            if (empty($course_title)) {
                $course_title = $row['course_title'];
            }
            $quiz_questions[] = $row;
        }
    } else {
        $_SESSION['message'] = '<div class="alert alert-warning">The admin has not set up questions for this course yet.</div>';
        header("Location: view_course.php?id={$course_id}");
        exit;
    }
    $stmt_info->close();
}

// 2. Handle Quiz Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['quiz_submitted'])) {
    $total_questions = count($quiz_questions);
    $correct_answers = 0;
    
    // Calculate Score
    foreach ($quiz_questions as $question) {
        $q_id = $question['quiz_id'];
        $submitted_answer = $_POST['answer'][$q_id] ?? null;

        // Compare answer (Trim whitespace to be safe)
        if ($submitted_answer !== null && trim($submitted_answer) === trim($question['correct_option'])) {
            $correct_answers++;
        }
    }

    // Calculate Percentage
    $percentage_score = ($total_questions > 0) ? round(($correct_answers / $total_questions) * 100, 2) : 0.00;
    
    // Determine Pass/Fail (Threshold: 50%)
    $is_passed = ($percentage_score >= 50) ? 1 : 0;

    // --- NEW LOGIC: INSERT INTO quiz_attempts ---
    // We use the quiz_id of the first question as the reference ID for the attempt
    // This allows the JOIN in the report to work.
    $reference_quiz_id = $quiz_questions[0]['quiz_id'];

    $sql_insert_attempt = "
        INSERT INTO quiz_attempts (student_id, quiz_id, score, total_questions, passed, attempt_date) 
        VALUES (?, ?, ?, ?, ?, NOW())
    ";

    if ($stmt_attempt = $conn->prepare($sql_insert_attempt)) {
        // i = student_id, i = quiz_id, i = score (raw count), i = total, i = passed
        $stmt_attempt->bind_param("iiiii", $student_id, $reference_quiz_id, $correct_answers, $total_questions, $is_passed);
        $stmt_attempt->execute();
        $stmt_attempt->close();
    } else {
        // Log error if needed: $conn->error
    }

    // --- EXISTING LOGIC: UPDATE AGGREGATE PROGRESS ---
    // Updates the 'best' or 'latest' percentage in the main progress table
    $sql_update_progress = "
        INSERT INTO progress (student_id, course_id, quiz_score)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quiz_score = GREATEST(quiz_score, ?)
    ";
    
    if ($stmt_update = $conn->prepare($sql_update_progress)) {
        $stmt_update->bind_param("iidd", $student_id, $course_id, $percentage_score, $percentage_score);
        $stmt_update->execute();
        $stmt_update->close();
        
        $status_msg = $is_passed ? "Passed" : "Failed";
        $color = $is_passed ? "success" : "warning";
        $message = '<div class="alert alert-'.$color.'">Quiz submitted! You got <strong>'.$correct_answers.'/'.$total_questions.'</strong> correct ('.$percentage_score.'%). Result: <strong>'.$status_msg.'</strong></div>';
    } else {
        $message = '<div class="alert alert-danger">Error saving your score. Please try again.</div>';
    }
    
    $_SESSION['quiz_message'] = $message;
    header("Location: take_quiz.php?id={$course_id}&status=submitted");
    exit;
}

// Check for redirection message
if (isset($_SESSION['quiz_message'])) {
    $message = $_SESSION['quiz_message'];
    unset($_SESSION['quiz_message']);
    $quiz_status = 'submitted';
}

// 4. Check Eligibility (Video Progress >= 60%)
// (Keep this logic only if you want to enforce video watching before quiz)
/* $sql_progress_check = "SELECT video_progress_percentage FROM progress WHERE student_id = ? AND course_id = ?";
... (Your existing check logic here) ...
*/

$page_title = 'Take Quiz: ' . $course_title;
require_once '../includes/header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-pen-fancy text-primary"></i> Quiz for: <?php echo htmlspecialchars($course_title); ?></h2>
        <a href="progress_report.php?course_id=<?php echo $course_id; ?>" class="btn btn-info text-white">
            <i class="fas fa-chart-bar"></i> View Report
        </a>
    </div>

    <?php echo $message; ?>

    <?php if ($quiz_status == 'submitted'): ?>
        <div class="alert alert-light text-center border p-5">
            <h4 class="alert-heading text-success"><i class="fas fa-check-circle"></i> Attempt Recorded</h4>
            <p class="mb-4">Your result has been saved to your progress report.</p>
            <a href="take_quiz.php?id=<?php echo $course_id; ?>" class="btn btn-outline-primary me-2">Retake Quiz</a>
            <a href="progress_report.php?course_id=<?php echo $course_id; ?>" class="btn btn-primary">See Detailed Report</a>
        </div>
    <?php else: ?>
        <div class="card shadow-lg mb-5">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-question-circle me-1"></i> Answer all <?php echo count($quiz_questions); ?> questions
            </div>
            <div class="card-body">
                <form action="take_quiz.php?id=<?php echo $course_id; ?>" method="post">
                    <input type="hidden" name="quiz_submitted" value="1">
                    
                    <?php $q_num = 1; foreach ($quiz_questions as $question): ?>
                        <div class="mb-4 p-3 border rounded bg-light">
                            <h5 class="fw-bold text-dark mb-3">Q<?php echo $q_num++; ?>: <?php echo htmlspecialchars($question['question_text']); ?></h5>
                            
                            <?php 
                            $options = [
                                'A' => $question['option_a'],
                                'B' => $question['option_b'],
                                'C' => $question['option_c'],
                                'D' => $question['option_d'],
                            ];
                            ?>
                            
                            <?php foreach ($options as $key => $value): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" 
                                           name="answer[<?php echo $question['quiz_id']; ?>]" 
                                           id="q<?php echo $question['quiz_id'] . $key; ?>" 
                                           value="<?php echo $key; ?>" required>
                                    <label class="form-check-label" for="q<?php echo $question['quiz_id'] . $key; ?>">
                                        <strong><?php echo $key; ?>.</strong> <?php echo htmlspecialchars($value); ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fas fa-check-double me-2"></i> Submit Answers
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>