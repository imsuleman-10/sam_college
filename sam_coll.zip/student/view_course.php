<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php';
$student_id = $_SESSION['user_id'];
$course_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($course_id === 0) {
    header('Location: course_catalog.php');
    exit;
}

// 1. Fetch Course Data, Enrollment, Progress, and Quiz Count
$sql = "
    SELECT 
        c.title, c.description, c.youtube_iframe_link, c.course_image, c.slides_path,
        e.enrollment_id,
        p.video_progress_percentage, p.quiz_score, p.certificate_status,
        (SELECT COUNT(*) FROM quizzes WHERE course_id = c.course_id) AS total_quizzes
    FROM courses c
    LEFT JOIN enrollments e ON c.course_id = e.course_id AND e.student_id = ?
    LEFT JOIN progress p ON c.course_id = p.course_id AND p.student_id = ?
    WHERE c.course_id = ?
";

$course = null;
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("iii", $student_id, $student_id, $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $course = $result->fetch_assoc();
    }
    $stmt->close();
}

// Check if course exists and student is enrolled
if (!$course || !$course['enrollment_id']) {
    $_SESSION['message'] = '<div class="alert alert-danger">Course not found or you are not enrolled.</div>';
    header('Location: course_catalog.php');
    exit;
}

$video_progress = $course['video_progress_percentage'] ?? 0;
$quiz_score = $course['quiz_score'] ?? 0;
$total_quizzes = $course['total_quizzes'] ?? 0;
$has_slides = !empty($course['slides_path']);

// Eligibility Checks
$video_eligible = $video_progress >= 60.00;
$quiz_eligible = $quiz_score >= 70.00;
$can_take_quiz = $video_eligible && ($total_quizzes >= 5);
$can_apply_for_cert = $video_eligible && $quiz_eligible;

// Extract YouTube Video ID from iframe link
$video_id = ''; 
$iframe_code = htmlspecialchars_decode($course['youtube_iframe_link']);

if (preg_match('/src=["\']([^"\']+?)["\']/i', $iframe_code, $matches)) {
    $src_url = $matches[1];
    
    $patterns = [
        '/youtube\.com\/embed\/([a-zA-Z0-9_-]+)/i',
        '/youtube\.com\/v\/([a-zA-Z0-9_-]+)/i',
        '/youtu\.be\/([a-zA-Z0-9_-]+)/i',
        '/youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/i'
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $src_url, $video_match)) {
            $video_id = $video_match[1];
            break;
        }
    }
    
    if (!$video_id) {
        $query_string = parse_url($src_url, PHP_URL_QUERY);
        if ($query_string) {
            parse_str($query_string, $query_params);
            if (isset($query_params['v'])) {
                $video_id = $query_params['v'];
            }
        }
    }
}

// Handle Certificate Application
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply_cert'])) {
    if ($can_apply_for_cert) {
        $sql_apply = "UPDATE progress SET certificate_status = 'pending' WHERE student_id = ? AND course_id = ?";
        if ($stmt_apply = $conn->prepare($sql_apply)) {
            $stmt_apply->bind_param("ii", $student_id, $course_id);
            if ($stmt_apply->execute()) {
                 $_SESSION['message'] = '<div class="alert alert-info">Certificate application submitted! Awaiting Admin review.</div>';
            } else {
                 $_SESSION['message'] = '<div class="alert alert-danger">Error submitting application.</div>';
            }
            $stmt_apply->close();
        }
    } else {
        $_SESSION['message'] = '<div class="alert alert-warning">You do not yet meet the requirements to apply for a certificate.</div>';
    }
    header("Location: view_course.php?id={$course_id}");
    exit;
}

$conn->close();
$page_title = $course['title'];
require_once '../includes/header.php';
?>

<!-- YouTube IFrame Player API -->
<script src="https://www.youtube.com/iframe_api"></script>

<!-- Professional CSS Styles -->
<style>
    .course-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 2.5rem 0;
        border-radius: 15px;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .course-card {
        border: none;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        margin-bottom: 1.5rem;
    }
    
    .course-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.12);
    }
    
    .card-header {
        border-bottom: none;
        padding: 1.2rem 1.5rem;
        font-weight: 600;
    }
    
    .video-container {
        position: relative;
        padding-bottom: 56.25%;
        height: 0;
        overflow: hidden;
        border-radius: 10px;
        background: #000;
    }
    
    .video-container iframe,
    .video-container #courseVideoPlayer {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
    }
    
    .progress-circle {
        width: 120px;
        height: 120px;
        position: relative;
        margin: 0 auto 1rem;
    }
    
    .progress-circle svg {
        width: 100%;
        height: 100%;
    }
    
    .progress-circle .circle-bg {
        fill: none;
        stroke: #e0e0e0;
        stroke-width: 8;
    }
    
    .progress-circle .circle-progress {
        fill: none;
        stroke-width: 8;
        stroke-linecap: round;
        transform: rotate(-90deg);
        transform-origin: 50% 50%;
        transition: stroke-dashoffset 1s ease;
    }
    
    .stat-card {
        text-align: center;
        padding: 1.5rem;
        border-radius: 12px;
        background: #f8f9fa;
        height: 100%;
    }
    
    .stat-value {
        font-size: 2.2rem;
        font-weight: 700;
        line-height: 1;
        margin-bottom: 0.5rem;
    }
    
    .stat-label {
        font-size: 0.9rem;
        color: #6c757d;
        font-weight: 500;
    }
    
    .badge-custom {
        padding: 0.5rem 1rem;
        font-size: 0.85rem;
        font-weight: 600;
        border-radius: 50px;
    }
    
    .action-btn {
        border-radius: 10px;
        padding: 0.8rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
        border: none;
    }
    
    .action-btn:hover {
        transform: scale(1.03);
    }
    
    .materials-section {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        border-radius: 15px;
        padding: 2rem;
        margin-top: 2rem;
    }
    
    .material-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .material-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    .material-icon {
        font-size: 3rem;
        margin-bottom: 1rem;
        color: #4e73df;
    }
    
    .material-title {
        font-weight: 600;
        margin-bottom: 0.5rem;
        color: #2d3748;
    }
    
    .material-desc {
        color: #718096;
        font-size: 0.9rem;
        margin-bottom: 1rem;
    }
    
    .course-description {
        background: white;
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .requirement-item {
        display: flex;
        align-items: center;
        margin-bottom: 0.8rem;
        padding: 0.8rem;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .requirement-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 1rem;
        flex-shrink: 0;
    }
    
    .requirement-met {
        background: #d4edda;
        color: #155724;
    }
    
    .requirement-not-met {
        background: #f8d7da;
        color: #721c24;
    }
    
    .youtube-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.2rem;
        height: 100%;
    }
    
    .youtube-loading i {
        margin-right: 10px;
        animation: spin 2s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>

<div class="container-fluid px-lg-4 py-4">
    <!-- Course Header -->
    <div class="course-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-2 text-center">
                    <?php if (!empty($course['course_image'])): ?>
                        <img src="../<?php echo htmlspecialchars($course['course_image']); ?>" 
                             alt="Course Logo" 
                             class="rounded-circle shadow-lg"
                             style="width: 120px; height: 120px; object-fit: cover; border: 4px solid white;">
                    <?php else: ?>
                        <div class="rounded-circle bg-white d-flex align-items-center justify-content-center shadow-lg"
                             style="width: 120px; height: 120px; margin: 0 auto;">
                            <i class="fas fa-graduation-cap fa-3x text-primary"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-10">
                    <h1 class="display-5 fw-bold mb-2"><?php echo htmlspecialchars($course['title']); ?></h1>
                    <p class="lead mb-0 opacity-75"><?php echo substr(htmlspecialchars($course['description']), 0, 150); ?>...</p>
                    <div class="mt-3">
                        <span class="badge badge-custom bg-primary me-2">
                            <i class="fas fa-video me-1"></i> Video Course
                        </span>
                        <?php if ($has_slides): ?>
                            <span class="badge badge-custom bg-success me-2">
                                <i class="fas fa-file-pdf me-1"></i> Slides Available
                            </span>
                        <?php endif; ?>
                        <span class="badge badge-custom bg-info">
                            <i class="fas fa-question-circle me-1"></i> <?php echo $total_quizzes; ?> Quizzes
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): 
        echo $_SESSION['message']; 
        unset($_SESSION['message']);
    endif; ?>

    <div class="row">
        <!-- Main Content Column (Video & Materials) -->
        <div class="col-lg-8">
            <!-- Video Player Card -->
            <div class="course-card">
                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-play-circle me-2"></i> Course Video Content
                    </div>
                    <div class="text-warning">
                        <i class="fas fa-clock me-1"></i> Progress: <?php echo $video_progress; ?>%
                    </div>
                </div>
                <div class="card-body p-3">
                    <div class="video-container shadow-sm">
                        <?php if (!empty($video_id)): ?>
                            <div id="courseVideoPlayer" class="youtube-loading">
                                <i class="fas fa-spinner"></i> Loading YouTube Player...
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning m-3">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Video content is currently unavailable.
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="mt-3 text-center">
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i> 
                            Your progress is automatically saved as you watch the video
                        </small>
                    </div>
                </div>
            </div>

            <!-- Course Description -->
            <div class="course-description mt-4">
                <h4 class="mb-3 text-primary">
                    <i class="fas fa-book-open me-2"></i> Course Description
                </h4>
                <p class="mb-0"><?php echo nl2br(htmlspecialchars($course['description'])); ?></p>
            </div>

            <!-- Course Materials Section -->
            <div class="materials-section">
                <h4 class="mb-4 text-center">
                    <i class="fas fa-folder-open me-2"></i> Course Materials
                </h4>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="material-card">
                            <div class="material-icon">
                                <i class="fas fa-file-video text-danger"></i>
                            </div>
                            <h5 class="material-title">Video Lectures</h5>
                            <p class="material-desc">
                                Comprehensive video lectures covering all course topics. 
                                Watch at your own pace.
                            </p>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-danger progress-bar-striped" 
                                     role="progressbar" 
                                     style="width: <?php echo $video_progress; ?>%"
                                     aria-valuenow="<?php echo $video_progress; ?>" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100">
                                    <?php echo $video_progress; ?>%
                                </div>
                            </div>
                            <button class="btn btn-outline-danger btn-sm disabled" style="cursor: default;">
                                <i class="fas fa-eye me-1"></i> Currently Watching
                            </button>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="material-card">
                            <div class="material-icon">
                                <i class="fas fa-file-pdf text-success"></i>
                            </div>
                            <h5 class="material-title">Course Slides</h5>
                            <p class="material-desc">
                                Downloadable PDF slides for offline study and reference.
                            </p>
                            <?php if ($has_slides): ?>
                                <a href="../<?php echo htmlspecialchars($course['slides_path']); ?>" 
                                   target="_blank" 
                                   class="btn btn-success action-btn">
                                    <i class="fas fa-download me-1"></i> Download Slides
                                </a>
                                <p class="text-muted mt-2 mb-0 small">
                                    <i class="fas fa-file-pdf me-1"></i> PDF Format
                                </p>
                            <?php else: ?>
                                <button class="btn btn-outline-secondary btn-sm disabled" style="cursor: default;">
                                    <i class="fas fa-clock me-1"></i> Coming Soon
                                </button>
                                <p class="text-muted mt-2 mb-0 small">
                                    Slides will be available soon
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="material-card">
                            <div class="material-icon">
                                <i class="fas fa-question-circle text-primary"></i>
                            </div>
                            <h5 class="material-title">Practice Quizzes</h5>
                            <p class="material-desc">
                                Test your knowledge with interactive quizzes and assessments.
                            </p>
                            <?php if ($can_take_quiz): ?>
                                <a href="take_quiz.php?id=<?php echo $course_id; ?>" 
                                   class="btn btn-primary action-btn">
                                    <i class="fas fa-pen-fancy me-1"></i> 
                                    <?php echo $quiz_score > 0 ? 'Retake Quiz' : 'Take Quiz'; ?>
                                </a>
                            <?php else: ?>
                                <button class="btn btn-outline-secondary disabled" style="cursor: default;">
                                    <i class="fas fa-lock me-1"></i> Locked
                                </button>
                                <p class="text-muted mt-2 mb-0 small">
                                    Complete 60% video to unlock
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="material-card">
                            <div class="material-icon">
                                <i class="fas fa-medal text-warning"></i>
                            </div>
                            <h5 class="material-title">Certificate</h5>
                            <p class="material-desc">
                                Earn a certificate upon successful completion of all requirements.
                            </p>
                            <?php if ($course['certificate_status'] === 'approved'): ?>
                                <a href="certificate_view.php?course_id=<?php echo $course_id; ?>" 
                                   class="btn btn-warning action-btn text-white">
                                    <i class="fas fa-award me-1"></i> View Certificate
                                </a>
                            <?php elseif ($can_apply_for_cert): ?>
                                <form method="post" class="w-100">
                                    <input type="hidden" name="apply_cert" value="1">
                                    <button type="submit" 
                                            class="btn btn-success action-btn w-100"
                                            onclick="return confirm('Apply for your course completion certificate?');">
                                        <i class="fas fa-file-invoice me-1"></i> Apply for Certificate
                                    </button>
                                </form>
                            <?php else: ?>
                                <button class="btn btn-outline-secondary disabled" style="cursor: default;">
                                    <i class="fas fa-lock me-1"></i> Requirements Pending
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar Column (Progress & Requirements) -->
        <div class="col-lg-4">
            <!-- Progress Overview Card -->
            <div class="course-card">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-chart-line me-2"></i> Progress Overview
                </div>
                <div class="card-body p-4">
                    <!-- Circular Progress -->
                    <div class="progress-circle mb-4">
                        <svg viewBox="0 0 120 120">
                            <circle class="circle-bg" cx="60" cy="60" r="54"></circle>
                            <circle class="circle-progress" 
                                    cx="60" cy="60" r="54" 
                                    stroke="<?php echo $video_eligible ? '#28a745' : '#ffc107'; ?>"
                                    stroke-dasharray="<?php echo 2 * 3.14159 * 54; ?>"
                                    stroke-dashoffset="<?php echo (2 * 3.14159 * 54) - (($video_progress / 100) * 2 * 3.14159 * 54); ?>">
                            </circle>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <div class="stat-value" style="color: <?php echo $video_eligible ? '#28a745' : '#ffc107'; ?>;">
                                <?php echo $video_progress; ?>%
                            </div>
                            <div class="stat-label">Video Completion</div>
                        </div>
                    </div>
                    
                    <!-- Stats Grid -->
                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <div class="stat-card">
                                <div class="stat-value text-info"><?php echo $quiz_score; ?>%</div>
                                <div class="stat-label">Quiz Score</div>
                                <div class="mt-2">
                                    <span class="badge bg-<?php echo $quiz_eligible ? 'success' : 'danger'; ?>">
                                        <?php echo $quiz_eligible ? 'PASS' : 'FAIL'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="stat-card">
                                <div class="stat-value text-success"><?php echo $total_quizzes; ?></div>
                                <div class="stat-label">Total Quizzes</div>
                                <div class="mt-2">
                                    <span class="badge bg-<?php echo $total_quizzes >= 5 ? 'success' : 'warning'; ?>">
                                        <?php echo $total_quizzes >= 5 ? 'Ready' : 'More needed'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Certificate Status -->
                    <div class="text-center">
                        <h6 class="mb-3 text-secondary">
                            <i class="fas fa-certificate me-1"></i> Certificate Status
                        </h6>
                        <?php if ($course['certificate_status'] === 'approved'): ?>
                            <span class="badge bg-success p-3 fs-6">
                                <i class="fas fa-check-circle me-1"></i> CERTIFIED
                            </span>
                        <?php elseif ($course['certificate_status'] === 'pending'): ?>
                            <span class="badge bg-info p-3 fs-6">
                                <i class="fas fa-clock me-1"></i> UNDER REVIEW
                            </span>
                        <?php else: ?>
                            <span class="badge bg-secondary p-3 fs-6">
                                <i class="fas fa-hourglass-half me-1"></i> NOT ELIGIBLE
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Requirements Card -->
            <div class="course-card mt-4">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-tasks me-2"></i> Course Requirements
                </div>
                <div class="card-body p-3">
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $video_eligible ? 'requirement-met' : 'requirement-not-met'; ?>">
                            <?php if ($video_eligible): ?>
                                <i class="fas fa-check"></i>
                            <?php else: ?>
                                <i class="fas fa-times"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <strong>Video Completion ≥ 60%</strong><br>
                            <small class="text-muted">Current: <?php echo $video_progress; ?>%</small>
                        </div>
                    </div>
                    
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $quiz_eligible ? 'requirement-met' : 'requirement-not-met'; ?>">
                            <?php if ($quiz_eligible): ?>
                                <i class="fas fa-check"></i>
                            <?php else: ?>
                                <i class="fas fa-times"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <strong>Quiz Score ≥ 70%</strong><br>
                            <small class="text-muted">Current: <?php echo $quiz_score; ?>%</small>
                        </div>
                    </div>
                    
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $total_quizzes >= 5 ? 'requirement-met' : 'requirement-not-met'; ?>">
                            <?php if ($total_quizzes >= 5): ?>
                                <i class="fas fa-check"></i>
                            <?php else: ?>
                                <i class="fas fa-times"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <strong>Minimum 5 Quizzes</strong><br>
                            <small class="text-muted">Available: <?php echo $total_quizzes; ?> quizzes</small>
                        </div>
                    </div>
                    
                    <div class="requirement-item">
                        <div class="requirement-icon <?php echo $has_slides ? 'requirement-met' : 'requirement-not-met'; ?>">
                            <?php if ($has_slides): ?>
                                <i class="fas fa-check"></i>
                            <?php else: ?>
                                <i class="fas fa-times"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <strong>Course Materials</strong><br>
                            <small class="text-muted">Slides: <?php echo $has_slides ? 'Available' : 'Not available'; ?></small>
                        </div>
                    </div>
                    
                    <hr class="my-3">
                    
                    <div class="text-center">
                        <p class="mb-2">
                            <strong>Overall Completion:</strong>
                            <span class="ms-2 badge bg-<?php 
                                echo ($video_eligible && $quiz_eligible) ? 'success' : 'warning'; 
                            ?>">
                                <?php 
                                $completion = 0;
                                if ($video_eligible) $completion += 50;
                                if ($quiz_eligible) $completion += 50;
                                echo $completion; 
                                ?>%
                            </span>
                        </p>
                        <?php if ($can_apply_for_cert): ?>
                            <form method="post" class="mt-3">
                                <input type="hidden" name="apply_cert" value="1">
                                <button type="submit" 
                                        class="btn btn-success action-btn w-100"
                                        onclick="return confirm('Ready to submit your certificate application?');">
                                    <i class="fas fa-file-certificate me-2"></i> 
                                    APPLY FOR CERTIFICATE
                                </button>
                            </form>
                        <?php elseif ($video_eligible && !$quiz_eligible && $total_quizzes >= 5): ?>
                            <a href="take_quiz.php?id=<?php echo $course_id; ?>" 
                               class="btn btn-primary action-btn w-100">
                                <i class="fas fa-pen-alt me-2"></i> 
                                TAKE QUIZ NOW
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Quick Actions Card -->
            <div class="course-card mt-4">
                <div class="card-header bg-dark text-white">
                    <i class="fas fa-bolt me-2"></i> Quick Actions
                </div>
                <div class="card-body p-3">
                    <div class="d-grid gap-2">
                        <a href="course_catalog.php" class="btn btn-outline-primary action-btn">
                            <i class="fas fa-list-alt me-2"></i> Back to Course Catalog
                        </a>
                        <a href="dashboard.php" class="btn btn-outline-secondary action-btn">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                        <?php if ($quiz_score > 0): ?>
                            <!-- <a href="quiz_results.php?course_id=<?php echo $course_id; ?>" 
                               class="btn btn-outline-info action-btn">
                                <i class="fas fa-chart-bar me-2"></i> View Quiz Results
                            </a> -->
                        <?php endif; ?>
                        <a href="progress_report.php?course_id=<?php echo $course_id; ?>" class="btn btn-outline-warning action-btn">
                            <i class="fas fa-print me-2"></i> Print Progress Report
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for YouTube Player and Progress Tracking -->
<!-- JavaScript for YouTube Player and Progress Tracking -->
<script>
// Global variables
let player;
let playerInitialized = false;
let progressInterval = null;
const TRACKING_INTERVAL = 5000; // Track every 5 seconds (بڑھایا ہے)

// PHP variables
const currentCourseId = <?php echo $course_id; ?>;
const initialProgress = <?php echo $video_progress; ?>;
const wasVideoEligible = <?php echo $video_eligible ? 'true' : 'false'; ?>;
const youtubeVideoId = "<?php echo $video_id; ?>";

// پچھلی پروگریس لوڈ کرنے کے لیے
let lastSavedProgress = initialProgress;

// YouTube API ready callback
function onYouTubeIframeAPIReady() {
    console.log('YouTube API is ready');
    
    if (youtubeVideoId) {
        initializeYouTubePlayer();
    }
}

// Initialize YouTube Player
function initializeYouTubePlayer() {
    if (!youtubeVideoId) {
        console.error('No Video ID provided');
        document.getElementById('courseVideoPlayer').innerHTML = 
            '<div class="alert alert-danger m-3">Error: Invalid Video ID</div>';
        return;
    }
    
    try {
        player = new YT.Player('courseVideoPlayer', {
            height: '100%',
            width: '100%',
            videoId: youtubeVideoId,
            playerVars: {
                'autoplay': 0, // Auto-play نہیں
                'controls': 1,
                'rel': 0,
                'modestbranding': 1,
                'showinfo': 0,
                'fs': 1
            },
            events: {
                'onReady': onPlayerReady,
                'onStateChange': onPlayerStateChange,
                'onError': onPlayerError
            }
        });
        
        playerInitialized = true;
        console.log('YouTube Player initialized successfully');
        
    } catch (error) {
        console.error('Error initializing YouTube player:', error);
        showVideoError('Failed to load video player: ' + error.message);
    }
}

// Player ready callback
function onPlayerReady(event) {
    console.log('YouTube Player is ready');
    // Remove loading message
    const playerElement = document.getElementById('courseVideoPlayer');
    if (playerElement && playerElement.classList.contains('youtube-loading')) {
        playerElement.classList.remove('youtube-loading');
        playerElement.innerHTML = '';
    }
    
    // پچھلی پروگریس پر ویڈیو سیٹ کریں
    if (initialProgress > 0) {
        const duration = player.getDuration();
        if (duration > 0) {
            // پروگریس کے مطابق وقت کا حساب لگائیں
            const seekTime = (initialProgress / 100) * duration;
            // ویڈیو کو پچھلی جگہ پر سیٹ کریں (لیکن نہ چلائیں)
            player.seekTo(seekTime, true);
            console.log('Video set to previous progress: ' + initialProgress + '% (' + seekTime.toFixed(0) + 's)');
        }
    }
}

// Player state change handler
function onPlayerStateChange(event) {
    // Start tracking when playing
    if (event.data === YT.PlayerState.PLAYING) {
        startProgressTracking();
    } else if (event.data === YT.PlayerState.PAUSED || 
               event.data === YT.PlayerState.ENDED) {
        stopProgressTracking();
        
        // If video ended, update to 100%
        if (event.data === YT.PlayerState.ENDED) {
            updateProgress(100);
            showNotification('Video completed! Progress saved.', 'success');
        }
    }
}

// Player error handler
function onPlayerError(event) {
    console.error('YouTube Player Error:', event.data);
    showVideoError('Video playback error. Please try again later.');
}

// Show video error
function showVideoError(message) {
    document.getElementById('courseVideoPlayer').innerHTML = 
        '<div class="alert alert-danger m-3">' +
        '<i class="fas fa-exclamation-triangle me-2"></i>' +
        message +
        '</div>';
}

// Start progress tracking
function startProgressTracking() {
    if (progressInterval) return;
    
    progressInterval = setInterval(() => {
        trackProgress();
    }, TRACKING_INTERVAL);
    
    console.log('Progress tracking started');
}

// Stop progress tracking
function stopProgressTracking() {
    if (progressInterval) {
        clearInterval(progressInterval);
        progressInterval = null;
        console.log('Progress tracking stopped');
    }
}

// Track progress - ہر 5 سیکنڈ بعد
function trackProgress() {
    if (!player || !player.getDuration || !player.getCurrentTime) return;
    
    try {
        const duration = player.getDuration();
        const currentTime = player.getCurrentTime();
        
        if (duration > 0) {
            const percentage = Math.floor((currentTime / duration) * 100);
            // 100% سے زیادہ نہ ہو
            const cappedPercentage = Math.min(100, percentage);
            updateProgress(cappedPercentage);
        }
    } catch (error) {
        console.error('Error tracking progress:', error);
    }
}

// Update progress
function updateProgress(percentage) {
    // Only update if progress increased (کم از کم 1% زیادہ)
    if (percentage > lastSavedProgress + 1) {
        console.log('Updating progress from ' + lastSavedProgress + '% to ' + percentage + '%');
        
        // Update UI
        updateProgressUI(percentage);
        
        // Send to server
        sendProgressToServer(percentage);
        
        // Update last saved progress
        lastSavedProgress = percentage;
        
        // Check for quiz unlock
        if (percentage >= 60 && !wasVideoEligible) {
            unlockQuiz();
        }
    }
}

// کویز کو انلاک کرنے کا فنکشن
function unlockQuiz() {
    console.log('Quiz unlocked! 60% progress reached.');
    
    // اگر پہلے سے انلاک نہیں ہے تو UI اپڈیٹ کریں
    if (!wasVideoEligible) {
        // کویز کے بٹن کو اپڈیٹ کریں
        const quizButton = document.querySelector('a[href*="take_quiz.php"]');
        if (quizButton) {
            quizButton.classList.remove('disabled');
            quizButton.classList.remove('btn-outline-secondary');
            quizButton.classList.add('btn-primary');
            quizButton.style.cursor = 'pointer';
            
            // ٹیکسٹ تبدیل کریں
            const quizText = quizButton.querySelector('i').nextSibling;
            if (quizText) {
                quizText.textContent = ' Take Quiz';
            }
        }
        
        // مواد سیکشن میں میسج
        const quizCard = document.querySelector('.material-card:nth-child(3) .material-desc');
        if (quizCard) {
            quizCard.innerHTML = 'You can now take the quiz! Complete 70% to pass.';
        }
        
        // ریکویئرمنٹس سیکشن اپڈیٹ کریں
        const requirementIcon = document.querySelector('.requirement-item:nth-child(1) .requirement-icon');
        if (requirementIcon) {
            requirementIcon.className = 'requirement-icon requirement-met';
            requirementIcon.innerHTML = '<i class="fas fa-check"></i>';
        }
        
        // نوٹیفکیشن دکھائیں
        showNotification('Quiz unlocked! You can now take the course quiz.', 'success');
        
        // Save in session that quiz is now unlocked
        sessionStorage.setItem('quiz_unlocked_' + currentCourseId, 'true');
    }
}

// Update UI elements
function updateProgressUI(percentage) {
    // Progress bar update
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = percentage + '%';
        progressBar.setAttribute('aria-valuenow', percentage);
        progressBar.textContent = percentage + '%';
    }
    
    // Circular progress update
    const circle = document.querySelector('.circle-progress');
    if (circle) {
        const radius = 54;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (percentage / 100) * circumference;
        circle.style.strokeDashoffset = offset;
        
        // رنگ تبدیل کریں اگر 60% ہو جائے
        if (percentage >= 60) {
            circle.style.stroke = '#28a745';
        }
    }
    
    // Stat value update
    const statValue = document.querySelector('.stat-value');
    if (statValue) {
        statValue.textContent = percentage + '%';
        if (percentage >= 60) {
            statValue.style.color = '#28a745';
        }
    }
    
    // Header progress update
    const headerProgress = document.querySelector('.card-header .text-warning');
    if (headerProgress) {
        headerProgress.innerHTML = '<i class="fas fa-clock me-1"></i> Progress: ' + percentage + '%';
    }
    
    // Video requirement text update
    const requirementText = document.querySelector('.requirement-item:nth-child(1) small.text-muted');
    if (requirementText) {
        requirementText.textContent = 'Current: ' + percentage + '%';
    }
}

// Send progress to server - درست راستہ
function sendProgressToServer(percentage) {
    console.log('Sending progress to server:', percentage);
    
    // FormData استعمال کریں
    const formData = new FormData();
    formData.append('course_id', currentCourseId);
    formData.append('progress', percentage);
    
    fetch('update_progress.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            console.log('Progress saved successfully:', data.message);
            
            // اگر 60% ہو گیا ہے تو UI اپڈیٹ کریں
            if (percentage >= 60) {
                // چیک کریں کہ پہلے سے انلاک نہیں ہے
                if (!wasVideoEligible) {
                    // ریفرش کے بغیر UI اپڈیٹ کریں
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                }
            }
        } else {
            console.error('Error saving progress:', data.error);
            showNotification('Failed to save progress. Please try again.', 'danger');
        }
    })
    .catch(error => {
        console.error('AJAX error:', error);
        showNotification('Network error. Progress may not be saved.', 'warning');
        
        // Local storage میں محفوظ کریں
        try {
            localStorage.setItem('unsaved_progress_' + currentCourseId, percentage);
            localStorage.setItem('unsaved_progress_time_' + currentCourseId, Date.now());
        } catch (e) {
            console.log('Local storage not available');
        }
    });
}

// Notification function
function showNotification(message, type = 'info', reload = false) {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = `
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    `;
    
    notification.innerHTML = `
        <strong>${type === 'success' ? '✓' : 'ℹ'}</strong> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
        if (reload) {
            setTimeout(() => window.location.reload(), 1000);
        }
    }, 3000);
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded, initializing...');
    console.log('Initial progress:', initialProgress);
    console.log('Quiz eligible:', wasVideoEligible);
    
    // If YouTube API is already loaded
    if (typeof YT !== 'undefined' && YT.loaded && youtubeVideoId) {
        console.log('YouTube API already loaded, initializing player...');
        initializeYouTubePlayer();
    } else if (youtubeVideoId) {
        console.log('Waiting for YouTube API...');
        // Show loading state
        const playerElement = document.getElementById('courseVideoPlayer');
        if (playerElement) {
            playerElement.innerHTML = '<div class="youtube-loading"><i class="fas fa-spinner"></i> Loading YouTube Player...</div>';
        }
        
        // Fallback if API fails to load
        setTimeout(function() {
            if (!playerInitialized) {
                console.warn('YouTube API failed to load, showing fallback');
                showVideoError('YouTube player failed to load. Please refresh the page.');
            }
        }, 10000);
    }
    
    // Animate progress circle
    setTimeout(() => {
        const circle = document.querySelector('.circle-progress');
        if (circle) {
            circle.style.transition = 'stroke-dashoffset 1.5s ease-in-out';
        }
    }, 500);
    
    // Check for any unsaved progress in local storage
    checkUnsavedProgress();
});

// چیک کریں کہ کوئی ان سیوڈ پروگریس لوکل سٹوریج میں ہے
function checkUnsavedProgress() {
    try {
        const unsavedProgress = localStorage.getItem('unsaved_progress_' + currentCourseId);
        const unsavedTime = localStorage.getItem('unsaved_progress_time_' + currentCourseId);
        
        if (unsavedProgress && unsavedTime) {
            const timeDiff = Date.now() - unsavedTime;
            // اگر 1 گھنٹے کے اندر کی ہے تو سینڈ کریں
            if (timeDiff < 3600000) {
                const progressNum = parseInt(unsavedProgress);
                if (progressNum > initialProgress) {
                    console.log('Found unsaved progress:', progressNum);
                    sendProgressToServer(progressNum);
                }
            }
            // کلئیر کر دیں
            localStorage.removeItem('unsaved_progress_' + currentCourseId);
            localStorage.removeItem('unsaved_progress_time_' + currentCourseId);
        }
    } catch (e) {
        // Ignore errors
    }
}

// ویڈیو چلانے/روکنے کے بٹن
document.addEventListener('click', function(e) {
    // اگر کوئی ویڈیو کنٹرول پر کلک کرے تو چیک کریں
    if (e.target.closest('.ytp-play-button, .ytp-play-button-icon')) {
        setTimeout(() => {
            if (player && player.getPlayerState() === 1) { // PLAYING
                startProgressTracking();
            }
        }, 100);
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>