<?php
session_start();

// Check if user is logged in as a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/db.php'; 

$student_id = $_SESSION['user_id'];
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if ($course_id === 0) {
    die("Error: Course ID not specified.");
}

$reportData = [
    'student_name' => 'N/A',
    'course_title' => 'N/A',
    'progress_percent' => 0,
    'certificate_status' => 'Pending',
    'total_attempts' => 0,
    'highest_score' => 'N/A',
];
$detailedAttempts = [];
$error_message = null;

try {
    // 1. Fetch Student Name, Course Info, and Video Progress
    $sqlSummary = "
        SELECT 
            u.name AS student_name,
            c.title AS course_title,
            p.video_progress_percentage,
            p.certificate_status
        FROM users u
        JOIN enrollments e ON u.user_id = e.student_id
        JOIN courses c ON e.course_id = c.course_id
        LEFT JOIN progress p ON c.course_id = p.course_id AND p.student_id = u.user_id
        WHERE u.user_id = ? AND c.course_id = ?
    ";

    if ($stmtSummary = $conn->prepare($sqlSummary)) {
        $stmtSummary->bind_param("ii", $student_id, $course_id);
        $stmtSummary->execute();
        $resultSummary = $stmtSummary->get_result();
        $summaryRow = $resultSummary->fetch_assoc();

        if ($summaryRow) {
            $reportData['student_name'] = htmlspecialchars($summaryRow['student_name']);
            $reportData['course_title'] = htmlspecialchars($summaryRow['course_title']);
            $reportData['progress_percent'] = intval($summaryRow['video_progress_percentage'] ?? 0);
            $reportData['certificate_status'] = $summaryRow['certificate_status'] ?? 'Pending';
        } else {
            // If just enrolled but no progress record yet, fetch basics
             $reportData['student_name'] = "Student"; 
        }
        $stmtSummary->close();
    }
    
    // 2. Fetch Quiz Attempts Summary (Max Score and Total Attempts)
    // We filter by course_id using the join to quizzes table
    $sqlQuizSummary = "
        SELECT 
            COUNT(qa.attempt_id) AS total_attempts,
            (
                SELECT CONCAT(score, '/', total_questions) 
                FROM quiz_attempts sub_qa
                JOIN quizzes sub_q ON sub_qa.quiz_id = sub_q.quiz_id
                WHERE sub_qa.student_id = ? AND sub_q.course_id = ?
                ORDER BY (score / NULLIF(total_questions, 0)) DESC, attempt_date DESC 
                LIMIT 1
            ) AS highest_score_text
        FROM quiz_attempts qa
        JOIN quizzes q ON qa.quiz_id = q.quiz_id
        WHERE qa.student_id = ? AND q.course_id = ?
    ";

    if ($stmtQuiz = $conn->prepare($sqlQuizSummary)) {
        $stmtQuiz->bind_param("iiii", $student_id, $course_id, $student_id, $course_id);
        $stmtQuiz->execute();
        $resultQuiz = $stmtQuiz->get_result();
        $quizSummary = $resultQuiz->fetch_assoc();
        
        if ($quizSummary) {
            $reportData['total_attempts'] = intval($quizSummary['total_attempts']);
            if (!empty($quizSummary['highest_score_text'])) {
                $reportData['highest_score'] = $quizSummary['highest_score_text'];
            }
        }
        $stmtQuiz->close();
    }
    
    // 3. Fetch Detailed Quiz Attempts List
    $sqlDetails = "
        SELECT 
            qa.attempt_id,
            qa.score,             
            qa.total_questions,   
            qa.passed,
            qa.attempt_date,
            q.title AS quiz_title
        FROM quiz_attempts qa
        JOIN quizzes q ON qa.quiz_id = q.quiz_id
        WHERE qa.student_id = ? AND q.course_id = ?
        ORDER BY qa.attempt_date DESC
    ";

    if ($stmtDetails = $conn->prepare($sqlDetails)) {
        $stmtDetails->bind_param("ii", $student_id, $course_id);
        $stmtDetails->execute();
        $detailedAttempts = $stmtDetails->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmtDetails->close();
    }

} catch (Exception $e) {
    $error_message = $e->getMessage();
}

$conn->close();
$page_title = 'Progress Report: ' . $reportData['course_title'];
require_once '../includes/header.php'; 
?>

<style>
    body { background-color: #f4f6f9; font-family: 'Arial', sans-serif; }
    .report-card-container { max-width: 900px; margin: 40px auto; }
    .report-card {
        background: #ffffff; border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); padding: 40px;
        border-top: 5px solid #007bff;
    }
    .summary-box {
        background-color: #f8f9fa; border-radius: 10px;
        padding: 20px; text-align: center; border: 1px solid #e9ecef;
    }
    .summary-box h3 { font-size: 2rem; font-weight: 700; margin-top: 10px; }
    .status-issued { background-color: #d4edda; color: #155724; padding: 5px 10px; border-radius: 5px; }
    .status-pending { background-color: #fff3cd; color: #856404; padding: 5px 10px; border-radius: 5px; }
    @media print { .no-print { display: none; } }
</style>

<div class="report-card-container">
    <div class="report-card">
        <div class="text-center mb-4">
            <h1 class="h3">Student Progress Report</h1>
            <h2 class="h5 text-primary"><?php echo $reportData['course_title']; ?></h2>
            <p class="text-muted">Student: <?php echo $reportData['student_name']; ?></p>
        </div>

        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php else: ?>
            
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="summary-box">
                        <small>Video Progress</small>
                        <h3 class="text-success"><?php echo $reportData['progress_percent']; ?>%</h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="summary-box">
                        <small>Best Quiz Score</small>
                        <h3 class="text-primary"><?php echo $reportData['highest_score']; ?></h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="summary-box">
                        <small>Attempts</small>
                        <h3 class="text-dark"><?php echo $reportData['total_attempts']; ?></h3>
                    </div>
                </div>
            </div>

            <div class="text-center mb-4">
                <strong>Certificate Status: </strong>
                <span class="<?php echo ($reportData['certificate_status'] == 'Issued') ? 'status-issued' : 'status-pending'; ?>">
                    <?php echo $reportData['certificate_status']; ?>
                </span>
            </div>

            <h4 class="h6 border-bottom pb-2 mb-3">Quiz Attempt History</h4>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-primary">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Score (Correct/Total)</th>
                            <th>Percentage</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($detailedAttempts)): ?>
                            <tr><td colspan="5" class="text-center">No attempts yet.</td></tr>
                        <?php else: ?>
                            <?php $i=1; foreach ($detailedAttempts as $attempt): ?>
                                <?php 
                                    $percent = ($attempt['total_questions'] > 0) 
                                        ? round(($attempt['score'] / $attempt['total_questions']) * 100) 
                                        : 0;
                                ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo date('M d, Y - h:i A', strtotime($attempt['attempt_date'])); ?></td>
                                    <td class="fw-bold"><?php echo $attempt['score'] . ' / ' . $attempt['total_questions']; ?></td>
                                    <td><?php echo $percent; ?>%</td>
                                    <td>
                                        <?php if ($attempt['passed']): ?>
                                            <span class="badge bg-success">Passed</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Failed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </div>
    
    <div class="text-center mt-3 no-print">
        <button onclick="window.print()" class="btn btn-secondary">Print Report</button>
        <a href="../course_detail.php?id=<?php echo $course_id; ?>" class="btn btn-outline-primary">Back to Course</a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>