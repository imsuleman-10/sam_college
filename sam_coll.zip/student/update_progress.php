<?php
// file: update_progress.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_SESSION['user_id'];
    $course_id = isset($_POST['course_id']) ? intval($_POST['course_id']) : 0;
    $progress = isset($_POST['progress']) ? floatval($_POST['progress']) : 0;
    
    if ($course_id === 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid course ID']);
        exit;
    }
    
    // Ensure progress is between 0-100
    $progress = min(100, max(0, $progress));
    
    // چیک کریں کہ enrollment ہے
    $check_enrollment = "SELECT enrollment_id FROM enrollments WHERE student_id = ? AND course_id = ?";
    if ($stmt_check = $conn->prepare($check_enrollment)) {
        $stmt_check->bind_param("ii", $student_id, $course_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        
        if ($result_check->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Not enrolled in this course']);
            $stmt_check->close();
            $conn->close();
            exit;
        }
        $stmt_check->close();
    }
    
    // Check if progress record exists
    $check_sql = "SELECT * FROM progress WHERE student_id = ? AND course_id = ?";
    if ($stmt = $conn->prepare($check_sql)) {
        $stmt->bind_param("ii", $student_id, $course_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Update existing progress - صرف اگر نیا زیادہ ہو
            $row = $result->fetch_assoc();
            $current_progress = $row['video_progress_percentage'] ?? 0;
            
            if ($progress > $current_progress) {
                $update_sql = "UPDATE progress SET video_progress_percentage = ? WHERE student_id = ? AND course_id = ?";
                if ($update_stmt = $conn->prepare($update_sql)) {
                    $update_stmt->bind_param("dii", $progress, $student_id, $course_id);
                    if ($update_stmt->execute()) {
                        echo json_encode([
                            'success' => true, 
                            'message' => 'Progress updated',
                            'new_progress' => $progress,
                            'was_updated' => true
                        ]);
                    } else {
                        echo json_encode(['success' => false, 'error' => 'Update failed: ' . $conn->error]);
                    }
                    $update_stmt->close();
                }
            } else {
                // No update needed
                echo json_encode([
                    'success' => true, 
                    'message' => 'Progress not updated (current progress is higher)',
                    'new_progress' => $current_progress,
                    'was_updated' => false
                ]);
            }
        } else {
            // Insert new progress record
            $insert_sql = "INSERT INTO progress (student_id, course_id, video_progress_percentage, quiz_score, certificate_status) 
                           VALUES (?, ?, ?, 0, 'not_applied')";
            if ($insert_stmt = $conn->prepare($insert_sql)) {
                $insert_stmt->bind_param("iid", $student_id, $course_id, $progress);
                if ($insert_stmt->execute()) {
                    echo json_encode([
                        'success' => true, 
                        'message' => 'Progress created',
                        'new_progress' => $progress,
                        'was_updated' => true
                    ]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Insert failed: ' . $conn->error]);
                }
                $insert_stmt->close();
            }
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
    }
    
    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>