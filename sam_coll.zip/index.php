<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$page_title = 'Welcome to SAM College E-Learning Portal';
require_once 'includes/header.php';
?>

<style>
    :root {
        --primary: #2563eb;
        --primary-light: #60a5fa;
        --primary-lighter: #dbeafe;
        --accent: #06b6d4;
        --accent-light: #67e8f9;
        --secondary: #f59e0b;
        --secondary-light: #fcd34d;
        --warning: #f97316;
        --success: #10b981;
        --gradient-primary: linear-gradient(135deg, #2563eb 0%, #06b6d4 100%);
        --gradient-secondary: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);
        --gradient-light: linear-gradient(135deg, #f0f9ff 0%, #fefce8 100%);
        --text-primary: #1e293b;
        --text-secondary: #64748b;
        --text-light: #475569;
        --bg-primary: #ffffff;
        --bg-secondary: #f8fafc;
        --bg-accent: #f0f9ff;
        --border: #e2e8f0;
        --border-light: #f1f5f9;
        --shadow-sm: 0 4px 12px rgba(15, 23, 42, 0.04);
        --shadow-md: 0 12px 32px rgba(15, 23, 42, 0.08);
        --shadow-lg: 0 24px 48px rgba(15, 23, 42, 0.1);
        --radius-lg: 24px;
        --radius-md: 16px;
        --radius-sm: 12px;
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        background: var(--bg-primary);
        color: var(--text-primary);
        line-height: 1.7;
        overflow-x: hidden;
    }

    /* Modern Container */
    .container {
        max-width: 1280px;
        margin: 0 auto;
        padding: 0 24px;
    }

    /* Hero Section - Redesigned */
    .hero-section {
        min-height: 100vh;
        background: var(--gradient-light);
        display: flex;
        align-items: center;
        position: relative;
        overflow: hidden;
        padding: 120px 0 80px;
    }

    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 100%;
        background: 
            radial-gradient(circle at 10% 20%, rgba(37, 99, 235, 0.03) 0%, transparent 50%),
            radial-gradient(circle at 90% 80%, rgba(6, 182, 212, 0.03) 0%, transparent 50%);
    }

    .hero-content {
        position: relative;
        z-index: 2;
        text-align: center;
        max-width: 900px;
        margin: 0 auto;
    }

    .hero-title {
        font-size: clamp(2.75rem, 5vw, 4.5rem);
        font-weight: 800;
        line-height: 1.1;
        color: var(--text-primary);
        margin-bottom: 1.5rem;
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .hero-subtitle {
        font-size: clamp(1.1rem, 2vw, 1.3rem);
        color: var(--text-secondary);
        max-width: 700px;
        margin: 0 auto 3rem;
        font-weight: 400;
    }

    /* Enhanced Buttons */
    .btn {
        padding: 16px 36px;
        font-size: 1.05rem;
        font-weight: 600;
        border-radius: var(--radius-md);
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        position: relative;
        overflow: hidden;
        text-decoration: none;
        border: none;
        cursor: pointer;
        box-shadow: var(--shadow-sm);
    }

    .btn-primary {
        background: var(--gradient-primary);
        color: white;
    }

    .btn-primary:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-md);
    }

    .btn-secondary {
        background: white;
        color: var(--primary);
        border: 2px solid var(--border);
        backdrop-filter: blur(10px);
    }

    .btn-secondary:hover {
        background: var(--primary-lighter);
        border-color: var(--primary-light);
        transform: translateY(-4px);
    }

    .btn-ghost {
        background: transparent;
        color: var(--text-secondary);
        border: 2px solid transparent;
    }

    .btn-ghost:hover {
        color: var(--primary);
        background: var(--primary-lighter);
    }

    /* Modern Card Styles */
    .welcome-card {
        background: white;
        backdrop-filter: blur(20px);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        padding: 2.5rem;
        max-width: 700px;
        margin: 0 auto;
        box-shadow: var(--shadow-lg);
        position: relative;
        overflow: hidden;
    }

    .welcome-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: var(--gradient-primary);
    }

    .user-avatar {
        width: 80px;
        height: 80px;
        background: var(--gradient-primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        color: white;
        box-shadow: var(--shadow-md);
    }

    /* Stats Section - Enhanced */
    .stats-section {
        padding: 100px 0;
        background: var(--bg-secondary);
        position: relative;
    }

    .stats-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 100px;
        background: linear-gradient(to bottom, white, transparent);
    }

    .stat-card {
        background: white;
        border-radius: var(--radius-lg);
        padding: 2.5rem;
        text-align: center;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        border: 1px solid var(--border-light);
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }

    .stat-card::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: var(--gradient-primary);
        opacity: 0;
        transition: var(--transition);
    }

    .stat-card:hover::after {
        opacity: 1;
    }

    .stat-card:hover {
        transform: translateY(-8px);
        box-shadow: var(--shadow-md);
        border-color: var(--primary-light);
    }

    .stat-number {
        font-size: 3.5rem;
        font-weight: 800;
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        line-height: 1;
        margin-bottom: 0.5rem;
    }

    /* Features Section - Redesigned */
    .features-section {
        padding: 120px 0;
        background: white;
    }

    .section-title {
        font-size: clamp(2.25rem, 4vw, 3.25rem);
        font-weight: 800;
        text-align: center;
        margin-bottom: 1rem;
        color: var(--text-primary);
        position: relative;
        display: inline-block;
        left: 50%;
        transform: translateX(-50%);
    }

    .section-title::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 25%;
        width: 50%;
        height: 4px;
        background: var(--gradient-primary);
        border-radius: 2px;
    }

    .section-subtitle {
        text-align: center;
        color: var(--text-secondary);
        max-width: 700px;
        margin: 1.5rem auto 4rem;
        font-size: 1.15rem;
    }

    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 2rem;
    }

    .feature-card {
        background: white;
        border-radius: var(--radius-lg);
        padding: 2.5rem;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        border: 1px solid var(--border);
        height: 100%;
        position: relative;
    }

    .feature-card:hover {
        transform: translateY(-12px);
        box-shadow: var(--shadow-lg);
        border-color: var(--primary-light);
    }

    .feature-icon {
        width: 80px;
        height: 80px;
        background: var(--gradient-primary);
        border-radius: var(--radius-md);
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 1.5rem;
        color: white;
        font-size: 2rem;
        box-shadow: var(--shadow-md);
    }

    .feature-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: var(--text-primary);
    }

    .feature-card .text-secondary {
        color: var(--text-light);
        font-size: 1.05rem;
    }

    /* Admin Section - Light Theme */
    .admin-section {
        padding: 120px 0;
        background: var(--bg-accent);
        position: relative;
        overflow: hidden;
    }

    .admin-section::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 80%;
        height: 200%;
        background: radial-gradient(circle, rgba(37, 99, 235, 0.05) 0%, transparent 70%);
        pointer-events: none;
    }

    .admin-section .section-title {
        color: var(--text-primary);
    }

    .admin-card {
        background: white;
        border-radius: var(--radius-lg);
        padding: 3rem;
        border: 1px solid var(--border);
        display: flex;
        gap: 3rem;
        align-items: center;
        box-shadow: var(--shadow-lg);
        position: relative;
        z-index: 1;
        max-width: 1000px;
        margin: 0 auto;
    }

    .admin-avatar {
        width: 160px;
        height: 160px;
        border-radius: 50%;
        object-fit: cover;
        border: 6px solid white;
        box-shadow: var(--shadow-lg);
    }

    .admin-title {
        font-size: 2.25rem;
        font-weight: 700;
        margin-bottom: 1rem;
        color: var(--text-primary);
    }

    .admin-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        margin-top: 1.5rem;
    }

    .admin-badge {
        background: var(--primary-lighter);
        padding: 10px 20px;
        border-radius: 9999px;
        font-size: 0.9rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
        border: 1px solid var(--border);
        color: var(--primary);
        transition: var(--transition);
    }

    .admin-badge:hover {
        background: white;
        transform: translateY(-2px);
        box-shadow: var(--shadow-sm);
    }

    /* Stats Grid */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 2rem;
        margin-top: 4rem;
        position: relative;
        z-index: 1;
    }

    .stat-item {
        text-align: center;
        padding: 2rem;
        background: white;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border-light);
        transition: var(--transition);
    }

    .stat-item:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-md);
    }

    .stat-item h3 {
        font-size: 2.5rem;
        font-weight: 800;
        color: var(--primary);
        margin-bottom: 0.5rem;
    }

    /* Responsive Design */
    @media (max-width: 1200px) {
        .container {
            padding: 0 32px;
        }
    }

    @media (max-width: 992px) {
        .admin-card {
            flex-direction: column;
            text-align: center;
            gap: 2rem;
        }

        .admin-avatar {
            margin: 0 auto;
        }

        .hero-section {
            padding: 100px 0 60px;
        }
    }

    @media (max-width: 768px) {
        .hero-section {
            padding: 80px 0 40px;
        }

        .btn {
            padding: 14px 28px;
            font-size: 1rem;
        }

        .feature-grid {
            grid-template-columns: 1fr;
        }

        .stat-card, .feature-card {
            padding: 2rem;
        }

        .admin-title {
            font-size: 1.75rem;
        }
    }

    @media (max-width: 480px) {
        .container {
            padding: 0 20px;
        }

        .hero-title {
            font-size: 2.25rem;
        }

        .btn {
            width: 100%;
            justify-content: center;
        }

        .btn-group {
            flex-direction: column;
            gap: 1rem;
        }
    }

    /* Animations */
    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .floating {
        animation: float 3s ease-in-out infinite;
    }

    .fade-in-up {
        animation: fadeInUp 0.6s ease-out forwards;
    }

    .stagger-delay-1 { animation-delay: 0.1s; }
    .stagger-delay-2 { animation-delay: 0.2s; }
    .stagger-delay-3 { animation-delay: 0.3s; }
    .stagger-delay-4 { animation-delay: 0.4s; }

    /* Glass Effect */
    .glass-effect {
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    /* Badge Colors */
    .badge-primary {
        background: var(--primary-lighter);
        color: var(--primary);
    }

    .badge-success {
        background: #d1fae5;
        color: #065f46;
    }

    .badge-warning {
        background: #fef3c7;
        color: #92400e;
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar {
        width: 10px;
    }

    ::-webkit-scrollbar-track {
        background: var(--bg-secondary);
    }

    ::-webkit-scrollbar-thumb {
        background: var(--primary-light);
        border-radius: 5px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--primary);
    }
</style>

<section class="hero-section">
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title fade-in-up">Transform Your Future with <span style="display: block;">SAM College</span></h1>
            <p class="hero-subtitle fade-in-up stagger-delay-1">Join 10,000+ professionals accelerating careers with AI-powered, immersive online courses and expert guidance.</p>

            <?php if (!isset($_SESSION['user_id'])): ?>
                <div class="btn-group d-flex flex-wrap justify-content-center gap-3 fade-in-up stagger-delay-2">
                    <a href="register.php" class="btn btn-primary">
                        <i class="fas fa-rocket"></i> Start Free Trial
                    </a>
                    <a href="login.php" class="btn btn-secondary">
                        <i class="fas fa-sign-in-alt"></i> Login to Dashboard
                    </a>
                    <a href="#features" class="btn btn-ghost">
                        <i class="fas fa-play-circle"></i> Watch Introduction
                    </a>
                </div>
            <?php else: ?>
                <div class="welcome-card fade-in-up">
                    <div class="d-flex align-items-center gap-4">
                        <div class="user-avatar">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h4 class="mb-2" style="color: var(--text-primary);">
                                Welcome back, <strong style="color: var(--primary);"><?php echo htmlspecialchars($_SESSION['name'] ?? 'Learner'); ?></strong>
                            </h4>
                            <p class="mb-3" style="color: var(--text-secondary);">
                                <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin'): ?>
                                    <i class="fas fa-shield-alt text-primary me-2"></i>
                                    Administrator access: Manage platform with advanced AI insights and analytics.
                                <?php else: ?>
                                    <i class="fas fa-graduation-cap text-primary me-2"></i>
                                    Explore 15+ new AI-enhanced courses this month. Your learning journey awaits!
                                <?php endif; ?>
                            </p>
                            <div class="d-flex flex-wrap gap-3">
                                <a href="<?php echo (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') ? 'admin/dashboard.php' : 'student/dashboard.php'; ?>" 
                                   class="btn btn-primary">
                                    <i class="fas fa-arrow-right"></i> Go to Dashboard
                                </a>
                                <a href="courses.php" class="btn btn-secondary">
                                    <i class="fas fa-book-open"></i> Browse Courses
                                </a>
                                <a href="logout.php" class="btn btn-ghost">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="stats-section">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-3 col-md-6 fade-in-up">
                <div class="stat-card">
                    <div class="stat-number">150+</div>
                    <p class="text-secondary mb-0">AI-Enhanced Courses</p>
                    <small class="text-muted">Updated weekly</small>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 fade-in-up stagger-delay-1">
                <div class="stat-card">
                    <div class="stat-number">98.7%</div>
                    <p class="text-secondary mb-0">Completion Rate</p>
                    <small class="text-muted">Industry leading</small>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 fade-in-up stagger-delay-2">
                <div class="stat-card">
                    <div class="stat-number">24/7</div>
                    <p class="text-secondary mb-0">AI Tutor Support</p>
                    <small class="text-muted">Always available</small>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 fade-in-up stagger-delay-3">
                <div class="stat-card">
                    <div class="stat-number">50+</div>
                    <p class="text-secondary mb-0">Expert Mentors</p>
                    <small class="text-muted">Industry leaders</small>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="features" class="features-section">
    <div class="container">
        <h2 class="section-title">Why SAM College Leads in 2025</h2>
        <p class="section-subtitle">Cutting-edge AI personalization, immersive experiences, and adaptive learning for modern professionals.</p>
        
        <div class="feature-grid">
            <div class="feature-card fade-in-up">
                <div class="feature-icon">
                    <i class="fas fa-play-circle"></i>
                </div>
                <h3 class="feature-title">Immersive 4K Videos</h3>
                <p class="text-secondary">Interactive, high-resolution lessons with AR elements for engaging, modern learning experiences.</p>
            </div>
            
            <div class="feature-card fade-in-up stagger-delay-1">
                <div class="feature-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <h3 class="feature-title">AI Adaptive Learning</h3>
                <p class="text-secondary">Personalized paths using generative AI for optimal skill development and knowledge retention.</p>
            </div>
            
            <div class="feature-card fade-in-up stagger-delay-2">
                <div class="feature-icon">
                    <i class="fas fa-certificate"></i>
                </div>
                <h3 class="feature-title">Blockchain Certifications</h3>
                <p class="text-secondary">Verifiable, shareable credentials recognized by top employers worldwide.</p>
            </div>
            
            <div class="feature-card fade-in-up stagger-delay-3">
                <div class="feature-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3 class="feature-title">Collaborative Sessions</h3>
                <p class="text-secondary">Live AI-moderated mentorship and global peer networking opportunities.</p>
            </div>
            
            <div class="feature-card fade-in-up">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h3 class="feature-title">Multi-Device Learning</h3>
                <p class="text-secondary">Seamless offline access with real-time sync across all your devices.</p>
            </div>
            
            <div class="feature-card fade-in-up stagger-delay-1">
                <div class="feature-icon">
                    <i class="fas fa-briefcase"></i>
                </div>
                <h3 class="feature-title">AI Career Matching</h3>
                <p class="text-secondary">Personalized job recommendations and realistic interview simulations.</p>
            </div>
        </div>
    </div>
</section>

<section class="admin-section">
    <div class="container">
        <h2 class="section-title">Advanced Platform Management</h2>
        <p class="section-subtitle" style="color: var(--text-secondary);">AI-driven operations ensuring security, performance, and innovation for 10,000+ users worldwide.</p>
        
        <div class="admin-card fade-in-up">
            <img src="assets/img/admin.jpg" alt="System Administrator" class="admin-avatar" 
                 onerror="this.src='https://images.unsplash.com/photo-1557862921-37829c790f19?w=400&h=400&fit=crop&crop=face';">
            <div class="flex-grow-1">
                <h3 class="admin-title">Enterprise-Grade Infrastructure</h3>
                <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">
                    Powered by AI monitoring, 99.9% uptime guarantee, and proactive security measures.
                </p>
                <div class="admin-badges">
                    <span class="admin-badge badge-primary">
                        <i class="fas fa-shield-alt"></i> AI Security
                    </span>
                    <span class="admin-badge badge-success">
                        <i class="fas fa-server"></i> Cloud Maintenance
                    </span>
                    <span class="admin-badge badge-warning">
                        <i class="fas fa-headset"></i> 24/7 Support
                    </span>
                    <span class="admin-badge badge-primary">
                        <i class="fas fa-chart-line"></i> Predictive Analytics
                    </span>
                </div>
            </div>
        </div>
        
        <div class="stats-grid fade-in-up stagger-delay-1">
            <div class="stat-item">
                <h3>99.9%</h3>
                <p style="color: var(--text-secondary); font-weight: 500;">Platform Uptime</p>
            </div>
            <div class="stat-item">
                <h3>&lt;30min</h3>
                <p style="color: var(--text-secondary); font-weight: 500;">Average Response Time</p>
            </div>
            <div class="stat-item">
                <h3>Quantum</h3>
                <p style="color: var(--text-secondary); font-weight: 500;">Ready Encryption</p>
            </div>
            <div class="stat-item">
                <h3>ISO 27001+</h3>
                <p style="color: var(--text-secondary); font-weight: 500;">Security Certified</p>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Button hover effect
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('mousemove', e => {
                const rect = btn.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                btn.style.setProperty('--x', `${x}px`);
                btn.style.setProperty('--y', `${y}px`);
            });
        });

        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in-up');
                    
                    // Add floating animation to stat cards after they appear
                    if (entry.target.classList.contains('stat-card')) {
                        setTimeout(() => {
                            entry.target.classList.add('floating');
                        }, 300);
                    }
                }
            });
        }, observerOptions);

        // Observe elements
        document.querySelectorAll('.stat-card, .feature-card, .admin-card, .stat-item').forEach(el => {
            observer.observe(el);
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Add subtle parallax effect to hero background
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const hero = document.querySelector('.hero-section');
            if (hero) {
                hero.style.backgroundPosition = `center ${scrolled * 0.5}px`;
            }
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>