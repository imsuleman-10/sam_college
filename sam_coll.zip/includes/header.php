<?php
// Session initialization
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set user variables
$is_logged_in = isset($_SESSION['user_id']);
$user_name = $is_logged_in ? htmlspecialchars($_SESSION['name']) : '';
$user_type = $is_logged_in ? ($_SESSION['user_type'] ?? 'student') : '';

// Path Resolution Logic
$current_script = basename($_SERVER['SCRIPT_FILENAME']);
$root_files = ['index.php', 'login.php', 'register.php', 'logout.php', '404.php', 'about.php', 'contact.php'];
$root_prefix = in_array($current_script, $root_files) ? '' : '../';

// Set navigation paths
if ($is_logged_in) {
    $dashboard_path = ($user_type == 'admin') 
        ? $root_prefix . 'admin/dashboard.php' 
        : $root_prefix . 'student/dashboard.php';
    $my_progress_path = $root_prefix . 'student/my_progress.php';
}

// Dynamic landing page
$dynamic_landing_page = $is_logged_in 
    ? $dashboard_path 
    : $root_prefix . 'index.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | SAM College' : 'SAM College | E-Learning Platform'; ?></title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* ============================================
           COLOR SCHEME 1: BLUE PROFESSIONAL (DEFAULT)
           ============================================ */
        :root {
            --primary-color: #2563eb;      /* Royal Blue */
            --primary-dark: #1d4ed8;       /* Darker Blue */
            --primary-light: #3b82f6;      /* Light Blue */
            --secondary-color: #06b6d4;    /* Cyan */
            --accent-color: #8b5cf6;       /* Violet */
            --success-color: #10b981;      /* Emerald */
            --danger-color: #ef4444;       /* Red */
            --warning-color: #f59e0b;      /* Amber */
            --dark-color: #1e293b;         /* Slate */
            --light-color: #f8fafc;        /* Light Slate */
            --gray-color: #64748b;         /* Slate Gray */
            --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --hover-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        /* ============================================
           ALTERNATIVE COLOR SCHEMES (UNCOMMENT TO USE)
           ============================================ */
        
        /* 
        SCHEME 2: DARK THEME
        :root {
            --primary-color: #6366f1;      /* Indigo */
            --primary-dark: #4f46e5;       /* Darker Indigo */
            --primary-light: #818cf8;      /* Light Indigo */
            --secondary-color: #ec4899;    /* Pink */
            --accent-color: #f59e0b;       /* Amber */
            --success-color: #10b981;      /* Emerald */
            --danger-color: #ef4444;       /* Red */
            --warning-color: #f59e0b;      /* Amber */
            --dark-color: #0f172a;         /* Slate 900 */
            --light-color: #f1f5f9;        /* Slate 100 */
            --gray-color: #94a3b8;         /* Slate 400 */
        }
        */
        
        /* 
        SCHEME 3: GREEN NATURE
        :root {
            --primary-color: #059669;      /* Emerald */
            --primary-dark: #047857;       /* Darker Emerald */
            --primary-light: #10b981;      /* Light Emerald */
            --secondary-color: #0ea5e9;    /* Sky Blue */
            --accent-color: #f59e0b;       /* Amber */
            --success-color: #10b981;      /* Emerald */
            --danger-color: #ef4444;       /* Red */
            --warning-color: #f59e0b;      /* Amber */
            --dark-color: #1e293b;         /* Slate */
            --light-color: #f0fdf4;        /* Green 50 */
            --gray-color: #64748b;         /* Slate Gray */
        }
        */
        
        /* 
        SCHEME 4: PURPLE CREATIVE
        :root {
            --primary-color: #7c3aed;      /* Violet */
            --primary-dark: #6d28d9;       /* Darker Violet */
            --primary-light: #8b5cf6;      /* Light Violet */
            --secondary-color: #ec4899;    /* Pink */
            --accent-color: #06b6d4;       /* Cyan */
            --success-color: #10b981;      /* Emerald */
            --danger-color: #ef4444;       /* Red */
            --warning-color: #f59e0b;      /* Amber */
            --dark-color: #1e293b;         /* Slate */
            --light-color: #faf5ff;        /* Purple 50 */
            --gray-color: #64748b;         /* Slate Gray */
        }
        */
        
        /* 
        SCHEME 5: CORPORATE BLUE
        :root {
            --primary-color: #1e40af;      /* Navy Blue */
            --primary-dark: #1e3a8a;       /* Dark Navy */
            --primary-light: #3b82f6;      /* Blue */
            --secondary-color: #0ea5e9;    /* Sky Blue */
            --accent-color: #6366f1;       /* Indigo */
            --success-color: #059669;      /* Emerald */
            --danger-color: #dc2626;       /* Red */
            --warning-color: #d97706;      /* Amber */
            --dark-color: #111827;         /* Gray 900 */
            --light-color: #f9fafb;        /* Gray 50 */
            --gray-color: #6b7280;         /* Gray 500 */
        }
        */
        
        /* ============================================
           COMMON STYLES (ALL SCHEMES USE THESE)
           ============================================ */
        * {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        body {
            background-color: var(--light-color);
        }
        
        /* Navbar Styling */
        .navbar {
            background: white;
            box-shadow: var(--card-shadow);
            padding: 0.8rem 0;
            border-bottom: 2px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .navbar.scrolled {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
        }
        
        /* Brand Logo */
        .navbar-brand {
            font-weight: 700;
            font-size: 1.6rem;
            color: var(--primary-color) !important;
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
        }
        
        .navbar-brand::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
        }
        
        .navbar-brand i {
            color: var(--secondary-color);
            font-size: 1.8rem;
            transition: transform 0.3s ease;
        }
        
        .navbar-brand:hover i {
            transform: rotate(-15deg);
        }
        
        /* Navigation Links */
        .nav-link {
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 6px;
            margin: 0 0.2rem;
            transition: all 0.3s ease;
            color: var(--dark-color) !important;
        }
        
        .nav-link:hover {
            background: rgba(37, 99, 235, 0.1);
            color: var(--primary-color) !important;
            transform: translateY(-2px);
        }
        
        /* Buttons */
        .btn-nav {
            padding: 0.5rem 1.5rem !important;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease !important;
            border: 2px solid transparent;
        }
        
        .btn-primary-nav {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white !important;
            border: none;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }
        
        .btn-primary-nav:hover {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.4);
        }
        
        .btn-secondary-nav {
            background: linear-gradient(135deg, var(--secondary-color), #0891b2);
            color: white !important;
            border: none;
            box-shadow: 0 4px 12px rgba(6, 182, 212, 0.3);
        }
        
        .btn-secondary-nav:hover {
            background: linear-gradient(135deg, #0891b2, var(--secondary-color));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(6, 182, 212, 0.4);
        }
        
        .btn-danger-nav {
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
            color: white !important;
            border: none;
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger-nav:hover {
            background: linear-gradient(135deg, #dc2626, var(--danger-color));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
        }
        
        .btn-success-nav {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white !important;
            border: none;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success-nav:hover {
            background: linear-gradient(135deg, #059669, var(--success-color));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }
        
        /* User Greeting */
        .user-greeting {
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.1), rgba(6, 182, 212, 0.1));
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            font-size: 0.9rem;
            color: var(--dark-color);
            border: 2px solid rgba(37, 99, 235, 0.2);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-greeting i {
            color: var(--primary-color);
        }
        
        .user-greeting strong {
            color: var(--primary-color);
            font-weight: 700;
        }
        
        /* Icon Container */
        .nav-icon-container {
            width: 36px;
            height: 36px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 10px;
            margin-right: 10px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover .nav-icon-container {
            background: var(--primary-color);
        }
        
        .nav-link:hover .nav-icon-container i {
            color: white !important;
        }
        
        /* Badge for notifications (optional) */
        .nav-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger-color);
            color: white;
            font-size: 0.6rem;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: bold;
        }
        
        /* Mobile Responsiveness */
        @media (max-width: 991.98px) {
            .navbar-collapse {
                background: white;
                padding: 1.5rem;
                border-radius: 12px;
                box-shadow: var(--hover-shadow);
                margin-top: 1rem;
                border: 1px solid rgba(0, 0, 0, 0.1);
            }
            
            .nav-item {
                margin-bottom: 0.8rem;
            }
            
            .user-greeting {
                width: 100%;
                justify-content: center;
                margin-bottom: 1rem;
            }
            
            .btn-nav {
                width: 100%;
                justify-content: center;
            }
        }
        
        /* Animation */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .navbar-collapse.show {
            animation: fadeInDown 0.3s ease;
        }
        
        /* Toggle Button */
        .navbar-toggler {
            border: 2px solid var(--primary-color);
            padding: 0.25rem 0.5rem;
        }
        
        .navbar-toggler:focus {
            box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.25);
        }
        
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(37, 99, 235, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <!-- Brand Logo -->
        <a class="navbar-brand" href="<?php echo $dynamic_landing_page; ?>">
            <i class="fas fa-graduation-cap"></i>
            <span>SAM College</span>
        </a>

        <!-- Mobile Toggle Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" 
                aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation Menu -->
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <?php if ($is_logged_in): ?>
                    
                    <!-- User Greeting -->
                    <li class="nav-item me-lg-3 mb-2 mb-lg-0 position-relative">
                        <div class="user-greeting">
                            <i class="fas fa-user-circle"></i>
                            <span>Welcome, <strong><?php echo $user_name; ?></strong></span>
                        </div>
                    </li>

                    <!-- Dashboard Button -->
                    <li class="nav-item mb-2 mb-lg-0">
                        <a class="nav-link btn btn-primary-nav btn-nav" 
                           href="<?php echo $dashboard_path; ?>">
                            <span class="nav-icon-container">
                                <i class="fas fa-tachometer-alt"></i>
                            </span>
                            <?php echo ($user_type == 'admin') ? 'Admin Panel' : 'Dashboard'; ?>
                        </a>
                    </li>
                    
                    <!-- My Progress (Student Only) -->
                    <?php if ($user_type == 'student'): ?>
                    <li class="nav-item mb-2 mb-lg-0">
                        <a class="nav-link" 
                           href="<?php echo $my_progress_path; ?>">
                            <span class="nav-icon-container">
                                <i class="fas fa-chart-line"></i>
                            </span>
                            My Progress
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- Logout Button -->
                    <li class="nav-item mb-2 mb-lg-0 ms-lg-2">
                        <a class="nav-link btn btn-danger-nav btn-nav" 
                           href="<?php echo $root_prefix; ?>logout.php">
                            <span class="nav-icon-container">
                                <i class="fas fa-sign-out-alt"></i>
                            </span>
                            Logout
                        </a>
                    </li>

                <?php else: ?>
                    
                    <!-- Login Link -->
                    <li class="nav-item mb-2 mb-lg-0">
                        <a class="nav-link" href="<?php echo $root_prefix; ?>login.php">
                            <span class="nav-icon-container">
                                <i class="fas fa-sign-in-alt"></i>
                            </span>
                            Login
                        </a>
                    </li>
                    
                    <!-- Register Button -->
                    <li class="nav-item mb-2 mb-lg-0 ms-lg-2">
                        <a class="nav-link btn btn-success-nav btn-nav" 
                           href="<?php echo $root_prefix; ?>register.php">
                            <span class="nav-icon-container">
                                <i class="fas fa-user-plus"></i>
                            </span>
                            Register Now
                        </a>
                    </li>
                
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<script>
    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 20) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Smooth hover effects
    document.addEventListener('DOMContentLoaded', function() {
        // Add hover effect to all nav items
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
        
        // Mobile menu close on click
        const navLinks = document.querySelectorAll('.nav-link');
        const navbarCollapse = document.querySelector('.navbar-collapse');
        
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth < 992) {
                    const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                        toggle: false
                    });
                    bsCollapse.hide();
                }
            });
        });
    });
</script>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>