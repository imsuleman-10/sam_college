<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in AND is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    // If not admin or not logged in, redirect to the main login page
    header('Location: ../login.php');
    exit;
}

// Database connection (assuming db.php is one level up)
require_once '../config/db.php'; 

// Set a default page title if not set by the page
$admin_page_title = isset($admin_page_title) ? $admin_page_title : 'Admin Dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $admin_page_title; ?> - Admin Panel</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        #sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40; /* Dark sidebar */
            color: white;
            padding-top: 20px;
            transition: all 0.3s;
        }
        #content {
            margin-left: 250px; /* Space for sidebar */
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
        }
        .nav-link.active {
            background-color: #0d6efd; /* Primary color for active link */
            color: white !important;
            border-radius: 5px;
        }
        .nav-link:hover {
            background-color: #495057;
        }
        .sidebar-brand {
            padding: 0 1rem;
            text-align: center;
            font-size: 1.5rem;
            margin-bottom: 2rem;
            font-weight: bold;
            color: #ffffff;
        }
    </style>
</head>
<body>

<div id="sidebar">
    <div class="sidebar-brand">
        <i class="fas fa-cogs"></i> Admin Portal
    </div>
    <ul class="nav flex-column px-3">
        <li class="nav-item mb-2">
            <a class="nav-link text-white <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php">
                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item mb-2">
            <a class="nav-link text-white <?php echo (basename($_SERVER['PHP_SELF']) == 'manage_users.php') ? 'active' : ''; ?>" href="manage_users.php">
                <i class="fas fa-users-cog me-2"></i> Manage Users
            </a>
        </li>
        </ul>
    
    <div class="position-absolute bottom-0 w-100 p-3">
        <a href="../logout.php" class="btn btn-outline-light w-100">
            <i class="fas fa-sign-out-alt me-2"></i> Logout
        </a>
    </div>
</div>

<div id="content">
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $admin_page_title; ?></h1>
        <div class="small text-muted">Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</div>
    </div>
    ```

### 2. Dashboard: `admin/dashboard.php`

Yeh basic dashboard page hai jahan admin login karta hai.

```php
<?php
$admin_page_title = 'System Overview';
require_once '../includes/admin_header.php'; // Includes the security check and HTML structure

// You can add logic here to fetch summary stats (e.g., total users, new registrations)
// Example: Fetch total number of students
$total_students = 0;
$sql = "SELECT COUNT(*) FROM users WHERE user_type = 'student'";
if ($result = $conn->query($sql)) {
    $row = $result->fetch_row();
    $total_students = $row[0];
    $result->close();
}

$conn->close(); // Close connection after fetching dashboard data
?>

<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Students
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_students; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-graduate fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Active Courses
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">12</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Pending Enrollments
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">4</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Quick Actions</h6>
    </div>
    <div class="card-body">
        <a href="manage_users.php" class="btn btn-primary btn-icon-split me-3">
            <span class="icon text-white-50"><i class="fas fa-users"></i></span>
            <span class="text">Manage Students</span>
        </a>
        <button class="btn btn-success btn-icon-split me-3">
            <span class="icon text-white-50"><i class="fas fa-plus"></i></span>
            <span class="text">Add New Course</span>
        </button>
    </div>
</div>

<?php require_once '../includes/admin_footer.php'; // Closing tags and JS ?>