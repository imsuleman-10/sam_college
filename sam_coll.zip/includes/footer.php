</main>
<footer class="bg-light text-center text-lg-start mt-auto">
  <div class="container p-4">
    <div class="text-center">
      © <?php echo date("Y"); ?> SAM College E-Learning Portal. All rights reserved.
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $is_admin ? '../js/scripts.js' : (isset($page_title) && $page_title == 'E-learning Portal' ? 'js/scripts.js' : '../js/scripts.js'); ?>"></script>

</body>
</html>