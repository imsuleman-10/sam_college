<?php
// ... aapke koi doosre functions yahan ho sakte hain ...

/**
 * System mein koi bhi ahem action ko record (log) karne ka function.
 * Ise $pdo (database connection) aur session_start() ke baad call karna hai.
 */
function log_action($pdo, $action, $details = null) {
    // Session se user ki tafseelat (details) hasil karna
    // Agar user log-in hai to uski ID aur type lein, warna 'system' type dein.
    $user_id = $_SESSION['user_id'] ?? null;
    $user_type = $_SESSION['user_type'] ?? 'system'; 
    
    // IP address hasil karna
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'N/A';

    // Details (jaise student ID, course name) ko JSON format mein save karna
    $details_json = is_array($details) ? json_encode($details, JSON_UNESCAPED_UNICODE) : $details;

    try {
        $query = "INSERT INTO system_logs (user_id, user_type, action, details, ip_address) 
                  VALUES (:user_id, :user_type, :action, :details, :ip_address)";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            ':user_id' => $user_id,
            ':user_type' => $user_type,
            ':action' => $action,
            ':details' => $details_json,
            ':ip_address' => $ip_address
        ]);

    } catch (PDOException $e) {
        // Agar logging mein masla ho to use system error log mein daal dein
        error_log("LOGGING ERROR: " . $e->getMessage());
        // Zaroori nahi ke user ko is error ka pata chale, isliye sirf log kar rahe hain
    }
}

// ... doosre functions ...

?>