<?php

// NEW FUNCTION REQUIRED BY quiz_results.php
function isLoggedIn() {
    // A user is logged in if their ID is set, or if they are identified as a student or admin.
    // We can use the existing student check for simplicity since this file is in the 'student' folder.
    return isStudentLoggedIn() || isAdminLoggedIn();
}


function isAdminLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
}

function isStudentLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'student';
}

?>