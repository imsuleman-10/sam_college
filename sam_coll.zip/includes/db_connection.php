<?php
// Database connection details
$host = 'localhost';
$db   = 'e_learning_db'; // Ensure this matches your actual database name
$user = 'root';         // Your MySQL username
$pass = '';             // Your MySQL password (usually empty in XAMPP)

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Essential for debugging
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     // If connection fails, die with an error
     die("Database connection error: Check db_connection.php. Error: " . $e->getMessage()); 
}
?>