<?php
// Yeh script sirf ek baar hash generate karne ke liye istemal hoga.
// Iske baad aap is file ko delete kar sakte hain.

// **STEP 1:** Apna naya password yahan likhiye.
$new_plain_password = '1234'; 

// **STEP 2:** PHP ka secure hashing function istemal karein.
$hashed_password = password_hash($new_plain_password, PASSWORD_DEFAULT);

// Output: Hashed password
echo "Aapka plain password: " . $new_plain_password . "<br>";
echo "Aapka naya hashed password hai (Ise copy karein): <span style='font-weight: bold; color: blue;'>" . $hashed_password . "</span><br><br>";
echo "Ab aap is file (generate_hash.php) ko delete kar dein.";
?>