<?php
// Start session for potential redirects
session_start();

// Check if user is already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['user_type'] == 'admin' ? 'admin/dashboard.php' : 'student/dashboard.php'));
    exit;
}

require_once 'config/db.php';

$name = $email = $password = $confirm_password = '';
$name_err = $email_err = $password_err = '';
$success_msg = '';

// Processing form data when form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Validate Name
    if (empty(trim($_POST['name']))) {
        $name_err = 'Please enter your name.';
    } else {
        $name = trim($_POST['name']);
    }

    // Validate Email
    if (empty(trim($_POST['email']))) {
        $email_err = 'Please enter an email.';
    } else {
        $email = trim($_POST['email']);
        // Check if email is already taken
        $sql = "SELECT user_id FROM users WHERE email = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $param_email);
            $param_email = $email;
            if ($stmt->execute()) {
                $stmt->store_result();
                if ($stmt->num_rows >= 1) {
                    $email_err = 'This email is already registered.';
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            $stmt->close();
        }
    }

    // Validate Password
    if (empty(trim($_POST['password']))) {
        $password_err = 'Please enter a password.';
    } elseif (strlen(trim($_POST['password'])) < 6) {
        $password_err = 'Password must have at least 6 characters.';
    } else {
        $password = trim($_POST['password']);
    }
    
    // Validate Confirm Password
    if (empty(trim($_POST['confirm_password'])) || (trim($_POST['password']) !== trim($_POST['confirm_password']))) {
        $password_err = 'Passwords do not match.';
    }

    // Check input errors before inserting into database
    if (empty($name_err) && empty($email_err) && empty($password_err)) {
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (name, email, password, user_type) VALUES (?, ?, ?, 'student')";
        
        if ($stmt = $conn->prepare($sql)) {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // Bind parameters
            $stmt->bind_param("sss", $param_name, $param_email, $param_password);
            
            // Set parameters
            $param_name = $name;
            $param_email = $email;
            $param_password = $hashed_password;
            
            // Execute the statement
            if ($stmt->execute()) {
                $success_msg = 'Registration successful! You can now log in.';
                // Clear inputs after success
                $name = $email = $password = $confirm_password = '';
            } else {
                echo "Something went wrong. Please try again.";
            }

            $stmt->close();
        }
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SAM College E-learning Portal</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
:root{
  --p:#4f46e5;
  --s:#6366f1;
  --a:#22d3ee;
  --bg:#f5f7ff;
  --glass:rgba(255,255,255,.78);
  --border:rgba(255,255,255,.4);
  --text:#111827;
  --muted:#6b7280;
  --danger:#ef4444;
  --shadow:0 30px 80px rgba(0,0,0,.12);
}

body{
  background:linear-gradient(135deg,#eef2ff,#f8fafc);
  min-height:100vh;
  font-family:Inter,system-ui,sans-serif;
  color:var(--text);
}

/* background */
.background-animation{position:fixed;inset:0;z-index:-1}
.gradient-circle{
  position:absolute;width:420px;height:420px;
  filter:blur(120px);opacity:.45
}
.circle-1{background:#6366f1;top:-120px;left:-120px}
.circle-2{background:#22d3ee;bottom:-120px;right:-120px}
.circle-3{background:#4f46e5;top:40%;left:50%}

/* card */
.register-wrapper{
  min-height:100vh;display:flex;
  align-items:center;justify-content:center;
  padding:2rem
}
.register-card{
  max-width:520px;width:100%;
  background:var(--glass);
  backdrop-filter:blur(18px);
  border-radius:28px;
  box-shadow:var(--shadow);
  padding:3rem;
  border:1px solid var(--border);
  transition:.4s
}
.register-card:hover{transform:translateY(-6px)}

/* header */
.logo-icon{
  width:90px;height:90px;border-radius:50%;
  margin:auto;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg,var(--p),var(--s));
  color:#fff;font-size:2rem;
  box-shadow:0 12px 30px rgba(79,70,229,.4)
}
.brand-name{text-align:center;font-weight:800;margin-top:1rem}
.brand-subtitle{text-align:center;color:var(--muted)}

/* steps */
.progress-steps{display:flex;justify-content:space-between;margin:2rem 0}
.step{text-align:center;flex:1}
.step-circle{
  width:38px;height:38px;border-radius:50%;
  background:#e5e7eb;margin:auto;
  display:flex;align-items:center;justify-content:center
}
.step.active .step-circle{
  background:linear-gradient(135deg,var(--p),var(--s));
  color:#fff
}

/* inputs */
.form-group{margin-bottom:1.4rem}
.input-label{font-weight:600;margin-bottom:.4rem}
.input-wrapper{
  display:flex;align-items:center;
  background:#fff;border-radius:14px;
  padding:.75rem 1rem;
  border:2px solid #e5e7eb;
  transition:.3s
}
.input-wrapper i{color:var(--muted)}
.input-wrapper input{
  border:none;outline:none;width:100%;
  padding-left:.6rem
}
.input-wrapper:focus-within{
  border-color:var(--p);
  box-shadow:0 0 0 4px rgba(79,70,229,.15)
}
.input-wrapper.error{border-color:var(--danger)}

.error-message{color:var(--danger);font-size:.85rem;margin-top:.3rem}

/* buttons */
.register-btn,.login-btn{
  width:100%;border:none;
  padding:1rem;border-radius:14px;
  font-weight:700;color:#fff;
  background:linear-gradient(135deg,var(--p),var(--s));
  transition:.3s
}
.register-btn:hover,.login-btn:hover{
  transform:translateY(-2px);
  box-shadow:0 12px 30px rgba(79,70,229,.35)
}

.login-link{text-align:center;margin-top:1.5rem}
.login-link a{text-decoration:none;font-weight:600}

.success-alert{
  background:#fff;border-radius:16px;
  padding:1.5rem;margin-bottom:1.5rem;
  box-shadow:var(--shadow)
}

.security-footer{
  text-align:center;margin-top:2rem;
  font-size:.85rem;color:var(--muted)
}

@media(max-width:576px){
  .register-card{padding:2rem}
}
</style>

</head>
<body>
    <!-- Animated Background -->
    <div class="background-animation">
        <div class="gradient-circle circle-1"></div>
        <div class="gradient-circle circle-2"></div>
        <div class="gradient-circle circle-3"></div>
    </div>
    
    <!-- Floating Particles -->
    <div class="floating-particles" id="particles"></div>
    
    <div class="register-wrapper">
        <div class="register-card animate__animated animate__fadeIn">
            <div class="logo-container">
                <div class="logo-icon">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h1 class="brand-name">Create Account</h1>
                <p class="brand-subtitle">Join SAM College Learning Community</p>
            </div>
            
            <!-- Progress Steps -->
            <div class="progress-steps">
                <div class="step active">
                    <div class="step-circle">1</div>
                    <span class="step-label">Account</span>
                </div>
                <div class="step">
                    <div class="step-circle">2</div>
                    <span class="step-label">Profile</span>
                </div>
                <div class="step">
                    <div class="step-circle">3</div>
                    <span class="step-label">Complete</span>
                </div>
            </div>

            <?php if (!empty($success_msg)): ?>
                <div class="success-alert" role="alert">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle success-icon"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5 class="mb-2" style="color: var(--primary-color);">Registration Successful!</h5>
                            <p class="mb-0"><?php echo htmlspecialchars($success_msg); ?></p>
                            <div class="mt-3">
                                <a href="login.php" class="login-btn">
                                    <i class="fas fa-sign-in-alt"></i> Proceed to Login
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <form id="registrationForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label class="input-label">
                        <i class="fas fa-user"></i> Full Name
                    </label>
                    <div class="input-wrapper <?php echo (!empty($name_err)) ? 'error' : ''; ?>">
                        <i class="fas fa-id-card"></i>
                        <input type="text" 
                               name="name" 
                               id="name" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($name); ?>"
                               required 
                               placeholder="Enter your full name"
                               autocomplete="name">
                    </div>
                    <?php if (!empty($name_err)): ?>
                        <div class="error-message">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $name_err; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="input-label">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <div class="input-wrapper <?php echo (!empty($email_err)) ? 'error' : ''; ?>">
                        <i class="fas fa-at"></i>
                        <input type="email" 
                               name="email" 
                               id="email" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($email); ?>"
                               required 
                               placeholder="your.email@example.com"
                               autocomplete="email">
                    </div>
                    <?php if (!empty($email_err)): ?>
                        <div class="error-message">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $email_err; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="input-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-key"></i>
                        <input type="password" 
                               name="password" 
                               id="password" 
                               class="form-control" 
                               required 
                               placeholder="Minimum 6 characters"
                               autocomplete="new-password">
                        <button type="button" class="password-toggle" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-strength">
                        <div class="strength-meter">
                            <div class="strength-fill" id="strengthFill"></div>
                        </div>
                        <div class="strength-text" id="strengthText">Password strength</div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="input-label">
                        <i class="fas fa-lock"></i> Confirm Password
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-key"></i>
                        <input type="password" 
                               name="confirm_password" 
                               id="confirm_password" 
                               class="form-control" 
                               required 
                               placeholder="Re-enter your password"
                               autocomplete="new-password">
                        <button type="button" class="password-toggle" id="toggleConfirmPassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="error-message" id="passwordMatchError" style="display: none;">
                        <i class="fas fa-exclamation-circle"></i> Passwords do not match
                    </div>
                </div>
                
                <div class="terms-check">
                    <label>
                        <input type="checkbox" id="termsCheck" required>
                        <span>
                            I agree to the <a href="#">Terms & Conditions</a> and <a href="#">Privacy Policy</a>
                        </span>
                    </label>
                    <div class="error-message" id="termsError" style="display: none;">
                        <i class="fas fa-exclamation-circle"></i> Please accept the terms and conditions
                    </div>
                </div>
                
                <button type="submit" class="register-btn">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>
            
            <div class="login-link">
                <p>Already have an account?</p>
                <a href="login.php" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i> Sign In
                </a>
            </div>
            
            <div class="security-footer">
                <i class="fas fa-shield-alt"></i>
                <span>Your data is secured with 256-bit encryption</span>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Generate floating particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 50;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random size
                const size = Math.random() * 4 + 2;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                
                // Random position
                particle.style.left = `${Math.random() * 100}%`;
                
                // Random animation
                particle.style.animationDelay = `${Math.random() * 15}s`;
                particle.style.animationDuration = `${Math.random() * 10 + 10}s`;
                
                // Random color
                const colors = ['#06d6a0', '#118ab2', '#ffd166', '#ef476f'];
                particle.style.background = colors[Math.floor(Math.random() * colors.length)];
                
                particlesContainer.appendChild(particle);
            }
        }
        
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
            const confirmPasswordInput = document.getElementById('confirm_password');
            const icon = this.querySelector('i');
            
            if (confirmPasswordInput.type === 'password') {
                confirmPasswordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                confirmPasswordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        // Password strength checker
        const passwordInput = document.getElementById('password');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        
        function checkPasswordStrength(password) {
            let strength = 0;
            
            // Length check
            if (password.length >= 6) strength += 20;
            if (password.length >= 8) strength += 20;
            
            // Character variety checks
            if (/[a-z]/.test(password)) strength += 20;
            if (/[A-Z]/.test(password)) strength += 20;
            if (/[0-9]/.test(password)) strength += 10;
            if (/[^A-Za-z0-9]/.test(password)) strength += 10;
            
            // Update UI
            strengthFill.style.width = `${strength}%`;
            
            if (strength < 40) {
                strengthFill.style.background = '#ef476f';
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#ef476f';
            } else if (strength < 70) {
                strengthFill.style.background = '#ffd166';
                strengthText.textContent = 'Medium strength';
                strengthText.style.color = '#ffd166';
            } else {
                strengthFill.style.background = '#06d6a0';
                strengthText.textContent = 'Strong password';
                strengthText.style.color = '#06d6a0';
            }
        }
        
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            validatePasswordMatch();
        });
        
        // Password match validation
        const confirmPasswordInput = document.getElementById('confirm_password');
        const passwordMatchError = document.getElementById('passwordMatchError');
        
        function validatePasswordMatch() {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;
            
            if (password && confirmPassword && password !== confirmPassword) {
                passwordMatchError.style.display = 'flex';
                confirmPasswordInput.closest('.input-wrapper').classList.add('error');
            } else {
                passwordMatchError.style.display = 'none';
                confirmPasswordInput.closest('.input-wrapper').classList.remove('error');
            }
        }
        
        confirmPasswordInput.addEventListener('input', validatePasswordMatch);
        
        // Form validation
        const registrationForm = document.getElementById('registrationForm');
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        const termsCheck = document.getElementById('termsCheck');
        const termsError = document.getElementById('termsError');
        
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        function showError(input, message) {
            const wrapper = input.closest('.input-wrapper');
            wrapper.classList.add('error');
            
            // Create error message if it doesn't exist
            let errorDiv = wrapper.nextElementSibling;
            if (!errorDiv || !errorDiv.classList.contains('error-message')) {
                errorDiv = document.createElement('div');
                errorDiv.className = 'error-message';
                wrapper.parentNode.insertBefore(errorDiv, wrapper.nextSibling);
            }
            errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
            errorDiv.style.display = 'flex';
        }
        
        function clearError(input) {
            const wrapper = input.closest('.input-wrapper');
            wrapper.classList.remove('error');
            
            const errorDiv = wrapper.nextElementSibling;
            if (errorDiv && errorDiv.classList.contains('error-message')) {
                errorDiv.style.display = 'none';
            }
        }
        
        // Real-time validation
        nameInput.addEventListener('input', function() {
            clearError(this);
            if (this.value && this.value.length < 2) {
                showError(this, 'Name must be at least 2 characters');
            }
        });
        
        emailInput.addEventListener('input', function() {
            clearError(this);
            if (this.value && !validateEmail(this.value)) {
                showError(this, 'Please enter a valid email address');
            }
        });
        
        registrationForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            // Validate name
            if (!nameInput.value) {
                showError(nameInput, 'Please enter your full name');
                isValid = false;
            } else if (nameInput.value.length < 2) {
                showError(nameInput, 'Name must be at least 2 characters');
                isValid = false;
            }
            
            // Validate email
            if (!emailInput.value) {
                showError(emailInput, 'Please enter your email address');
                isValid = false;
            } else if (!validateEmail(emailInput.value)) {
                showError(emailInput, 'Please enter a valid email address');
                isValid = false;
            }
            
            // Validate password
            if (!passwordInput.value) {
                showError(passwordInput, 'Please enter a password');
                isValid = false;
            } else if (passwordInput.value.length < 6) {
                showError(passwordInput, 'Password must be at least 6 characters');
                isValid = false;
            }
            
            // Validate password match
            if (passwordInput.value !== confirmPasswordInput.value) {
                passwordMatchError.style.display = 'flex';
                confirmPasswordInput.closest('.input-wrapper').classList.add('error');
                isValid = false;
            }
            
            // Validate terms
            if (!termsCheck.checked) {
                termsError.style.display = 'flex';
                termsCheck.closest('label').classList.add('error');
                isValid = false;
            } else {
                termsError.style.display = 'none';
                termsCheck.closest('label').classList.remove('error');
            }
            
            if (!isValid) {
                e.preventDefault();
                // Add shake animation to form
                registrationForm.classList.add('shake-animation');
                setTimeout(() => {
                    registrationForm.classList.remove('shake-animation');
                }, 500);
            } else {
                // Add loading animation to button
                const submitBtn = registrationForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Creating Account...';
                submitBtn.disabled = true;
                
                // Simulate processing time
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 2000);
            }
        });
        
        // Update progress steps based on form completion
        const steps = document.querySelectorAll('.step');
        const formInputs = registrationForm.querySelectorAll('input[required]');
        
        function updateProgressSteps() {
            let filledCount = 0;
            formInputs.forEach(input => {
                if (input.value.trim()) filledCount++;
            });
            
            // Update steps
            steps.forEach((step, index) => {
                if (index <= Math.floor(filledCount / 2)) {
                    step.classList.add('active');
                } else {
                    step.classList.remove('active');
                }
            });
        }
        
        formInputs.forEach(input => {
            input.addEventListener('input', updateProgressSteps);
        });
        
        // Initialize particles and animations
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            
            // Add hover effect to card
            const registerCard = document.querySelector('.register-card');
            registerCard.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px)';
            });
            
            registerCard.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
            
            // Add focus animation to inputs
            const inputs = document.querySelectorAll('.form-control');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.closest('.input-wrapper').style.transform = 'translateY(-2px)';
                });
                
                input.addEventListener('blur', function() {
                    this.closest('.input-wrapper').style.transform = 'translateY(0)';
                });
            });
            
            // Add CSS for animations
            const style = document.createElement('style');
            style.textContent = `
                .shake-animation {
                    animation: shake 0.5s ease;
                }
                
                .fa-spinner {
                    animation: spin 1s linear infinite;
                }
                
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                
                label.error {
                    color: #ef476f;
                }
            `;
            document.head.appendChild(style);
        });
    </script>
</body>
</html>