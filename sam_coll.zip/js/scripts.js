/**
 * ==========================================================
 * SAM College E-Learning Portal - Custom JavaScript
 * (Final fixed structure)
 * ==========================================================
 */

// 1. Load the YouTube Iframe Player API asynchronously
var tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// Global variables
var player;
var courseId; // Isko initializePlayer set karega
var isYouTubeApiReady = false; 

// 2. The API calls this function when the player's code is downloaded.
function onYouTubeIframeAPIReady() {
    console.log("YouTube Iframe API is ready.");
    isYouTubeApiReady = true; 
    
    if (window.pendingPlayerSetup) {
        window.pendingPlayerSetup();
        window.pendingPlayerSetup = null;
    }
}

/**
 * 3. Function to initialize the player.
 */
function initializePlayer(iframeId, cId, videoId, onStateChangeCallback) { 
    courseId = cId; // Course ID ko global variable mein save kiya
    
    var setupPlayer = function() {
        console.log('Player initialization started for ID:', videoId); 
        player = new YT.Player(iframeId, {
            videoId: videoId, 
            playerVars: {
                'controls': 1,
                'enablejsapi': 1, 
                'modestbranding': 1,
            },
            events: {
                'onReady': onPlayerReady,
                'onStateChange': onStateChangeCallback 
            }
        });
    };
    
    if (isYouTubeApiReady) {
        setupPlayer();
    } else {
        window.pendingPlayerSetup = setupPlayer;
    }
}


// 4. Called when the player is ready to be used.
function onPlayerReady(event) {
    console.log("YouTube Player is ready for course ID:", courseId);
}

/**
 * 5. AJAX function to send progress to the server.
 */
function updateVideoProgress(percentage) {
    // Path check kar lein (Assuming folder structure: sam_coll/student/view_course.php)
    const url = '../student/update_progress.php'; 
    
    const data = {
        // FIX 2: Global 'courseId' use karein jo initializePlayer ne set kiya hai.
        course_id: courseId, 
        // FIX 1: Key name ko 'progress_percentage' set karein.
        progress_percentage: percentage
    };

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
             console.error("Network response not ok. Status:", response.status);
             return response.text().then(text => { throw new Error('Server error: ' + text); });
        }
        return response.json();
    })
    .then(data => {
        // Yahan aapko 'Progress updated' ya 'Progress not increased' message milna chahiye
        console.log("Progress Update Response:", data);
    })
    .catch((error) => {
        console.error('Error sending progress:', error);
    });
}