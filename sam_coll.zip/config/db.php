<?php
// Database connection configuration
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // Change to your database username
define('DB_PASSWORD', '');     // Change to your database password
define('DB_NAME', 'e_learning_db');

// Attempt to establish a connection to the MySQL database
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn->connect_error) {
    // Log error securely and display a user-friendly message
    die("ERROR: Could not connect. " . $conn->connect_error);
}
?>
