<?php
/**
 * Logout Handler
 * This script destroys the session and redirects the user to the home page.
 */
session_start();

// Remove all session variables
session_unset();

// Destroy the session
session_destroy();

// Redirect to the home page
header('Location: index.php');
exit;
?>