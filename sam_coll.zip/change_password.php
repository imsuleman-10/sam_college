<?php
// Start session for messages
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/db.php';

$password_err = '';
$change_pw_msg = isset($_SESSION['change_pw_msg']) ? $_SESSION['change_pw_msg'] : 'Please set your new password.';
unset($_SESSION['change_pw_msg']);

// 1. Security Check: Must be verified to access this page
if (!isset($_SESSION['is_verified_for_reset']) || !isset($_SESSION['temp_user_id'])) {
    $_SESSION['login_err'] = 'Access denied. Please verify your email first.';
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['temp_user_id'];

// 2. Process form submission (New Password)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Validate Password
    if (empty($password) || strlen($password) < 6) {
        $password_err = 'Password must have at least 6 characters.';
    } elseif ($password !== $confirm_password) {
        $password_err = 'Passwords do not match.';
    }

    // Update password if no errors
    if (empty($password_err)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        
        // Update the password
        $sql_update = "UPDATE users SET password = ? WHERE user_id = ?";
        
        if ($stmt_update = $conn->prepare($sql_update)) {
            $stmt_update->bind_param("si", $hashed_password, $user_id);
            
            if ($stmt_update->execute()) {
                // SUCCESS: Clear temporary session variables
                unset($_SESSION['is_verified_for_reset']);
                unset($_SESSION['temp_user_id']);
                unset($_SESSION['temp_email']);
                
                // Redirect to login with success message
                $_SESSION['reset_success'] = 'Your password has been reset successfully! You can now log in.';
                header('Location: login.php');
                exit;
            } else {
                $password_err = "Error updating password. Please try again.";
            }
            $stmt_update->close();
        }
    }
}

// Close connection if it was opened
if (isset($conn) && $conn->ping()) {
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Set New Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        /* Reusing Forgot Password Styles */
        body { 
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); 
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .reset-card-wrapper {
            max-width: 450px;
            margin: 50px auto; 
            animation: floatAnimation 6s ease-in-out infinite;
        }
        @keyframes floatAnimation {
            0% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
            100% { transform: translateY(0); }
        }
        .card-reset { 
            padding: 40px; 
            border-radius: 12px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.15); 
            background: #ffffff; 
            border: 1px solid #dee2e6;
        }
        .btn-primary {
             transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-primary:hover {
            transform: translateY(-2px); 
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.4) !important;
        }
        .form-control:focus {
            border-color: #007bff; 
            box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-10 col-md-8 col-lg-6 reset-card-wrapper">
            
            <div class="card-reset">
                
                <h2 class="text-center mb-4 text-primary fw-bold">
                    <i class="fas fa-key me-2"></i> Set New Password
                </h2>
                
                <p class="text-center text-muted mb-4"><?php echo htmlspecialchars($change_pw_msg); ?></p>

                <?php if (!empty($password_err)): ?>
                    <div class="alert alert-danger fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $password_err; ?>
                    </div>
                <?php endif; ?>

                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    
                    <div class="mb-3">
                        <label for="password" class="form-label fw-semibold">
                            <i class="fas fa-lock me-1 text-primary"></i> New Password (Min 6 chars)
                        </label>
                        <input type="password" name="password" id="password" class="form-control form-control-lg <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" required placeholder="••••••••">
                        <span class="invalid-feedback"><?php echo $password_err; ?></span>
                    </div>
                    
                    <div class="mb-4">
                        <label for="confirm_password" class="form-label fw-semibold">
                            <i class="fas fa-check-circle me-1 text-primary"></i> Confirm New Password
                        </label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control form-control-lg <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" required placeholder="••••••••">
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg shadow-sm">
                            <i class="fas fa-save me-1"></i> Update Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>